import { NgModule } from '@angular/core';
import { IonicApp, IonicModule } from 'ionic-angular';

import { FEApp } from './app.component';
import { HomePage } from '../pages/home/home';
import { LoginPage } from '../pages/core/login/login';
import { AccountPage } from '../pages/core/account/account';
import { SupportPage } from '../pages/core/support/support';
import { ProximityPage } from '../pages/proximity/proximity-landing';
import { ProximityDetailsPage } from '../pages/proximity/proximity-detail';
import { BarcodeScannerPage } from '../pages/barcodeScanner/barcodeScanner';
import { NguiMapModule} from '@ngui/map';
import { NgCalendarModule  } from 'ionic2-calendar';

import { InternalPartTransferLandingPage } from '../pages/internal-part-transfer/landing/internal-part-transfer-landing';
import { InternalPartTransferCreateDetailPage } from '../pages/internal-part-transfer/create/internal-part-transfer-detail-create';
import { InternalPartTransferEditDetailPage } from '../pages/internal-part-transfer/edit/internal-part-transfer-detail-edit';
import { InternalPartTransferSearchPage } from '../pages/internal-part-transfer/search/internal-part-transfer-search';
import { WODashboardPage} from '../pages/workorder/dashboard/wo-dashboard';
import { WODetailPage } from '../pages/workorder/detail/wo-detail';
import { CreateWOPage } from '../pages/workorder/createWO/createWO';
import { AddWODetailsPage } from '../pages/workorder/add-wo-details/add-wo-details';
import { OrderSparePartListPage } from '../pages/order-spare-part/order-spare-part-list/order-spare-part-list';
import { CreateSparePartOrderPage } from '../pages/order-spare-part/create-spare-part-order/create-spare-part-order';
import { OrderSparePartDetailsPage } from '../pages/order-spare-part/order-spare-part-details/order-spare-part-details';
import { SwitchVenderPage } from '../pages/switch-vender/switch-vender'
import { AddSparePartsPage } from '../pages/workorder/add-spare-parts/add-spare-parts';
import { AddPeoplePage } from '../pages/workorder/add-people/add-people';
import { AddEquipmentPage } from '../pages/workorder/add-equipment/add-equipment';
import { AddServicePage } from '../pages/workorder/add-service/add-service';
import { AddSparePartListPage } from '../pages/order-spare-part/add-spare-part-list/add-spare-part-list'
import { ViewWOPage } from '../pages/workorder/view-wo/view-wo';
import { CommentWOPage } from '../pages/workorder/comment/comment';
import{ AddDocumentPage } from '../pages/workorder/add-document/add-document';
import { UserLocationPage } from '../pages/user-location/user-location';

import { AuthHttp, AuthSessionService, ConfigService, AccountService,
    WorkOrderService, OrderSparePartService, PushNotificationService, ToastService,
    Principal, HasAnyAuthorityDirective, HasAnyModuleDirective, HasCreateAnyAuthorityDirective,
    HasUpdateAnyAuthorityDirective, HasDeleteAnyAuthorityDirective, HasReadAnyAuthorityDirective,
    CatalogService, InternalPartTransferService,AddPartsPriceCalculationService ,
    DatabaseService } from '../providers';

import { Http } from '@angular/http';
import { TranslateModule, TranslateLoader, TranslateStaticLoader } from 'ng2-translate';
import { DateTime } from "../providers/internal-part-transfer/internal-part-transfer.modal";
import { UserLocationService } from "../providers/userLocation/userLocation.service";
import { DataUtilsService } from "../providers/utils/dataUtils.service";

@NgModule({
  declarations: [
    FEApp,
    HomePage,
    LoginPage,
    AccountPage,
    SupportPage,
    ProximityPage,
    ProximityDetailsPage,
    BarcodeScannerPage,
    WODashboardPage,
    InternalPartTransferCreateDetailPage,
    InternalPartTransferEditDetailPage,
    InternalPartTransferSearchPage,
    InternalPartTransferLandingPage,
    WODetailPage,
    CreateWOPage,
    AddWODetailsPage,
    OrderSparePartListPage,
    CreateSparePartOrderPage,
    OrderSparePartDetailsPage,
    HasAnyAuthorityDirective,
    HasAnyModuleDirective,
    HasCreateAnyAuthorityDirective,
    HasUpdateAnyAuthorityDirective,
    HasDeleteAnyAuthorityDirective,
    HasReadAnyAuthorityDirective,
    SwitchVenderPage,
    AddSparePartsPage,
    AddPeoplePage,
    AddEquipmentPage,
    AddServicePage,
    AddSparePartListPage,
    ViewWOPage,
    CommentWOPage,
    AddDocumentPage,
    UserLocationPage
    
  ],
  imports: [
    NgCalendarModule,
    IonicModule.forRoot(FEApp),
    TranslateModule.forRoot({
            provide: TranslateLoader,
            useFactory: (http: Http) => new TranslateStaticLoader(http, './assets/i18n', '.json'),
            deps: [Http]
      }),
    NguiMapModule.forRoot({apiUrl: 'https://maps.google.com/maps/api/js?key=AIzaSyChWKKwukMc12bAIjitXFNZl6PZbZHlKdA'})
  ],
  bootstrap: [IonicApp],
  entryComponents: [
    FEApp,
    HomePage,
    LoginPage,
    AccountPage,
    SupportPage,
    ProximityPage,
    ProximityDetailsPage,
    BarcodeScannerPage,
    WODashboardPage,
    InternalPartTransferCreateDetailPage,
    InternalPartTransferEditDetailPage,
    InternalPartTransferSearchPage,
    InternalPartTransferLandingPage,
    WODetailPage,
    CreateWOPage,
    AddWODetailsPage,
    OrderSparePartListPage,
    CreateSparePartOrderPage,
    OrderSparePartDetailsPage,
    SwitchVenderPage,
    AddSparePartsPage,
    AddPeoplePage,
    AddEquipmentPage,
    AddServicePage,
    AddSparePartListPage,
    ViewWOPage,
    CommentWOPage,
    AddDocumentPage,
    UserLocationPage
  ],
  providers: [ 
    DatabaseService,
    AuthHttp, 
    AuthSessionService,
    ConfigService,
    AccountService,
    WorkOrderService,
    OrderSparePartService,
    PushNotificationService,
    ToastService,
    Principal,
    CatalogService,
    InternalPartTransferService,
    DateTime,
    UserLocationService,
    AddPartsPriceCalculationService,
    DataUtilsService
    
  ]
})
export class AppModule {}
