import { Injectable } from '@angular/core';
import { AuthHttp } from '../index'
import { ConfigService } from '../config/config.service'
import { Push } from "ionic-native";
import { Platform } from 'ionic-angular';
import { ToastService } from './toast-notification'

@Injectable()
export class PushNotificationService {

    constructor(
        private authHttp: AuthHttp,
        public platform: Platform,
        private configService: ConfigService,
        private toastService:ToastService) {}

    public callSetupPushNotification():void{
        this.platform.ready().then(() => {
            this.setupPush();
        });
    }

    private setupPush():void {
        if (!this.platform.is('cordova')) {
            console.warn("Push notifications not initialized. Cordova is not available - Run in physical device");
            return;
        }
		let push = Push.init({
				"android": {
				"senderID": "807116384764",
				"icon": "icon"
			},
			"ios": {
				"alert": true,
				"badge": true,
				"gcmSandbox":false
			},
			"windows": {}
		});

		push.on('registration', (data) => {
            let currentPlatform : any;

            if (this.platform.is('ios')) {
                currentPlatform = 'ios';
            }
            else if(this.platform.is('android')){
                currentPlatform = 'Android';
            }
            else{ currentPlatform = 'windows';
            }
            
			console.log("registration event: " , data.registrationId,currentPlatform);
            let tokenData = {
                 'token': data.registrationId,
                 'platform' : currentPlatform
            };
			this.configService.getServiceUrl("NOTIFICATION").take(1).subscribe(url => {		
			    this.authHttp.post(url, tokenData)
                    .subscribe(response => {
                        console.log("save successfully");
                    },error => {
                        console.log("error in saving registrationId ");
                    });
			    });
            });

			push.on('error', (e) => {
				console.log("push error = " + e.message);
			});

			push.on('notification', (data) => {
				console.log('notification event');
                console.log(data);
                this.toastService.showToast('bottom',data.message);
            
			push.finish( () => {
				console.log('notification success');}, 
                () => { console.log('notification error'); });
            });
		}

    }

