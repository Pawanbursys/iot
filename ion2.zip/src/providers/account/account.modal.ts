export declare class Account{
    id:string;
    login:string;
    firstName:string;
    lastName:string;
    activated:boolean;
    authorities:Array<string>;
    mobileNumber:string;
    isCustomer:boolean;
    parentVendor:Vendor;
    createdDate:string;
    createdBy:string;
    lastModifiedBy:string;
    lastModifiedDate:string;
    sites:Array<string>;
    acl:Array<string>;
    parentVendorList:Array<any>;
}

export declare class Vendor {
    id:string;
    vendorName:string;
    isManufacturingIndustryVendor:boolean;
    activated:boolean;
    userCreated:boolean;
    services: Array<Service>;
}

export declare class Service {
    id:string;
    serviceName:string;
}