import { Injectable } from '@angular/core';
import { Headers } from '@angular/http';
import { AuthHttp } from '../index'
import { Observable } from "rxjs/Observable";
import { ConfigService } from '../config/config.service'
import { Account } from './account.modal';
import {UserLocationService} from '../userLocation/userLocation.service'

@Injectable()
export class AccountService {
_account:Account
    constructor(private authHttp: AuthHttp, private configService: ConfigService,
    private userLocationService: UserLocationService) {
    }

    currentLat: number;
    currentLng: number;

    public getAccount(): Observable<Account> {
        let headers = new Headers();
        headers.append("Content-Type", "application/x-www-form-urlencoded");
       
       if(this._account){
             return Observable.create(observer => {
                    observer.next(this._account);
                    observer.complete();

             });
       }else{
            return Observable.create(observer => {
                this.configService.getServiceUrl("USER").take(1).subscribe(url => {
                    this.authHttp.get(url, { headers: headers })                
                    .subscribe(response => {  

                            if (navigator.geolocation) {
                                console.log("location enabled.");
                                navigator.geolocation.getCurrentPosition(success => {
                                    console.log("location got successfully.");
                                    this.currentLat = success.coords.latitude;
                                    this.currentLng = success.coords.longitude;
                                    
                                    this.userLocationService.saveUserLocation(this.currentLat, this.currentLng).take(1).subscribe(response => {
                                        console.log("Location saved successfully. ",response);
                                    }, error =>{
                                        console.log("error "+error);
                                    })


                                }, error => {
                                    console.log("location failed.");

                                }, options => {
                                    console.log("options");
                                });

                            }

                            if(response.headers.get("xrt")){
                                localStorage.setItem('X-CSRF-TOKEN', response.headers.get("xrt"));
                            }
                            this._account = response.json();
                            observer.next(this._account);
                            observer.complete();
                        }, error => {
                            observer.error(error);
                            observer.complete();
                        });
                })

            });
       }
    }

}
