import { Injectable } from '@angular/core';
import { AuthHttp } from '../index'
import { Observable } from "rxjs/Observable";
import { ConfigService } from '../config/config.service'

import { Account } from '../../providers';

@Injectable()
export class CatalogService {

    constructor(private authHttp: AuthHttp, private configService: ConfigService) {
    }

	 
     public getItemList(account :Account, page : number, records : number, itemType: string): Observable<any> {
        return Observable.create(observer => {
            this.configService.getServiceUrl("ITEM_SEARCH_CATALOG").take(1).subscribe(url => {
                this.authHttp.query(url+'/'+itemType+'/'+account.parentVendor.id+'/'+page+'/'+records)
                    .map((response) => response.json())
                    .subscribe(response => {
                        observer.next(response);
                        observer.complete();
                    }, error => {
                        observer.error(error);
                        observer.complete();
                    });
                })
            });
        }



     public searchItemInCatalog(itemNumber : string, itemType:string, account :Account): Observable<any> {
       
        return Observable.create(observer => {
            this.configService.getServiceUrl("ITEM_SEARCH_CATALOG").take(1).subscribe(url => {
                this.authHttp.query(url+itemNumber+'/'+itemType+'/'+account.parentVendor.id+'/'+''+'/'+'')
                    .map((response) => response.json())
                    .subscribe(response => {
                        observer.next(response);
                        observer.complete();
                    }, error => {
                        observer.error(error);
                        observer.complete();
                    });
                })
            });
        }


    // public getPeopleList(account :Account, page : number, records : number): Observable<any> {
    //     return Observable.create(observer => {
    //         this.configService.getServiceUrl("ITEM_SEARCH_CATALOG").take(1).subscribe(url => {
    //             this.authHttp.get(url+'/PEOPLE' +'/'+account.parentVendor.id+'/'+page+'/'+records)
    //                 .map((response) => response.json())
    //                 .subscribe(response => {
    //                     observer.next(response);
    //                     observer.complete();
    //                 }, error => {
    //                     observer.error(error);
    //                     observer.complete();
    //                 });
    //             })
    //         });
    //     }

}
