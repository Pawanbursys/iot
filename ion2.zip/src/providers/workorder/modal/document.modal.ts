export class Document{
    
    id:string;
	documentId:string;
	description:string;
	documentType:string;
	field:string;
	fileSize:string; 
	createdOn:Date;
	createdBy:string;
	comments:string;
	fileName:string;
	fileData:string;
	imageData:string;

    constructor(){}
}