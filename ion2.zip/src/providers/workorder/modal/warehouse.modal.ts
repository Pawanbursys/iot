export class Warehouse {

     id:string;
	 wareHouseId:string;
	 whseName:string;
	 address:string;
	 whseContact:string;
	 purchaseContact:string;
	 siteInfo:string;
	 customer:string;
	 createdBy:string;
	 createdDate:Date;
	 lastModifiedBy:string;
	 lastModifiedDate:Date;
	 qtyOnHandsValue:number;
	 whseType:string;

     constructor(){}
}