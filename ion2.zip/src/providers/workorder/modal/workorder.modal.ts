
import { SiteEquipment } from './siteEquipment.modal';
import { SmartContract } from '../modal/smartContract.modal';
import { Contact } from '../modal/contact.modal';
import{ WorkOrderItem } from '../modal/workOrderItem.modal';
import { Document } from '../modal/document.modal';

export class WorkOrder{
    
    id:string;
    workOrderId:string;
    longDescription:string;
    assignedPersonnel:any;  //TODO: Get more details
    jobStatus:string;
    customer:Customer;
    site:Site;
    fileList:Array<string>;
    fileNameList:Array<string>;
    itemCount:number;
    itemIndexList:any;  //TODO: Get more details
    createdBy:string;
    createdDate:string;
    vendor:string;
    machine:SiteEquipment;
    serviceTag:string;
    isResidence:boolean;
    workOrderTransactions:any;  //TODO: Get more details
    isWOAssignedUser:boolean;
    isAreaOrDistrictMgr:boolean;
    isPeopleLineItemAdded:boolean;
    isSparePartsOrder:boolean;
    contract : SmartContract;
    primaryContact : Contact;
    workOrderItems : Array<WorkOrderItem>;
    totalPrice : number;
    machineStatus:string;
    eta:Date;
    documents:Array<Document>;
    resolution:string;
    symptoms:string;
    workingHours:string;

    constructor(){}
}

export class JobStatus {
    readonly Created     :string;
    readonly Accepted    :string;
    readonly Started     :string;
    readonly Suspended   :string;
    readonly Completed   :string;

    constructor(){
        this.Created     ="Created";
        this.Accepted    ="Accepted";
        this.Started     ="Started";
        this.Suspended   ="Suspended";
        this.Completed   ="Completed";
    }
}

export class Customer{
    companyName:string;
    userCreated:boolean;
    copyAddress:boolean;
    constructor(){}
}

export  class Site{
    id:string;
    siteName:string;
    assignedPersonnels:any; //TODO: Get more details
    favoriteFlag:boolean;
    primaryContact : Contact;
    
    constructor(){}
}

export  class Region{
    regionName:string;
  constructor(){}
}