export class CustomerVendorPartMap{
     mapId:string;
	 vendorItemNumber:string;
	 customerItemNumber:string;
	 billingCode:string;
	 description:string;
	 createdBy:string;
	 listPrice:string;
	 itemType:string;
	 costPrice:string;
	 parentPartNumber:string;

     constructor(){}
}