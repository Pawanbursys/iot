import { SiteEquipment } from '../modal/siteEquipment.modal';

export class WorkOrderItem{

    id:string;
	itemNumber:string;
	customerItemNumber:string;
	itemType:string;
	description:string;
	itemNotes:string;
	itemQty:number;
	contractPrice:number;
	listPrice:string;
	status:string;
	contractPriceStr:string;
	usedItemQty:number;
	qtyAvailabilityInInventory:boolean;
	workingHours:string;
	price:number;
	billable:number;
	contractType:number;
	discount:number;
	contractName:string;
	unitRate:string;
	unitRateType:string;
	dispatchQuantity:number;
	warehousePickUpTicketId:string;
	warehouses:any;
	qtyOnHands:any;
	costPrice:number;
	siteAsset:SiteEquipment;
	assignedPersonnel:Array<any>;
	
    constructor(){}

}