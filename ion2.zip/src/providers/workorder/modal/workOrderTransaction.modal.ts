export class WorkOrderTransaction{

	transactionType:string;
	workOrderId:string;
	oldValue:string;
	newValue:string;
	createdByFullName:string;
	createdDate:Date;
	createdBy:string;
	approvalComment:string;

	constructor(){}
}