import { Customer } from './workorder.modal';
import { Site } from './workorder.modal';
import { Region } from './workorder.modal';
export class SiteEquipment{

    id:string;
    customer:Customer;
    siteInfoDTO:Site;
    createdBy:string;
    createdDate:string;
	equipmentName : string;
	serviceTag : string;
    region : Region;  
    description : string;  
    longDescription:string;
    partNumber:string;
    manufacturer:string;
    extendedNotes:string;
    installationDate:Date;
    comminsioningDate:Date;
    warrantyExpiryDate:Date;
    machineStatus:string;


    constructor(){}
}