export class Contact {

    id : string;
    firstName : string;
    lastName : string;
    mobileNumber : string;
    workPhone : string;
    emailAdr : string;
    mobileNumberCountryCode : string;
    workPhoneCountryCode : string;

}