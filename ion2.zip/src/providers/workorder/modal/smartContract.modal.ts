export class SmartContract{

    id:string;
    contractName:string;
    description:string;
    createdDate:string;
	createdByFullName : string;
	type : string ;
    servicePrice : number;
    contractOtherDetails : ContractOtherDetails;
    smartContractItems : SmartContractItems;    
    constructor(){}
}

export class ContractOtherDetails{

  coveredInFP : boolean;
  coveredInTM : boolean;
  discountOnListPrice : boolean;
  addOnCostPrice : boolean;
  discountOnListPriceValue : number;
  addOnCostPriceValue : number;

  constructor(){}
}



export class SmartContractItems{
 
    customerItemNumber : string;
    vendorItemNumber : string;
    listPrice : number;
    contractPrice :number; 
    costPrice: number;

    discountOnListPrice : boolean;
    addOnCostPrice : boolean;
    discountOnListPriceValue : number;
    addOnCostPriceValue : number;
    BillingCode : string;
    itemType : string;
    description : string;
    subCategory: string;
    category1: string;
    category2 : string;
    category3 : string;
    category4 : string;
    contractPriceStr : string;
    coveredUnderWaranty : string;

    constructor(){}

}