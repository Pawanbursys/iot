import { Injectable } from '@angular/core';
import { Headers } from '@angular/http';
import { AuthHttp } from '../index'
import { Observable } from "rxjs/Observable";
import { ConfigService } from '../config/config.service'
import { WorkOrder ,Site,JobStatus} from './modal/workorder.modal';

import { SiteEquipment,Account, SmartContract, WorkOrderTransaction, Document} from '../../providers';

@Injectable()
export class WorkOrderService {

saveWorkOrderObject:any;
updateWorkOrderObject:any;

    constructor(private authHttp: AuthHttp, private configService: ConfigService) {
    }

    public getWorkOrders(): Observable<Array<WorkOrder>> {
        let headers = new Headers();
        headers.append("Content-Type", "application/x-www-form-urlencoded");
        return Observable.create(observer => {
            this.configService.getServiceUrl("WO").take(1).subscribe(url => {
                this.authHttp.query(url, { headers: headers })
                    .map((response) => response.json())
                    .subscribe(response => {
                        observer.next(response);
                        observer.complete();
                    }, error => {
                        observer.error(error);
                        observer.complete();
                    });
            })

        });
    }


	 public getWorkOrderDetails(woid: String): Observable<any> {
        return Observable.create(observer => {
            this.configService.getServiceUrl("WO").take(1).subscribe(url => {
                this.authHttp.get(url+"/"+woid)
                    .map((response) => response.json())
                    .subscribe(response => {
                        observer.next(response);
                        observer.complete();
                    }, error => {
                        observer.error(error);
                        observer.complete();
                    });
                })

            });
        }

     public getServiceTagDetail(serviceTag : String): Observable<any> {
       
        return Observable.create(observer => {
            this.configService.getServiceUrl("SITE_ASSET_TAG").take(1).subscribe(url => {
                 console.log(url);
                this.authHttp.get(url+serviceTag)
                    .map((response) => response.json())
                    .subscribe(response => {
                        observer.next(response);
                        observer.complete();
                    }, error => {
                        observer.error(error);
                        observer.complete();
                    });
            })

        });
    }




     public getMachineSmartContract(machineId : String): Observable<any> {
       
        return Observable.create(observer => {
            this.configService.getServiceUrl("MACHINE_SMART_CONTRACT").take(1).subscribe(url => {
                this.authHttp.get(url+machineId)
                    .map((response) => response.json())
                    .subscribe(response => {
                        observer.next(response);
                        observer.complete();
                    }, error => {
                        observer.error(error);
                        observer.complete();
                    });
            })

        });
    }



public saveWO(siteEquipment :SiteEquipment,account :Account, smartcontract : SmartContract , isSparePartsOrder : boolean) {

        console.log(siteEquipment);
       let workOrder=new WorkOrder();
   

       workOrder.machine=siteEquipment;
       workOrder.machineStatus=siteEquipment.machineStatus;
       workOrder.site=siteEquipment.siteInfoDTO;
       workOrder.customer=siteEquipment.customer;
       workOrder.vendor=account.parentVendor.vendorName;
       workOrder.jobStatus=new JobStatus().Created;
       workOrder.contract=smartcontract;
       workOrder.longDescription=siteEquipment.description?siteEquipment.description:" ";
       workOrder.primaryContact = siteEquipment.siteInfoDTO.primaryContact;
       workOrder.serviceTag = siteEquipment.serviceTag;
       workOrder.isSparePartsOrder = isSparePartsOrder;

        this.saveWorkOrderObject={wo: workOrder};
        console.log("this.saveWorkOrderObject :: ",this.saveWorkOrderObject);

        return Observable.create(observer => {
            this.configService.getServiceUrl("WO").take(1).subscribe(url => {
                this.authHttp.post(url, this.saveWorkOrderObject)
                    .map((response) => response.json())
                    .subscribe(response => {
                        observer.next(response);
                        observer.complete();
                    }, error => {
                        observer.error(error);
                        observer.complete();
                    });
            })

        });
    }


    public updateWO(workOrder :WorkOrder) {
        console.log("WO :: " +workOrder);
        this.updateWorkOrderObject={wo: workOrder};
        console.log("this.updateWorkOrderObject :: ",this.updateWorkOrderObject);

        return Observable.create(observer => {
            this.configService.getServiceUrl("WO").take(1).subscribe(url => {
                this.authHttp.put(url, this.updateWorkOrderObject)
                    .map((response) => response.json())
                    .subscribe(response => {
                        observer.next(response);
                        observer.complete();
                    }, error => {
                        observer.error(error);
                        observer.complete();
                    });
            })

        });
    }


    public getWarehousesForWO(itemNumber:string, isSparePartsOrder:boolean) {
          return Observable.create(observer => {
            this.configService.getServiceUrl("WO_WAREHOUSE").take(1).subscribe(url => {
                this.authHttp.query(url+itemNumber+'/'+isSparePartsOrder)
                    .map((response) => response.json())
                    .subscribe(response => {
                        observer.next(response);
                        observer.complete();
                    }, error => {
                        observer.error(error);
                        observer.complete();
                    });
            })

        });
      
    }



     public saveWorkOrderEvent(workOrderTransaction:WorkOrderTransaction) {
        return Observable.create(observer => {
            this.configService.getServiceUrl("WO").take(1).subscribe(url => {
                this.authHttp.post(url+'/event', workOrderTransaction)
                    .map((response) => response.json())
                    .subscribe(response => {
                        observer.next(response);
                        observer.complete();
                    }, error => {
                        observer.error(error);
                        observer.complete();
                    });
            })

        });
    }



     public saveWorkOrderDocuments(documents:Array<Document>) {
        return Observable.create(observer => {
            this.configService.getServiceUrl("WO").take(1).subscribe(url => {
                this.authHttp.post(url+'/document/mobile', documents)
                    .map((response) => response.json())
                    .subscribe(response => {
                        observer.next(response);
                        observer.complete();
                    }, error => {
                        observer.error(error);
                        observer.complete();
                    });
            })

        });
    }

}
