import { Injectable } from '@angular/core';
import { AuthHttp } from '../index'
import { Observable } from "rxjs/Observable";
import { ConfigService } from '../config/config.service'
import { Customer } from './proximity.modal'

@Injectable()
export class ProximityService {

    constructor(private authHttp: AuthHttp, private configService: ConfigService) {
    }

    public getCustomers(): Observable<Array<Customer>> {
      
        return Observable.create(observer => {
            this.configService.getServiceUrl("CUSTOMERS").take(1).subscribe(url => {
                this.authHttp.query(url)
                    .map((response) => response.json())
                    .subscribe(response => {
                        console.log(response);
                        observer.next(response);
                        observer.complete();
                    }, error => {
                        observer.error(error);
                        observer.complete();
                    });
            })

        });
    }

    public getWorkOrderDetailsOfSite(siteId: String): Observable<any> {
        
        return Observable.create(observer => {
            this.configService.getServiceUrl("SITE_WO_DATA").take(1).subscribe(url => {
                this.authHttp.query(url+"/"+siteId)
                    .map((response) => response.json())
                    .subscribe(response => {
                        observer.next(response);
                        observer.complete();
                    }, error => {
                        observer.error(error);
                        observer.complete();
                    });
            })

        });
    }

}
