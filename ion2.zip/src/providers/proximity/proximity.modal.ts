export declare class Customer{
    id: string;
    custId: string;
    companyName:string;
    sites: any;
}

export declare class Site{
    siteName:string;
    assignedPersonnels:any; //TODO: Get more details
    favoriteFlag:boolean;
    mailingAddress: any;
}

export declare class Address{
    longitude:string;
    latitude:string; //TODO: Get more details
}