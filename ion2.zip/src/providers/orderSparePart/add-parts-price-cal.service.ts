import { Injectable } from '@angular/core';
import { Headers } from '@angular/http';
import { AuthHttp } from '../index'
import { Observable } from "rxjs/Observable";
import { ConfigService } from '../config/config.service'

import { SiteEquipment, Account, SmartContract, WorkOrder} from '../../providers';

@Injectable()
export class AddPartsPriceCalculationService {

constructor(private authHttp: AuthHttp,
 			private configService: ConfigService) {}

    public getItem(target, catItem) {
		let item = {
			itemType: catItem.itemType,
			itemNumber: catItem.vendorItemNumber,
			description: catItem.description,
			listPrice: catItem.listPrice,
			itemNotes: catItem.itemNotes,
			itemQty: catItem.itemQty,
			warehouses: [],
			qtyOnHands: [],
			costPrice: catItem.costPrice,
			billable: "Yes",
			siteAsset: target.machine,
			unitRate: catItem.unitRate,
			unitRateType: catItem.unitRateType,
			contractName: target.contractName,
			price: target.price,
			contractPrice: target.contractPrice
		};


		if (target.contract && target.contract.type == "T & M support contract") {

			var smartCoractItemTemp = null;
			if (target.contract.smartContractItems) {
				target.contract.smartContractItems.forEach(smartContractItem => {
					if (smartContractItem.vendorItemNumber == catItem.vendorItemNumber) {
						smartCoractItemTemp = smartContractItem;
						this.checkAndSetSmartItemContract(smartContractItem, item, target)
					}
				});
			}

			if (!smartCoractItemTemp) {
				this.checkAndSetOtherContract(target, catItem, item)
			}
		} else if (target.contract && target.contract.type == "Fixed service contract") {
			item.contractName = target.contract.type;
			this.checkAndSetOtherContract(target, catItem, item)
		}

		if (!target.totalPrice) {
			target.totalPrice = 0;
		}

		if (!item.contractPrice && (item.itemType == "PEOPLE" || item.itemType == "SERVICE")) {
			item.price = item.listPrice;
			target.totalPrice = target.totalPrice + Number(item.price);
		}

		return item;
	}


	public checkAndSetSmartItemContract(smartContractItem, item, target) {
		if (smartContractItem.addOnCostPrice) {
			item.addOnCostPrice = true;
			item.addOnCostPriceValue = smartContractItem.addOnCostPriceValue;
			item.billable = "Yes";
			this.calculateAddOnCostPrice(item);
			item.contractName = target.contract.type;

		} else if (smartContractItem.discountOnListPrice) {
			item.discountOnListPrice = true;
			item.discountOnListPriceValue = smartContractItem.discountOnListPriceValue;
			item.billable = "Yes";
			this.calculateDiscountOnListPrice(item);
			item.contractName = target.contract.type;
		}
	}


	public calculateAddOnCostPrice(item) {
		if (item.billable == "Yes" && item.costPrice) {
			var price = item.costPrice * (Number(item.addOnCostPriceValue) / 100)
			item.contractPrice = Number(item.listPrice) + price;
			if (item.itemType == "PEOPLE" || item.itemType == "SERVICE") {
				item.price = item.contractPrice;
			}
		}
	}

	public calculateDiscountOnListPrice(item) {
		if (item.billable == "Yes" && item.listPrice) {
			var price = item.listPrice * (Number(item.discountOnListPriceValue) / 100)
			item.contractPrice = Number(item.listPrice) - price;
			if (item.itemType == "PEOPLE" || item.itemType == "SERVICE") {
				item.price = item.contractPrice;
			}
		}
	}

	public checkAndSetOtherContract(target, catItem, item) {
		target.contract.contractOtherDetails.forEach(otherContract => {
			let contractItemType = otherContract.name.toLowerCase();
			let catItemType = catItem.itemType.toLowerCase();
			let isManufactured = "yes";
			if (catItem.manufactured) {
				isManufactured = catItem.manufactured.toLowerCase();
			}

			if (contractItemType == "manufactured parts" && catItemType == "product" && isManufactured == "yes" && (otherContract.coveredInTM || otherContract.coveredInFP)) {
				item.coveredUndercontact = true;
				item.billable = "No";
				item.contractName = target.contract.type;

			} else if (contractItemType == "manufactured parts" && catItemType == "product" && isManufactured == "yes" && otherContract.addOnCostPrice) {
				item.addOnCostPrice = true;
				item.addOnCostPriceValue = otherContract.addOnCostPriceValue;
				this.calculateAddOnCostPrice(item);
				item.contractName = target.contract.type;

			} else if (contractItemType == "manufactured parts" && catItemType == "product" && isManufactured == "yes" && otherContract.discountOnListPrice) {
				item.discountOnListPrice = true;
				item.discountOnListPriceValue = otherContract.discountOnListPriceValue;
				this.calculateDiscountOnListPrice(item);
				item.contractName = target.contract.type;

			} else if (contractItemType == "procured parts" && catItemType == "product" && isManufactured == "no" && (otherContract.coveredInTM || otherContract.coveredInFP)) {
				item.coveredUndercontact = true;
				item.billable = "No";
				item.contractName = target.contract.type;

			} else if (contractItemType == "procured parts" && catItemType == "product" && isManufactured == "no" && otherContract.addOnCostPrice) {
				item.addOnCostPrice = true;
				item.addOnCostPriceValue = otherContract.addOnCostPriceValue;
				this.calculateAddOnCostPrice(item);
				item.contractName = target.contract.type;

			} else if (contractItemType == "procured parts" && catItemType == "product" && isManufactured == "no" && otherContract.discountOnListPrice) {
				item.discountOnListPrice = true;
				item.discountOnListPriceValue = otherContract.discountOnListPriceValue;
				this.calculateDiscountOnListPrice(item);
				item.contractName = target.contract.type;

			} else if (contractItemType == catItemType && (otherContract.coveredInTM || otherContract.coveredInFP)) {
				item.coveredUndercontact = true;
				item.billable = "No";
				item.contractName = target.contract.type;

			} else if (contractItemType == catItemType && otherContract.addOnCostPrice) {
				item.addOnCostPrice = true;
				item.addOnCostPriceValue = otherContract.addOnCostPriceValue;
				this.calculateAddOnCostPrice(item);
				item.contractName = target.contract.type;

			} else if (contractItemType == catItemType && otherContract.discountOnListPrice) {
				item.discountOnListPrice = true;
				item.discountOnListPriceValue = otherContract.discountOnListPriceValue;
				this.calculateDiscountOnListPrice(item);
				item.contractName = target.contract.type;
			}
		});
	}

	public priceCalculationOnItemChange(wOItem) {
		console.log(wOItem);
		var itemQty = 1;

		if (wOItem.itemType == 'PRODUCT' || wOItem.itemType == 'EQUIPMENT') {
			itemQty = wOItem.itemQty;
		}

		if (wOItem.billable === 'No' || !itemQty || !wOItem.listPrice) {
			wOItem.price = 0;
			return;
		}

		var price = 0;
		if (wOItem.contractPrice) {
			price = wOItem.contractPrice;
		} else {
			price = wOItem.listPrice;
		}

		wOItem.price = Number(itemQty) * Number(price);

		if (wOItem.discount && Number(wOItem.discount) <= 100) {
			wOItem.price = wOItem.price - (wOItem.price * (Number(wOItem.discount) / 100));
		}

	}

}