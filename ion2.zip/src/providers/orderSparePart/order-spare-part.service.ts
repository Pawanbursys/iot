import { Injectable } from '@angular/core';
import { AuthHttp } from '../index'
import { Observable } from "rxjs/Observable";
import { ConfigService } from '../config/config.service'

import { WorkOrder} from '../../providers';

@Injectable()
export class OrderSparePartService {

constructor(private authHttp: AuthHttp, private configService: ConfigService) {
    }

public getListOfSpareParts(): Observable<Array<WorkOrder>>{
     
     return Observable.create(observer => {
            this.configService.getServiceUrl("SPARE_PART_ORDER_LIST").take(1).subscribe(url => {
                this.authHttp.query(url)
                    .map((response) => response.json())
                    .subscribe(response => {
                        observer.next(response);
                        observer.complete();
                    }, error => {
                        observer.error(error);
                        observer.complete();
                    });
            })
        });
    }
    
}
