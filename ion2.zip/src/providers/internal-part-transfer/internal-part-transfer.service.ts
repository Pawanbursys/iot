import { Injectable } from '@angular/core';
import { AuthHttp } from '../index'
import { Observable } from "rxjs/Observable";
import { ConfigService } from '../config/config.service';
import { WhsePickUpTicket } from './internal-part-transfer.modal';

@Injectable()
export class InternalPartTransferService {

    saveWhsePickUpTicketObject: any;

    constructor(private authHttp: AuthHttp, private configService: ConfigService) {
    }

    public getSearchDetailsOfItems(searchValue: String): Observable<any> {
        return Observable.create(observer => {
            this.configService.getServiceUrl("CENTRALISE_SEARCH_FOR_INVENTORY").take(1).subscribe(url => {
                this.authHttp.query(url + "/" + searchValue)
                    .map((response) => response.json())
                    .subscribe(response => {
                        observer.next(response);
                        observer.complete();
                    }, error => {
                        observer.error(error);
                        observer.complete();
                    });
            })
        });
    }

    public getWarehouse(id: String): Observable<any> {
        return Observable.create(observer => {
            this.configService.getServiceUrl("WAREHOUSE_FOR_PART_TRANSFER").take(1).subscribe(url => {
                this.authHttp.query(url + "/" + id)
                    .map((response) => response.json())
                    .subscribe(response => {
                        observer.next(response);
                        observer.complete();
                    }, error => {
                        observer.error(error);
                        observer.complete();
                    });
            })
        });
    }

    public getSites(): Observable<any> {
        return Observable.create(observer => {
            this.configService.getServiceUrl("SITES_FOR_PART_TRANSFER").take(1).subscribe(url => {
                this.authHttp.get(url)
                    .map((response) => response.json())
                    .subscribe(response => {
                        observer.next(response);
                        observer.complete();
                    }, error => {
                        observer.error(error);
                        observer.complete();
                    });
            })
        });
    }

    public saveWhsePickUpTicket(intrnlPartTrnsfer, fromWarehouse, itemDetail) {
        let whsePickUpTicket = new WhsePickUpTicket();

        whsePickUpTicket.fromWarehouse = fromWarehouse;
        whsePickUpTicket.itemNo = itemDetail.itemNo;
        whsePickUpTicket.description = itemDetail.description;
        whsePickUpTicket.itemType = itemDetail.itemType;
        whsePickUpTicket.toWarehouse = intrnlPartTrnsfer.toWarehouse.id;
        whsePickUpTicket.shippingSiteLocation = intrnlPartTrnsfer.shippingSiteLocation.id;
        whsePickUpTicket.comment = intrnlPartTrnsfer.comment;
        whsePickUpTicket.priority = intrnlPartTrnsfer.priority;
        whsePickUpTicket.expectedReceivingDate = new Date(intrnlPartTrnsfer.expectedReceivingDate);
        whsePickUpTicket.quantity = intrnlPartTrnsfer.quantity;

        this.saveWhsePickUpTicketObject = { whsePickUpTicket: whsePickUpTicket };

        console.log(this.saveWhsePickUpTicketObject);

        return Observable.create(observer => {
            this.configService.getServiceUrl("PICK_UP_TICKET").take(1).subscribe(url => {
                this.authHttp.post(url, whsePickUpTicket)
                    .map((response) => response.json())
                    .subscribe(response => {
                        observer.next(response);
                        observer.complete();
                    }, error => {
                        observer.error(error);
                        observer.complete();
                    });
            })

        });

    }

    public updateWhsePickUpTicket(intrnlPartTrnsfer, dateTime, fromWarehouse, itemDetail) {
        let whsePickUpTicket = new WhsePickUpTicket();
        whsePickUpTicket.id = itemDetail.id;
        whsePickUpTicket.fromWarehouse = fromWarehouse;
        whsePickUpTicket.itemNo = itemDetail.itemNo;
        whsePickUpTicket.description = itemDetail.description;
        whsePickUpTicket.itemType = itemDetail.itemType;
        whsePickUpTicket.toWarehouse = intrnlPartTrnsfer.toWarehouse.id;
        whsePickUpTicket.shippingSiteLocation = intrnlPartTrnsfer.shippingSiteLocation.id;
        whsePickUpTicket.comment = intrnlPartTrnsfer.comment;
        whsePickUpTicket.priority = intrnlPartTrnsfer.priority;
        whsePickUpTicket.expectedReceivingDate = new Date(dateTime.date);
        whsePickUpTicket.quantity = intrnlPartTrnsfer.quantity;

        return Observable.create(observer => {
            this.configService.getServiceUrl("PICK_UP_TICKET").take(1).subscribe(url => {
                this.authHttp.put(url, whsePickUpTicket)
                    .map((response) => response.json())
                    .subscribe(response => {
                        observer.next(response);
                        observer.complete();
                    }, error => {
                        observer.error(error);
                        observer.complete();
                    });
            })

        });

    }


    public getPickUpTickets(): Observable<any> {
        return Observable.create(observer => {
            this.configService.getServiceUrl("PICK_UP_TICKET").take(1).subscribe(url => {
                this.authHttp.query(url)
                    .map((response) => response.json())
                    .subscribe(response => {
                        observer.next(response);
                        observer.complete();
                    }, error => {
                        observer.error(error);
                        observer.complete();
                    });
            })
        });
    }

}
