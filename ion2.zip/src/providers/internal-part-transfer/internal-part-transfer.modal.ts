export class WhsePickUpTicket{
    id : string;
    pickUpTicketId: string;
    itemNo: string;
    description: string;
    itemType: string;
    quantity: number;
    serialNumbers: string[];
    fromWarehouse: string;
    toWarehouse: string;
    status: string;
    comment: string;
    priority: string;
    expectedReceivingDate: any;
    parentVendor: any;
    shippingSiteLocation: any;
    ticketAssignedTo: any;
    workOrder: string;
    address: any;
    whsePickUpTicketDispatchDetails: any;
    constructor(){};
}

export class DateTime{
    date: any;
    time: any;
}