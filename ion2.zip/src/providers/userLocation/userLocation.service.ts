import { Injectable } from '@angular/core';
import { AuthHttp } from '../index'
import { Observable } from "rxjs/Observable";
import { ConfigService } from '../config/config.service'
import { UserLocationHistory } from './userLocation.modal';

@Injectable()
export class UserLocationService {

    constructor(private authHttp: AuthHttp, private configService: ConfigService) {
    }

    public saveUserLocation(lat:number, lng:number): Observable<UserLocationHistory> {
        let userLocation = new UserLocationHistory();

        userLocation.coordLatitude = lat;
        userLocation.coordLongitude = lng;
        userLocation.locationSource = "Mobile";

         return Observable.create(observer => {
            this.configService.getServiceUrl("USER_LOCATION").take(1).subscribe(url => {
                this.authHttp.post(url, userLocation)
                    .map((response) => response.json())
                    .subscribe(response => {
                        observer.next(response);
                        observer.complete();
                    }, error => {
                        observer.error(error);
                        observer.complete();
                    });
            })

        });
    }
}
