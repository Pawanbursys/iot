export class UserLocationHistory {
    id: string;
    baseUser: any;
    coordLongitude: number;
    coordLatitude: number;
    locationSource: string;
}