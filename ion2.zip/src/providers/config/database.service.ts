import { Response, Headers } from '@angular/http';

import { Injectable } from '@angular/core'
import { Platform } from 'ionic-angular'
import { ConfigService } from '../../providers';
import { Observable,ReplaySubject  } from "rxjs";

declare var require: any;
var loki = require('lokijs');
var LokiIndexedAdapter = require("lokijs/src/loki-indexed-adapter");
var LokiCordovaFSAdapter = require("loki-cordova-fs-adapter");


@Injectable()
export class DatabaseService {
private db:  ReplaySubject<any>;;

public constructor(private configService: ConfigService,private platform: Platform) {
       
    console.log("* DatabaseService initilizing...*");
    this.db = new ReplaySubject<any>(1);

    if(!this.configService.isDevEnvironment()){   
        this.platform.ready().then(() => {
            console.log("Cordova Native DB")
            var ad=new LokiCordovaFSAdapter({"prefix":"bcf"});
            this.initlizedatabase(ad);    
        });
    }else{
        console.log("Browser DB");
        let ad=new LokiIndexedAdapter();
        this.initlizedatabase(ad);
    }
   
}

private  initlizedatabase(adapter:any):void{
     
    let db = new loki('bcf.json', {   
    autoload: true,                     
    autosave: true,
    autosaveInterval: 10000, //every 10 seconds
    persistenceMethod: 'adapter',
    persistenceAdapter:adapter,
    adapter: adapter,
    autoloadCallback: ()=>{                 
            console.log("* DatabaseService initilized...*");
            this.db.next(db);        
        }
    }); 
          
}

private getCollection(collectionName:string):Observable<any> {
    return Observable.create(observer => {
        this.db.subscribe(db => {
            let collection = db.getCollection(collectionName);        
            if (collection == null) {            
                console.log("creating new collection"+collectionName);
                observer.next(db.addCollection(collectionName));                
            } else {            
                observer.next(collection);
            }
        });
    });
}


private getNewCollection(collectionName:string):Observable<any> {  // Remove If already Exists
    return Observable.create(observer => {
        this.db.subscribe(db => {
            let collection = db.getCollection(collectionName);        
            if (collection != null) {                                            
                db.removeCollection(collectionName);
            }
            observer.next(db.addCollection(collectionName));                
        });
    });
}

public generateTestData():Observable<any> {  
 return Observable.create(observer => { 
    this.getCollection("test").subscribe(collection=>{
        collection.insert({ description:"Application Started",startedOn:new Date()});
        observer.next("done");
    }); 
  });
}

 public showTestData():void {
   this.getCollection("test").take(1).subscribe(collection=>{
        var results = collection.find({});       
        for (let r of results){
           console.log(`${r.description}, Time: ${new Date(r.startedOn)}`);
        }        
    }); 
  }

    public saveDataToDataBase(data:Response):void{                                    
        if(data.headers.get("content-type") && data.headers.get("content-type").indexOf("json")>-1){
            let collectionName=data.url.split("api/")[1];
            this.getNewCollection(collectionName).take(1).subscribe(collection=>{                                                
                var obj=data.json();
                collection.insert(obj);                                             
            });     
        }
    }

 

    public getDataFromDataBase(url:string,isArray:boolean):Observable<any> {                                            
        return Observable.create(observer => {
            let collectionName=url.split("api/")[1];
            this.getCollection(collectionName).subscribe(collection=>{                   
                let data=collection.find({});                             
                let databaseResponse=new DatabaseResponse(data,collectionName,this.configService,isArray);
                console.log("DatabaseResponse : ",databaseResponse.json());      
                observer.next(databaseResponse,collectionName,this.configService);                                   
            });            
        });   
    }
    

}

export class DatabaseResponse {
    private _data:Array<any>;
    public json;
    public collectionName:string;
    private configService :ConfigService;
    public headers=new Headers();
    public isArray;
    constructor(data:Array<any>,collectionName:string,configService:ConfigService,isArray:boolean){             
        this._data=data;
        this.json=this._json;
        this.isArray=isArray;
        this.collectionName=collectionName;
        this.configService=configService;
        
    }
       
    private _json(){         
        if(this._data.length == 0 && !this.isArray){            
             return  "fail";
        }else if(!this.isArray){             
             return  this._data[0];
        }else{           
            return  this._data;
        }
    }
   

}
