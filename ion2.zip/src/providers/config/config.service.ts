import { Injectable } from '@angular/core';
import { Observable } from "rxjs";

@Injectable()
export class ConfigService {
   /**
      *  dev/prod
      */     
     public readonly ENVIRONMENT:string                      =   "dev";
    
     /**
      * Base URL for Production environment
      */
     public  readonly BASEURL                                =   "http://localhost:8080/";

     /**
      * Apis
      */
     public readonly SERVICES={
          AUTH                               :   "api/authentication",       
          USER                               :   "api/account",
          WO                                 :   "api/workOrder",
          WO_ITEM                            :   "api/workOrder/woItem",
          LOGOUT                             :   "api/logout",
          NOTIFICATION                       :   "api/users/push/token",
          SITE_ASSET_TAG                     :   "api/site/assets/service-tag/",
          MACHINE_SMART_CONTRACT             :   "api/contract/machine/",
          SITE_WO_DETAILS                    :   "api/workOrderDetails/site",
          CUSTOMERS                          :   "api/base-companies/lightWeight",
          SPARE_PART_ORDER_LIST              :   "api/workOrder/web-portal/true",
          SWITCH_COMPANY                     :   "api/users/switch/",
          ITEM_SEARCH_CATALOG                :   "api/catalog/wo/mobile/items/",
          WO_WAREHOUSE                       :   "api/workOrder/warehouse/qtyOnHand/",
          CENTRALISE_SEARCH_FOR_INVENTORY    :   "api/whse-inventory-centralize-search",
          WAREHOUSE_FOR_PART_TRANSFER        :   "api/warehouse/inventory",
          SITES_FOR_PART_TRANSFER            :   "api/pick-up-ticket/sites",
          PICK_UP_TICKET                     :   "api/pick-up-ticket",
          USER_LOCATION                      :   "api/user-location",
          LOCATION                           :   "api/workOrder/woSiteMap",
          SITE_WO_DATA                       :   "api/mobile/dashboard/"
     }
 
  
 
 
 
 

    public getServiceUrl(serviceType: string): Observable<string> {   
      return Observable.create(observer => {   
          if (this.ENVIRONMENT === 'dev' && this.SERVICES[serviceType]) {
              observer.next(this.SERVICES[serviceType]);   
          } else if (this.ENVIRONMENT === 'prod' && this.SERVICES[serviceType]) {
            observer.next(this.BASEURL + this.SERVICES[serviceType]);  
          } else {
            throw new Error("Service URL not found");
          }
      });   
    }

  

  public getBaseUrl(): string {
    if (this.ENVIRONMENT === 'dev') {
      return "";
    } else {
      return this.BASEURL;
    }

  }

  public isDevEnvironment(): boolean {   
    return this.ENVIRONMENT === 'dev';    
  }

}