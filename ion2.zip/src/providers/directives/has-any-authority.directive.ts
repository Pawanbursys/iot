import { Directive, Input, TemplateRef, ViewContainerRef } from '@angular/core';
import { Principal } from '../';

@Directive({
    selector: '[hasAnyAuthority]'
})
export class HasAnyAuthorityDirective {

    private authorities: string[];

    constructor(private principal: Principal,
                private templateRef: TemplateRef<any>,
                private viewContainerRef: ViewContainerRef) {
    }

    @Input()
    set hasAnyAuthority(value: string|string[]) {
        this.authorities = typeof value === 'string' ? [ <string> value ] : <string[]> value;
        this.principal.identity().subscribe(identity => this.updateView());
    }

    private updateView(): void {
        this.viewContainerRef.clear();
        if (this.principal.hasAnyAuthority(this.authorities)) {
            this.viewContainerRef.createEmbeddedView(this.templateRef);
        }
    }
}
