import { Directive, Input, TemplateRef, ViewContainerRef } from '@angular/core';
import { Principal } from '../';

@Directive({
    selector: '[hasReadAnyAuthority]'
})
export class HasReadAnyAuthorityDirective {

    private acl: string[];

    constructor(private principal: Principal,
                private templateRef: TemplateRef<any>,
                private viewContainerRef: ViewContainerRef) {
    }

    @Input()
    set hasReadAnyAuthority(value: string|string[]) {
        this.acl = typeof value === 'string' ? [ <string> value ] : <string[]> value;
        this.principal.identity().subscribe(identity => this.updateView());
    }

    private updateView(): void {
        this.viewContainerRef.clear();
        if (this.principal.hasReadAnyAuthority(this.acl)) {
            this.viewContainerRef.createEmbeddedView(this.templateRef);
        }
    }
}
