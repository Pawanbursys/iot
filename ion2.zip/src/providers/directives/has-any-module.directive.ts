import { Directive, Input, TemplateRef, ViewContainerRef } from '@angular/core';
import { Principal } from '../';

@Directive({
    selector: '[hasAnyModule]'
})
export class HasAnyModuleDirective {

    private authorities: string[];

    constructor(private principal: Principal,
                private templateRef: TemplateRef<any>,
                private viewContainerRef: ViewContainerRef) {
    }

    @Input()
    set hasAnyModule(value: string|string[]) {
        this.authorities = typeof value === 'string' ? [ <string> value ] : <string[]> value;
        this.principal.identity().subscribe(identity => this.updateView());
    }

    private updateView(): void {
        this.viewContainerRef.clear();
        if (this.principal.hasAnyModule(this.authorities)) {
            this.viewContainerRef.createEmbeddedView(this.templateRef);
        }
    }
}
