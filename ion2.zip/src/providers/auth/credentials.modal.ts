export declare class Credentials{
    email:string;
    password:string;
    rememberMe:boolean;
}