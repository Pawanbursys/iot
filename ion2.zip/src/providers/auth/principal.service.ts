import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';

import { AccountService, ToastService} from '../';

@Injectable()
export class Principal {

    private userIdentity: any;
    private authenticated = false;
	private token = null;

    constructor( private account: AccountService ) {
     }

    identity (force?: boolean): Observable<any> {
		return Observable.create(observer => {
         	this.account.getAccount().subscribe(account => {
            if (account) {
                    this.userIdentity = account;
                    this.authenticated = true;
                } else {
                    this.userIdentity = null;
                    this.authenticated = false;
                }
            		observer.next(this.userIdentity);
                    observer.complete();
			 }, error => {
				 	this.userIdentity = null;
                 	this.authenticated = false;
                    observer.error(error);
                    observer.complete();
            });
		});
    }

    public hasAnyAuthority (authorities: string[]): boolean {

        if (!this.authenticated || !this.userIdentity || !this.userIdentity.authorities) {
            return false;
        }
        for (let i = 0; i < authorities.length; i++) {       
        	if (this.userIdentity.authorities.indexOf(authorities[i]) !== -1) {
                return true;
            }
        }
        return false;
    }

    public hasAuthority (authority: string): boolean {
        
        if (!this.authenticated || !this.userIdentity || !this.userIdentity.authorities) {
            return false;
        }else{
			return (this.userIdentity.authorities && this.userIdentity.authorities.indexOf(authority) !== -1);
		}
    }

    public hasAnyModule (modules): boolean {
            		
		if(this.userIdentity != null && this.userIdentity.parentVendor != null && this.userIdentity.parentVendor.services != null){
			if (!this.isAuthenticated () || !this.userIdentity || !this.userIdentity.parentVendor.services.serviceName) {
				return false;
			}
			for (let i = 0; i < modules.length; i++) {
				if (this.userIdentity.parentVendor.services.serviceName.indexOf(modules[i]) !== -1) {
					return true;
				}
				return false;
			}
		}

		if(this.userIdentity != null && this.userIdentity.baseCompany != null && this.userIdentity.baseCompany.services != null){
			if (!this.isAuthenticated () || !this.userIdentity || !this.userIdentity.baseCompany.services.serviceName) {
				return false;
			}
			for (let i = 0; i < modules.length; i++) {
				if (this.userIdentity.baseCompany.services.serviceName.indexOf(modules[i]) !== -1) {
					return true;
				}
				return false;
			}
		}
	}

    public isAuthenticated (): boolean {
            return this.authenticated;
        }


	public getToken (): string {
		// get ths from localstorage CSRF-TOKEN
    	 	this.token=	localStorage.getItem('X-CSRF-TOKEN');
            return this.token;
     }
        
     public authenticate (identity) {
           this.userIdentity = identity;
            if(identity==null){
            	this.token = null
            }
        }
		
	public isManufacturingIndustryVendor(): boolean {
			if(this.userIdentity != null && this.userIdentity.parentVendor != null){
				if (!this.userIdentity || !this.userIdentity.parentVendor.isManufacturingIndustryVendor) {
					return false;
				}else{
					return true;
				}
			}
		}

	//------------------------------ ACL SERVICES ---------------------------------------//


	public hasReadAuthority(entity): boolean {
		
		if (!this.isAuthenticated ()) {
			return false;
		}
		let result = true;
		if(this.userIdentity && this.userIdentity.acl && this.userIdentity.acl.length>0){
            for(let i = 0; i<this.userIdentity.acl.length; i++){
                if(this.userIdentity.acl[i].entityKey === entity){
					result= this.userIdentity.acl[i].permissions.read;
				}
            }
		}
		return result;
	}
		
	public hasCreateAuthority(entity): boolean {

		if (!this.isAuthenticated ()) {
			return false;
		}
		let result = true;	
		if(this.userIdentity && this.userIdentity.acl && this.userIdentity.acl.length>0){
            for(let i = 0; i<this.userIdentity.acl.length; i++){
                if(this.userIdentity.acl[i].entityKey === entity){
					result= this.userIdentity.acl[i].permissions.create;
				}
            }		
		}
		return result;		
	}
		
		
	public hasDeleteAuthority(entity): boolean {
		if (!this.isAuthenticated ()) {
			return false;
		}
		let result = true;
		if(this.userIdentity.acl && this.userIdentity.acl.length>0){
            for(let i = 0; i<this.userIdentity.acl.length; i++){
                if(this.userIdentity.acl[i].entityKey === entity){
					result= this.userIdentity.acl[i].permissions.delete;
				}
            }		
		}
		return result;
	}
		
		
	public hasUpdateAuthority(entity): boolean {
		if (!this.isAuthenticated ()) {
			return false;
		}
		let result = true;
		if(this.userIdentity.acl && this.userIdentity.acl.length>0){
            for(let i = 0; i<this.userIdentity.acl.length; i++){
                if(this.userIdentity.acl[i].entityKey === entity){
					result= this.userIdentity.acl[i].permissions.update;
				}
            }		
		}
		return result;
	}
		
		
	public hasCreateAnyAuthority(entities): boolean{
		if (!this.isAuthenticated ()) {
			return false;
		}
		let result=true;
		if(this.userIdentity.acl && this.userIdentity.acl.length>0){
			for(let i = 0; i<this.userIdentity.acl.length; i++){
				for(let j = 0; j<entities.length; j++){
					if(this.userIdentity.acl[i].entityKey.trim() === entities[j].trim()){
						result= this.userIdentity.acl[i].permissions.create;
					}
				}
			}
		}
		return result;
	}
		
		
	public hasReadAnyAuthority(entities): boolean {
		if (!this.isAuthenticated ()) {
			return false;
		}
		let result=true;
		if(this.userIdentity.acl && this.userIdentity.acl.length>0){
			for(let i = 0; i<this.userIdentity.acl.length; i++){
				for(let j = 0; j<entities.length; j++){
					if(this.userIdentity.acl[i].entityKey.trim() === entities[j].trim()){
						result= this.userIdentity.acl[i].permissions.read;
					}
				}
			}
		}
		return result;
	}
		
	public hasUpdateAnyAuthority(entities): boolean {
		if (!this.isAuthenticated ()) {
			return false;
		}
		let result=true;
		if(this.userIdentity.acl && this.userIdentity.acl.length>0){
			for(let i = 0; i<this.userIdentity.acl.length; i++){
				for(let j = 0; j<entities.length; j++){
					if(this.userIdentity.acl[i].entityKey.trim() === entities[j].trim()){
						result= this.userIdentity.acl[i].permissions.update;
					}
				}
			}
		}
		return result;
	}
		
	public hasDeleteAnyAuthority(entities): boolean {
		if (!this.isAuthenticated ()) {
			return false;
		}
		let result=true;
		if(this.userIdentity.acl && this.userIdentity.acl.length>0){
			for(let i = 0; i<this.userIdentity.acl.length; i++){
				for(let j = 0; j<entities.length; j++){
					if(this.userIdentity.acl[i].entityKey.trim() === entities[j].trim()){
						result= this.userIdentity.acl[i].permissions.delete;
					}
				}
			}
		}
		return result;
	}
    
}
