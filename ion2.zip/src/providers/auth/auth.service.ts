import {
    Http,
    Headers,
    Request,
    RequestOptions,
    RequestOptionsArgs,
    RequestMethod,
    Response
} from "@angular/http";
import {Injectable,Injector} from "@angular/core";
import {Observable} from "rxjs/Observable";
import "rxjs/add/observable/fromPromise";
import "rxjs/add/observable/defer";
import "rxjs/add/operator/mergeMap";
import {  DatabaseService } from '../../providers';
 

@Injectable()
export class AuthHttp {

  private http: Http;
  private databaseService:DatabaseService;



  constructor( private injector: Injector) {
    this.http=this.injector.get(Http);
    this.databaseService=this.injector.get(DatabaseService);
    
  }

  private mergeOptions(providedOpts: RequestOptionsArgs) {
    let newOptions = new RequestOptions();

    if (!providedOpts.headers) {
      providedOpts.headers = new Headers();
    }

    if (providedOpts.url && providedOpts.url.indexOf("api/") > -1 && localStorage.getItem('X-CSRF-TOKEN')) {
      providedOpts.headers.append("X-CSRF-TOKEN", localStorage.getItem('X-CSRF-TOKEN'));
    }

    newOptions = newOptions.merge(new RequestOptions(providedOpts));

    return newOptions;
  }

  private requestHelper(isArray:boolean,requestArgs: RequestOptionsArgs, additionalOptions?: RequestOptionsArgs): Observable<Response> {
    let options = new RequestOptions(requestArgs);
    if (additionalOptions) {
      options = options.merge(additionalOptions);
    }
    return this.request(new Request(this.mergeOptions(options)),isArray);
  }

  public setGlobalHeaders(headers: Array<Object>, request: Request | RequestOptionsArgs) {
    if (!request.headers) {
      request.headers = new Headers();
    }
    headers.forEach((header: Object) => {
      let key: string = Object.keys(header)[0];
      let headerValue: string = (header as any)[key];
      (request.headers as Headers).set(key, headerValue);
    });
  }

  public request(req:Request,isArray:boolean): Observable<Response> {
    
    return Observable.create(observer => {
      this.http.request(req).subscribe(data => {        
        observer.next(data);        
        this.databaseService.saveDataToDataBase(data);
      }, error => { 
         if(error.status != 401){
          this.databaseService.getDataFromDataBase(req.url,isArray).subscribe(data=>{             
            if(data.json()==="fail"){
                 observer.error("failed");
            }else{
             observer.next(data); 
            }
          });   
                
         }else{
           observer.error("Un-Authorized");
         }
      });
    });
  }

  // public get(url: string, options?: RequestOptionsArgs): Observable<Response> {
  //   return this.requestHelper({ body: '', method: RequestMethod.Get, url: url }, options);
  // }

  public get(url: string, options?: RequestOptionsArgs): Observable<Response> {
    return this.requestHelper(false,{ body: '', method: RequestMethod.Get, url: url }, options);
  }
  
  public query(url: string, options?: RequestOptionsArgs): Observable<Response> {
    return this.requestHelper(true,{ body: '', method: RequestMethod.Get, url: url }, options);
  }

  public post(url: string, body: any, options?: RequestOptionsArgs): Observable<Response> {
    return this.requestHelper(false,{ body: body, method: RequestMethod.Post, url: url }, options);
  }

  public put(url: string, body: any, options?: RequestOptionsArgs): Observable<Response> {
    return this.requestHelper(false,{ body: body, method: RequestMethod.Put, url: url }, options);
  }

  public delete(url: string, options?: RequestOptionsArgs): Observable<Response> {
    return this.requestHelper(false,{ body: '', method: RequestMethod.Delete, url: url }, options);
  }
}

