import { Injectable } from '@angular/core';
import { Headers, Response } from '@angular/http';
import { AuthHttp } from './auth.service'
import { Observable } from "rxjs/Observable";
import { ConfigService } from '../config/config.service'

@Injectable()
export class AuthSessionService {

  constructor(private authHttp: AuthHttp, private configService: ConfigService) {
  }

  public login(credentials): Observable<Response> {

    let data = 'j_username=' + encodeURIComponent(credentials.email) +
      '&j_password=' + encodeURIComponent(credentials.password) +
      '&remember-me=' + credentials.rememberMe + '&submit=Login&source=mobile';
    let headers = new Headers();
    headers.append("Content-Type", "application/x-www-form-urlencoded");
    return Observable.create(observer => {
      this.configService.getServiceUrl("AUTH").take(1).subscribe(url => {
        this.authHttp.post(url, data, { headers: headers }).subscribe(response => {
          observer.next(true);
          observer.complete();
        }, error => {
          observer.next(false);
          observer.complete();
        });
      })

    });
  }

  public logout(): Observable<any> {
      
      // logout from the server
      let headers = new Headers();
      headers.append("Content-Type", "application/x-www-form-urlencoded");
      headers.append("Access-Control-Allow-Origin", "*");
      return Observable.create(observer => {
        this.configService.getServiceUrl("LOGOUT").take(1).subscribe(url => {
          this.authHttp.post(url, {}, { headers: headers }).subscribe(response => {
            observer.next(true);
            observer.complete();
            return response;
          }, error => {
            observer.next(false);
            observer.complete();
          })
       })
    });
  }

}
