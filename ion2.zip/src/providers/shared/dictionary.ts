export interface Dictionary<T> {
    [index: string]: T;
}