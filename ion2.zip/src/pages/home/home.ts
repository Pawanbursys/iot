import { Component, ViewChild, Input } from '@angular/core';
import { Nav, LoadingController, Loading } from 'ionic-angular';
import { AccountService, Account, AuthSessionService, ToastService } from '../../providers';
import { WODashboardPage } from '../workorder/dashboard/wo-dashboard';
import { ProximityPage } from '../proximity/proximity-landing';
import { BarcodeScannerPage } from '../barcodeScanner/barcodeScanner';
import { InternalPartTransferLandingPage } from '../internal-part-transfer/landing/internal-part-transfer-landing';
import { AccountPage } from '../core/account/account';
import { SupportPage } from '../core/support/support';
import { OrderSparePartListPage } from '../order-spare-part/order-spare-part-list/order-spare-part-list';
import { Observable } from "rxjs";
import { SwitchVenderPage } from '../../pages/switch-vender/switch-vender';
import { ConfigService } from '../../providers';
import { UserLocationPage } from '../user-location/user-location'


export interface PageInterface {
  title: string;
  component: any;
  icon: string;
  logsOut?: boolean;
  index?: number;
  tabComponent?: any;
}

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {
  @ViewChild(Nav) nav: Nav;
  childPage: any;
   loading: Loading;

  username = '';
  email = '';
  private currentAccount: Account;

  vendorLogoPic: any;
  accountDetails: any;

  workOrderManagementHeight = 0;
  ainventoryManagementHeight = 0;

  woManagementPages: PageInterface[] = [
    { title: 'WO Dashboard', component: WODashboardPage, icon: 'home' },
    { title: 'Internal Part Transfer', component: InternalPartTransferLandingPage, index: 1, icon: 'swap' },
    { title: 'Order Spare Parts', component: OrderSparePartListPage, index: 2, icon: 'cart' }
  ];

  ioManagementPages: PageInterface[] = [
    { title: 'Inventory Shipment', component: SupportPage, index: 1, icon: 'fa fa-truck' },
    { title: 'Inventory Recieving', component: SupportPage, index: 2, icon: 'fa fa-building-o' },
    { title: 'Item Tracking', component: SupportPage, index: 3, icon: 'fa fa-map-marker' }
  ];


  accountPages: PageInterface[] = [
    { title: 'Account', component: AccountPage, icon: 'person' },
    //  { title: 'Support', component: SupportPage, icon: 'help' },
    { title: 'Proximity', component: ProximityPage, icon: 'map' },
    { title: 'User Location', component: UserLocationPage, icon: 'switch' }
    //{ title: 'Barcode', component: BarcodeScannerPage, icon: 'barcode' }
    // { title: 'Switch Company', component: SwitchVenderPage, icon: 'switch' }
    // { title: 'Logout', component: LoginPage, icon: 'log-out', logsOut: true }
  ];

  constructor(private accountService: AccountService,
    private authSessionService: AuthSessionService,
    private toastService: ToastService,
    private loadingCtrl: LoadingController,
    private configService:ConfigService) {
    /*let info = this.auth.getUserInfo();
    this.username = info.name;
    this.email = info.email;
    */
    this.childPage = WODashboardPage;
    this.loadUserAccount().take(1).subscribe(account => {
      this.currentAccount = account;
    })

    this.accountService.getAccount().subscribe(response => {
      this.accountDetails = response;
       this.checkVendorLogoPic();
    });

    
}

  public logout() {

    // Give the menu time to close before changing to logged out
    setTimeout(() => {

      this.showLoading();
      this.authSessionService.logout().subscribe(response => {
        if (response) {
          window.location.reload(true);
        } else {
          this.loading.dismiss();
          this.toastService.showToast("bottom", "ERROR")
        };
      });

    }, 500);

  }

  isActive(page: PageInterface) {

    try {
      let childNav = this.nav.getActiveChildNav();
      //typeof childNav !== 'undefined' 
      // Tabs are a special case because they have their own navigation
      if (childNav) {
        if (childNav.getSelected() && childNav.getSelected().root === page.tabComponent) {
          return 'primary';
        }
        return;
      }

      if (this.nav.getActive() && this.nav.getActive().component === page.component) {
        return 'primary';
      }

    } catch (e) {
      console.log(e);//TODO
    }
    return;
  }

  openPage(page: PageInterface) {
    // the nav component was found using @ViewChild(Nav)
    // reset the nav to remove previous pages and only have this page
    // we wouldn't want the back button to show in this scenario

    if (page.index) {
      this.nav.setRoot(page.component, { tabIndex: page.index }).catch(() => {
        console.log("Didn't set nav root");
      });
    } else {
      this.nav.setRoot(page.component).catch(() => {
        console.log("Didn't set nav root");
      });
    }
    // }
  }

  private loadUserAccount(): Observable<Account> {
    return this.accountService.getAccount();
  }

  showLoading() {
    this.loading = this.loadingCtrl.create({
      content: 'Please wait...'
    });
    this.loading.present();
  }

  onSwitchCompanyBtnPressed() {
    this.nav.setRoot(SwitchVenderPage).catch(() => {
      console.log("Didn't set nav root");
    });
  }

  checkVendorLogoPic(): void {
     if (this.accountDetails.parentVendor.vendorLogoId != null || this.accountDetails.parentVendor.vendorLogoId != undefined) {
       this.vendorLogoPic = this.configService.getBaseUrl()+"api/vendor/imageType/" + this.accountDetails.parentVendor.vendorLogoId;
     } else if (this.accountDetails.parentVendor.vendorLogoId == null || this.accountDetails.parentVendor.vendorLogoId == undefined) {
      this.vendorLogoPic = null;      
  }    
}
}