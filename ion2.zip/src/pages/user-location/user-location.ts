import { Component, ViewChild } from '@angular/core';
import { NavController, NavParams, Loading , LoadingController } from 'ionic-angular';
import { AccountService, ToastService, ConfigService, Principal } from '../../providers';
import { AuthHttp } from '../../providers/auth/auth.service';
import { Geolocation } from 'ionic-native';
import { LaunchNavigator, LaunchNavigatorOptions } from 'ionic-native';

/*
  Generated class for the user-locationPage.

  See http://ionicframework.com/docs/v2/components/#navigation for more info on
  Ionic pages and navigation.
*/
@Component({
    selector: 'user-location',
    templateUrl: 'user-location.html',
    providers: [Geolocation, LaunchNavigator]
})
export class UserLocationPage {
    data: any;
    loading: Loading;
    @ViewChild('map') map;

    private accountDetails: any;
    public userLocations: any;
    public currentLocation: any;
    public noWoSitesOrAllApproved: Array<any> = [];
    public machineFailureWoSites: Array<any> = [];
    public openWoSites: Array<any> = [];
    public siteWo: Array<any> = [];

    public siteInfo:{
        areaMgr:any,
        districtManager:any,
        name:any,
        primaryTech:any,
        siteName:any
    }

    constructor(
        public navCtrl: NavController,
        public navParams: NavParams,
        private accountService: AccountService,
        private authHttp: AuthHttp,
        private loadingCtrl:LoadingController,
        private configService: ConfigService,
        private toastService: ToastService,
        private principal: Principal) {

        this.accountService.getAccount().subscribe(response => {
            this.accountDetails = response;
        });
        this.showLoading();
        this.getLocations();

    }

    getLocations():void {
        this.configService.getServiceUrl("LOCATION").take(1).subscribe(url => {
            this.authHttp.query(url)
                .map((response) => response.json())
                .subscribe(response => {

                    var totalWO = 0;
                    response.siteWo.forEach(info => {
                        if(info.siteInfoDTO.mailingAddress.latitude && info.siteInfoDTO.mailingAddress.longitude){

                            let details = {
                                coordLatitude: info.siteInfoDTO.mailingAddress.latitude,
                                coordLongitude: info.siteInfoDTO.mailingAddress.longitude,
                                name: info.siteInfoDTO.customer.companyName,
                                id: info.siteInfoDTO.id,
                                siteName: info.siteInfoDTO.siteName,
                                areaMgr: "",
                                primaryTech: "",
                                districtManager: ""
                            }

                            if (info.assignedPersonnelDTOs) {
                                info.assignedPersonnelDTOs.forEach(list => {
                                    if (list.personnelRole == "Area Manager" && list.user != null) {
                                        details.areaMgr = list.user.firstName + " " + list.user.lastName;
                                    } else if (list.personnelRole == "Primary Technician" && list.user != null) {
                                        details.primaryTech = list.user.firstName + " " + list.user.lastName;
                                    } else if (list.personnelRole == "District Manager" && list.user != null) {
                                        details.districtManager = list.user.firstName + " " + list.user.lastName;
                                    }
                                });
                            }


                            if (!info.woDto) {
                                this.noWoSitesOrAllApproved.push(details);
                            } else {
                                totalWO++;
                                var openWO = 0;
                                var nonOpWO = 0;
                                var completeWO = 0;
                                var approvedWO = 0;

                                info.woDto.forEach(wo => {
                                    //check if non-operational
                                    if (wo.machineStatus == "Non-Operational" && wo.jobStatus != "Completed" && wo.jobStatus != "Approved" && wo.jobStatus != "Closed") {
                                        nonOpWO++;
                                    }
                                    //check for WO
                                    if (wo.jobStatus != "Completed" && wo.jobStatus != "Approved" && wo.jobStatus != "Closed") {
                                        openWO++;
                                    } else if (wo.jobStatus == "Completed" || wo.jobStatus == "Closed") {
                                        completeWO++;
                                    } else if (wo.jobStatus == "Approved") {
                                        approvedWO++;
                                    }
                                });

                                if (nonOpWO > 0) {
                                    this.machineFailureWoSites.push(details);  //red
                                } else if ((completeWO + approvedWO) != totalWO) {
                                    this.openWoSites.push(details);  //yellow
                                } else {
                                    this.noWoSitesOrAllApproved.push(details);   //green
                                }
                            }
                        }
                    }, error => {
                        this.loading.dismiss();
                        this.showError("ERROR LOADING DATA")
                    });
                
                });
            }
        );     
    this.loading.dismiss();
    }


    clicked(event,openSites) {
    this.siteInfo = openSites;
    var marker = event.target;

        marker.nguiMapComponent.openInfoWindow('iw', marker, {
            lat: marker.getPosition().lat(),
            lng: marker.getPosition().lng(),
            areaMgr:openSites.areaMgr,
            districtManager:openSites.districtManager,
            name:openSites.name,
            primaryTech:openSites.primaryTech,
            siteName:openSites.siteName
        });
    }



    showLoading() {
        this.loading = this.loadingCtrl.create({
            content: 'Please wait...'
        });
        this.loading.present();
    }
 
    showError(text) {
        setTimeout(() => {
            this.loading.dismiss();
        });
        this.toastService.showToast("bottom",text);
    }

}