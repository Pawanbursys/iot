import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';
import { AccountService, ToastService , ConfigService , Principal } from '../../providers';
import { AuthHttp } from '../../providers/auth/auth.service';

/*
  Generated class for the SwitchVenderPage.

  See http://ionicframework.com/docs/v2/components/#navigation for more info on
  Ionic pages and navigation.
*/
@Component({
    selector: 'switch-vender',
    templateUrl: 'switch-vender.html'
})
export class SwitchVenderPage {

    private accountDetails: any;

    constructor(
        public navCtrl: NavController,
        public navParams: NavParams,
        private accountService: AccountService,
        private authHttp:AuthHttp,
        private configService:ConfigService,
        private toastService:ToastService,
        private principal:Principal) {

        this.accountService.getAccount().subscribe(response => {
            this.accountDetails = response;
        });

    }

    public switchToVendor(vendor): void {
        this.configService.getServiceUrl("SWITCH_COMPANY").take(1).subscribe(url => {
            this.authHttp.get(url+vendor.id+"?source=mobile")             
                .subscribe(response => {                       
                      this.principal.authenticate(null);
                      window.location.reload(true);     
                        }, error => {
                          this.toastService.showToast("bottom","ERROR");
                        });
                })
    }
}
