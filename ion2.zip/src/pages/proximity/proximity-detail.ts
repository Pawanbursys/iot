import { Component, ViewChild } from '@angular/core';
import { NavController, Platform, LoadingController, Loading, NavParams } from 'ionic-angular';

import { Geolocation } from 'ionic-native';

import { ProximityService } from '../../providers/proximity/proximity.service';

import { LaunchNavigator, LaunchNavigatorOptions } from 'ionic-native';
import { ViewWOPage } from '../workorder/view-wo/view-wo';
import { WODashboardPage} from '../workorder/dashboard/wo-dashboard'

declare var google: any;

@Component({
  selector: 'page-proximity',
  templateUrl: 'proximity-detail.html',
  providers: [Geolocation, ProximityService, LaunchNavigator]
})

export class ProximityDetailsPage {
  data: any;
  loading: Loading;
  @ViewChild('map') map;

  constructor(public navCtrl: NavController, public platform: Platform, private loadingCtrl: LoadingController,
    private proximity: ProximityService, public navParams: NavParams, public launchNavigator: LaunchNavigator) {
    //this.loadCustomers();
  }

  coordLat: number;
  coordLng: number;

  createdWO: number = 0;
  startedWO: number = 0;
  completedWO: number = 0;

  currentLocation: any[];
  siteLocation: any;

  sites: any[] = [];

  currentLat: any;
  currentLng: any;

  private workordersData:any;

  public loadLocation() {

    var currentPos: any;

    console.log("alternative of rootscope ", this.navParams.data);

    this.currentLocation = [this.navParams.data.currentLatitude, this.navParams.data.currentLongitude];
    this.siteLocation = this.navParams.data.siteLocation;

    //this.showLoading();
    navigator.geolocation.getCurrentPosition(success => {
      this.currentLat = success.coords.latitude;
      this.currentLng = success.coords.longitude;

      currentPos = [this.currentLat, this.currentLng];
      this.sites.push(currentPos);
      //this.loading.dismiss();
    }, error => {
      console.log("error");
      //this.loading.dismiss();
    }, options => {
      //this.loading.dismiss();
    });

    this.showLoading();
    this.proximity.getWorkOrderDetailsOfSite(this.navParams.data.id).take(1).subscribe(wos => {
      console.log(wos);
      this.workordersData = wos;
      this.loading.dismiss();
    });
  }


  ionViewDidLoad() {
    this.loadLocation();
  }

  showLoading() {
    this.loading = this.loadingCtrl.create({
      content: 'Please wait...'
    });
    this.loading.present();
  }

  navigate(siteLocation) {
    var startLoc = this.currentLat + ", " + this.currentLng;

    let options: LaunchNavigatorOptions = {
      start: startLoc
    };

    LaunchNavigator.navigate(siteLocation, options)
      .then(
      success => console.log('Launched navigator'),
      error => console.log('Error launching navigator: ' + error)
      );
  }

  openWorkOrderList(statusType:string):void{
    this.navCtrl.push(ViewWOPage,{"statusType":statusType,"siteName":this.navParams.data.siteName});
	}

  gotoHomePage(){
    this.navCtrl.push(WODashboardPage);
  }

}