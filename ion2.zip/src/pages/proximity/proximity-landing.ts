import { Component, ViewChild } from '@angular/core';
import { NavController, Platform, LoadingController, Loading } from 'ionic-angular';

import { Geolocation } from 'ionic-native';
import { ToastService } from '../../providers';
import { ProximityService } from '../../providers/proximity/proximity.service';
import { ProximityDetailsPage } from '../../pages/proximity/proximity-detail';

declare var google: any;

@Component({
  selector: 'page-proximity',
  templateUrl: 'proximity-landing.html',
  providers: [Geolocation, ProximityService]
})

export class ProximityPage {
  loading: Loading;
  @ViewChild('map') map;

  constructor(public navCtrl: NavController, public platform: Platform, 
  private loadingCtrl: LoadingController, private proximity: ProximityService,
  private toastService:ToastService) {
    //this.loadCustomers();
  }

  currentLat: any;
  currentLng: any;
  siteAssetsData: any[] = [];

  geolocationEnabled: boolean = true;

  public getNearBySites() {

    if (navigator.geolocation) {
      console.log("location enabled.");
      this.showLoading();
      navigator.geolocation.getCurrentPosition(success => {
         
        console.log("location got successfully.");
        this.currentLat = success.coords.latitude;
        this.currentLng = success.coords.longitude;
        this.siteAssetsData = this.getComputeAllData();
        
      }, error => {
        console.log("location failed.");
        this.loading.dismiss();
        this.toastService.showToast("bottom","Failed to get current location");
        this.geolocationEnabled = false;
        console.log("error");

      }, options => {
        console.log("options");
      });
      this.loading.dismiss();

    }

    if(this.siteAssetsData.length == 0){
        console.log("location not enabled.", this.siteAssetsData);
        this.geolocationEnabled = false;
       // this.toastService.showToast("bottom", "Location not enabled.");
      }


  }

  getComputeAllData(): any {
    let siteAssetsData = [];
    this.showLoading();
    this.proximity.getCustomers().take(1).subscribe(customers => {
      console.log("customers");
      customers.forEach((cust) => {

        cust.sites.forEach(site => {

          var distance: number = this.computeDistanceBetweenTwoPoints(this.currentLat, this.currentLng, site.mailingAddress.latitude, site.mailingAddress.longitude);
          
            siteAssetsData.push({
              id: site.id,
              equipments: site.equipments,
              distance: Math.round(distance),
              siteName: site.siteName,
              street1: site.mailingAddress.street1,
              street2: site.mailingAddress.street2,
              city: site.mailingAddress.city,
              state: site.mailingAddress.state,
              country: site.mailingAddress.country,
              postCode: site.mailingAddress.postCode,
              customerId: cust.id,
              currentLatitude: this.currentLat,
              currentLongitude: this.currentLng,
              siteLocation: [site.mailingAddress.latitude, site.mailingAddress.longitude]
            });

        });

      });
      this.loading.dismiss();
    });

    return siteAssetsData;

  }

  computeDistanceBetweenTwoPoints(lat1, lon1, lat2, lon2): number {
        var toRad = (val) => val * Math.PI / 180;
        var R = 6371 | 0, // Radius of the earth 6371 km
          dLat = toRad(lat2 - lat1),
          dLon = toRad(lon2 - lon1);
        var a = Math.sin(dLat / 2) * Math.sin(dLat / 2) + Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLon / 2) * Math.sin(dLon / 2);
        var c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        console.log("c", c);
        return R * c;
      };

  ionViewDidLoad() {
    this.getNearBySites();
  }

  openSiteDetails(site) {
    console.log("njkn");
    this.navCtrl.push(ProximityDetailsPage, site);
  }

  showLoading() {
    this.loading = this.loadingCtrl.create({
      content: 'Please wait...'
    });
    this.loading.present();
  }

}