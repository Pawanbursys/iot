import { Component } from '@angular/core';
import { NavController, NavParams, Loading, LoadingController } from 'ionic-angular';
import { AddWODetailsPage } from '../add-wo-details/add-wo-details';


import { AccountService, WorkOrderService, ToastService, CatalogService, WorkOrder, Account, WorkOrderItem } from '../../../providers';


/*
  Generated class for the Add Service in WO.

  See http://ionicframework.com/docs/v2/components/#navigation for more info on
  Ionic pages and navigation.
*/
@Component({
	selector: 'add-service',
	templateUrl: 'add-service.html'
})

export class AddServicePage {

	public account: Account;
	private workOrder: WorkOrder;


	private serviceList = [];
	private finalServiceList = [];
	private checked: any[] = [];
	private workOrderItems = [];
	private clonedServiceList: any[] = [];

	private page = 0;
	private records = 20;
	public itemNumber: string;
	loading: Loading;

	constructor(private accountService: AccountService,
		public navCtrl: NavController,
		public navParams: NavParams,
		private catalogService: CatalogService,
		private toastService: ToastService,
		private workOrderService: WorkOrderService,
		private loadingCtrl: LoadingController) {

		this.accountService.getAccount().subscribe(response => {
			this.account = response;
		}, error => {
			this.toastService.showToast("bottom", "Not Found.");
		});

		let woId = navParams.get('id');

		this.showLoading();
		this.workOrderService.getWorkOrderDetails(woId).take(1).subscribe(wo => {
			this.loading.dismiss();
			this.workOrder = wo;
			for (let woItem of this.workOrder.workOrderItems) {
				if (woItem.itemType == 'SERVICE') {
					this.workOrderItems.push(woItem);
				}
			}
			this.loadService();
		}, error => {
			this.toastService.showToast("bottom", "Not found.");
		})
	}


	showLoading() {
		this.loading = this.loadingCtrl.create({
			content: 'Please wait...'
		});
		this.loading.present();
	}

	//*********Get Service list in page********//

	loadService() {
		return new Promise(resolve => {
			this.showLoading();
			this.catalogService.getItemList(this.account, this.page, this.records, 'SERVICE').subscribe(serviceList => {
				this.loading.dismiss();
				this.finalServiceList = [];
				this.serviceList = [];

				for (let service of serviceList) {
					this.serviceList.push(service);
				}


				let serviceToDelete = [];

				for (let service of this.serviceList) {
					for (let woItem of this.workOrderItems) {
						if (woItem.itemNumber == service.vendorItemNumber) {
							serviceToDelete.push(service);
						}
					}
				}


				if (serviceToDelete.length > 0) {
					for (let service of serviceToDelete) {
						var index = this.serviceList.indexOf(service);
						if (index >= 0) {
							this.serviceList.splice(index, 1);
						}
					}
				}

				for (let service of this.serviceList) {
					this.finalServiceList.push(service);
				}
				console.log("finalServiceList:: ", this.finalServiceList);

				resolve(true);
			}, error => {
				this.toastService.showToast("bottom", "Unable to fetch data.");
				this.navCtrl.pop(AddServicePage);
			});
		});
	}


	//called when scrolled
	doInfinite(infiniteScroll: any) {
		this.records += 20;
		this.page + 1;
		console.log('doInfinite, records is currently ' + this.records + ' and page at ' + this.page);

		if (this.itemNumber) {
			this.searchItem(this.itemNumber).then(() => {
				infiniteScroll.complete();
			});
		} else {
			this.loadService().then(() => {
				infiniteScroll.complete();
			});

		}

	}


	addServiceItem(item, index) {
		console.log('checked', this.checked);
		let service = this.finalServiceList[index];

		let serviceItem = new WorkOrderItem();
		serviceItem.itemType = service.itemType;
		serviceItem.itemNumber = service.vendorItemNumber;
		serviceItem.description = service.description;
		serviceItem.listPrice = service.listPrice;
		serviceItem.itemNotes = service.itemNotes;
		serviceItem.itemQty = service.quantity;
		serviceItem.warehouses = service.warehouses;
		serviceItem.qtyOnHands = service.qtyOnHands;
		serviceItem.costPrice = service.costPrice;
		serviceItem.siteAsset = this.workOrder.machine;
		serviceItem.unitRate = service.unitRate;
		serviceItem.unitRateType = service.unitRateType;


		if (this.checked[index] == true) {
			this.workOrder.workOrderItems.push(serviceItem);
		} else {

			var delIndex = -1;

			this.workOrder.workOrderItems.forEach(item => {
				if (item.itemNumber == service.vendorItemNumber) {
					delIndex = this.workOrder.workOrderItems.indexOf(item);
					console.log('delIndex', delIndex);
					if (delIndex >= 0) {
						this.workOrder.workOrderItems.splice(delIndex, 1);
					}
				}

			});

			console.log(this.workOrder.workOrderItems);
		}
	}


	//************** Save Service Item Start********************//

	saveServiceItems(): void {
		console.log(this.workOrder);
		this.showLoading();
		this.workOrderService.updateWO(this.workOrder).subscribe(wo => {
			this.loading.dismiss();
			this.toastService.showToast("bottom", "Service(s) added to the Work order!");
			this.navCtrl.push(AddWODetailsPage, { id: wo.id });
		}, error => {
			this.loading.dismiss();
			this.toastService.showToast("bottom", "Error while adding Service to Work order!");
		});
	}




	//************** Save Service Item End********************//


	//search items
	searchItem(itemNumber) {
		return new Promise(resolve => {
			if (itemNumber) {
				this.showLoading();
				this.catalogService.searchItemInCatalog(itemNumber, 'SERVICE', this.account).subscribe(searchedItems => {
					this.loading.dismiss();
					if (searchedItems) {
						this.serviceList = searchedItems;

						this.clonedServiceList = this.finalServiceList.map(x => Object.assign({}, x));
						this.finalServiceList = [];
						let serviceToDelete = [];

						console.log(this.serviceList);

						for (let service of this.serviceList) {
							for (let item of this.workOrderItems) {
								if (item.itemNumber == service.vendorItemNumber) {
									serviceToDelete.push(service);
								}
							}
						}


						for (let service of serviceToDelete) {
							var index = this.serviceList.indexOf(service);
							if (index >= 0) {
								this.serviceList.splice(index, 1);
							}
						}

						for (let service of this.serviceList) {
							this.finalServiceList.push(service);
						}

						console.log("this.finalServiceList", this.finalServiceList);
					} else {
						this.toastService.showToast("bottom", "NO RESULT FOUND");
					}
				}, error => {
					this.loading.dismiss();
					this.toastService.showToast("bottom", "ERROR WHILE FEATCHING SEARCH LIST");
				});
			}
			else {
				if (this.clonedServiceList) {
					this.finalServiceList = this.clonedServiceList.map(x => Object.assign({}, x));
				}
				//if cloned list is emplty
				else {
					this.loadService();
				}
			}
		});
	}

}
