import { Component } from '@angular/core';
import { NavController, NavParams, Platform, Loading, LoadingController } from 'ionic-angular';
import { WorkOrderService} from '../../../providers/index';

import {WorkOrder, AccountService, SiteEquipment, Account, SmartContract, ToastService} from '../../../providers';
import { AddWODetailsPage } from '../add-wo-details/add-wo-details';
import { BarcodeScanner } from 'ionic-native';


/*
  Generated class for the Wo create page.

  See http://ionicframework.com/docs/v2/components/#navigation for more info on
  Ionic pages and navigation.
*/
@Component({
  selector: 'create-wo',
  templateUrl: 'createWO.html'
})
export class CreateWOPage {
  private siteEquipment : SiteEquipment;
  private account :Account;
  private smartContract : SmartContract;
  private barcodeText:string;
  loading: Loading;
  private serviceTag : string;

  private machineStatuses = ['Operational', 'Non-Operational'];
  
  constructor(private accountService:AccountService,
      public navCtrl: NavController,
      public navParams: NavParams,
      private workOrderService : WorkOrderService,
      private toastService:ToastService,
      private platform:Platform,
      private loadingCtrl: LoadingController) {

     this.accountService.getAccount().subscribe(response => {
           this.account=response;
        });
  }


//**************Scan Barcode Start****************//

 onScanServiceBtnClick(){

  console.log("inside method");

   this.platform.ready().then(() => {
     console.log("platform ready");
        BarcodeScanner.scan().then((result) => {
            console.log(result);
            if (!result.cancelled) {
                this.barcodeText = result.text;
				        this.getServiceTagDetails(result.text);
            }
            console.log("Barcode Format -> " + result.format);
        }, (error) => {
            console.log('error when scanning product barcode');
        });
    }); 

		  //  BarcodeScanner.scan().then((result) => {
      //       if (!result.cancelled) {
      //           console.log(result.text);
      //           this.barcodeText = result.text;
			// 	        this.getServiceTagDetails(result.text);
      //       }
			//         console.log("Barcode Format -> " + result.format);
      //      }, (error) => {
      //          console.log('error when scanning item barcode');
      //   });
	}

//**********Scan Barcode End**********************//


  showLoading() {
    this.loading = this.loadingCtrl.create({
      content: 'Please wait...'
    });
    this.loading.present();
  }


    getServiceTagDetails(serviceTag: string) {
      this.showLoading();
    this.workOrderService.getServiceTagDetail(serviceTag).take(1).subscribe(siteAsset=> {
        this.siteEquipment = siteAsset;
        this.siteEquipment.serviceTag = serviceTag;
        this.loading.dismiss();
        this.getMachineSmartContract(this.siteEquipment.id)
    }, error => {
      this.loading.dismiss();
        this.toastService.showToast("bottom","SERVICE TAG NOT FOUND")
    });

  }


  private getMachineSmartContract(machineId: String) {
    this.showLoading();
    this.workOrderService.getMachineSmartContract(machineId).take(1).subscribe(smartContract=> {
          this.smartContract = smartContract;
           this.loading.dismiss();
    }, error => {
        console.log("NO CONTRACT FOUND");
         this.loading.dismiss();
    });
  }

  createWO(siteEquipment){
  
    if(!siteEquipment.machineStatus){
      this.toastService.showToast("bottom","select machine status");
    }else{
      this.showLoading();
      this.workOrderService.saveWO(siteEquipment,this.account,this.smartContract,false).subscribe(wo => {
      this.loading.dismiss();
      this.navCtrl.push(AddWODetailsPage, {id: wo.id});
      this.toastService.showToast("bottom","WO SUCCESSFULLY CREATED");
    },error => {
      this.loading.dismiss();
      if(error.status == '417'){
        this.toastService.showToast("bottom","YOU ARE NOT AUTHORIZED TO CREATE WO");
        return;
      }
      this.toastService.showToast("bottom","ERROR WHILE CREATING WO");
    });
    }
    
    
  }

}
