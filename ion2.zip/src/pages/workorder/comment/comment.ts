import { Component } from '@angular/core';
import { NavController, NavParams, Loading, LoadingController } from 'ionic-angular';
import { WorkOrderService } from '../../../providers/index';

import { WorkOrder, AccountService, SiteEquipment, Account, SmartContract, ToastService, WorkOrderTransaction } from '../../../providers';
import { AddWODetailsPage } from '../add-wo-details/add-wo-details';

/*
  Generated class for the Wo Comment page.

  See http://ionicframework.com/docs/v2/components/#navigation for more info on
  Ionic pages and navigation.
*/
@Component({
  selector: 'comment-wo',
  templateUrl: 'comment.html'
})
export class CommentWOPage {
  loading: Loading;

  private workOrder: WorkOrder; constructor(public navCtrl: NavController,
    public navParams: NavParams, private loadingCtrl: LoadingController,
    private workOrderService: WorkOrderService, private toastService: ToastService) {
    this.workOrder = navParams.get('wo');
    console.log(this.workOrder);
  }


  private comments: string;

  showLoading() {
    this.loading = this.loadingCtrl.create({
      content: 'Please wait...'
    });
    this.loading.present();
  }

  saveComments() {

    console.log(this.comments);
    let workOrderTransaction = new WorkOrderTransaction();

    workOrderTransaction.transactionType = "Comments";
    workOrderTransaction.workOrderId = this.workOrder.id;
    workOrderTransaction.newValue = this.comments;
    this.showLoading();

    this.workOrderService.saveWorkOrderEvent(workOrderTransaction).take(1).subscribe(workOrder => {

      this.loading.dismiss();
      console.log("Wo ::", workOrder);
      this.navCtrl.push(AddWODetailsPage, { id: workOrder.id });
      this.toastService.showToast("bottom", "comment saved successfull !!!");
    }, error => {
      this.loading.dismiss();
      this.toastService.showToast("bottom", "error while saving comment");
    });
  }

}
