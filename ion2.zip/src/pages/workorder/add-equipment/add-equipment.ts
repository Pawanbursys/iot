import { Component } from '@angular/core';
import { NavController, NavParams, Platform, Loading, LoadingController} from 'ionic-angular';
import { AddWODetailsPage } from '../add-wo-details/add-wo-details';
import { BarcodeScanner } from 'ionic-native';


import {AccountService ,WorkOrderService, ToastService, CatalogService, WorkOrder, Account, WorkOrderItem, Warehouse} from '../../../providers';


/*
  Generated class for the Add People in WO.

  See http://ionicframework.com/docs/v2/components/#navigation for more info on
  Ionic pages and navigation.
*/
@Component({
  selector: 'add-equipment',
  templateUrl: 'add-equipment.html'
})

export class AddEquipmentPage {
    private account :Account;
    private workOrder:WorkOrder;
    private warehouse : Warehouse;
	private barcodeText:string;
	private itemNumber:string;

    private workOrderItems:any[]=[];
    private equipmentList : any[]=[];
    private finalEquipmentList :any[]=[];
	private clonedEquipmentList:any[]= [];
	private checked: any[] = [];

	private newWorkOrderItems = [];

    public page = 0;
	public records = 20;
	loading: Loading;


  constructor(private accountService:AccountService,
      public navCtrl: NavController,
      public navParams: NavParams,
      private catalogService : CatalogService,
      private toastService:ToastService,
      private workOrderService: WorkOrderService,
	  private platform : Platform,
	  private loadingCtrl: LoadingController
) {

     this.accountService.getAccount().subscribe(response => {
           this.account=response;
        }, error => {
			this.toastService.showToast("bottom", "Not Found.");
		});

       let woId = navParams.get('id');
       this.getWorkOrder(woId);
  }



  //**************Scan Barcode****************//
 onScanServiceBtnClick(){

  console.log("inside method");

   this.platform.ready().then(() => {
     console.log("platform ready");
        BarcodeScanner.scan().then((result) => {
            console.log(result);
            if (!result.cancelled) {
                this.barcodeText = result.text;
				this.searchItem(result.text);
            }
            console.log("Barcode Format -> " + result.format);
        }, (error) => {
            console.log('error when scanning product barcode');
			this.toastService.showToast("bottom", "NOT FOUND.");
        });
    });
 }

	//*******Search Item Start***********//

	//search items
	searchItem(itemNumber) {
		return new Promise(resolve => {
		if (itemNumber) {
			this.showLoading();
			this.catalogService.searchItemInCatalog(itemNumber, 'EQUIPMENT', this.account).subscribe(searchedItems => {
				 this.loading.dismiss();
				if (searchedItems) { 
				this.equipmentList = searchedItems;
				
				this.clonedEquipmentList = this.finalEquipmentList.map(x => Object.assign({}, x));
				this.finalEquipmentList = [];
			 	let equipmentToDelete = [];

          for (let equipment of this.equipmentList) {
                for(let woItem of this.workOrderItems){
                     	 if(woItem.itemNumber == equipment.vendorItemNumber){
						                 equipmentToDelete.push(equipment);
		 			                }
                      			}
                 		 }


        if(equipmentToDelete.length>0){
            for (let equipment of equipmentToDelete){
                  var index = this.equipmentList.indexOf(equipment);
			              	if(index>=0){
					                 this.equipmentList.splice(index,1);
				                 }
                   }
              }

           for (let equipment of this.equipmentList){
                this.finalEquipmentList.push(equipment);
             }
          	console.log("finalEquipmentList:: ", this.finalEquipmentList);
			}else {
				this.toastService.showToast("bottom", "NO RESULT FOUND");
			}
			}, error => {
			 this.loading.dismiss();
				this.toastService.showToast("bottom", "ERROR WHILE FEATCHING SEARCH LIST");
			});
		}
		else {
			if (this.clonedEquipmentList) {
				this.finalEquipmentList = this.clonedEquipmentList.map(x => Object.assign({}, x));
			}
			else {
				this.loadEquipments();
				}
			}
		});
	}


	//*******Load Equipment Items Start***********//

	loadEquipments() {
		return new Promise(resolve => {
			this.showLoading();
			this.catalogService.getItemList(this.account, this.page, this.records, 'EQUIPMENT').subscribe(equipmentsList => {
			this.loading.dismiss();
			this.finalEquipmentList = [];
			this.equipmentList = [];
				for (let parts of equipmentsList) {
					this.equipmentList.push(parts);
				}

		let equipmentToDelete = [];

          for (let equipment of this.equipmentList) {
                for(let woItem of this.workOrderItems){
                     	 if(woItem.itemNumber == equipment.vendorItemNumber){
						                 equipmentToDelete.push(equipment);
		 			                }
                      			}
                 		 }


        if(equipmentToDelete.length>0){
            for (let equipment of equipmentToDelete){
                  var index = this.equipmentList.indexOf(equipment);
			              	if(index>=0){this.equipmentList.splice(index,1);}
                   }
              }

           for (let equipment of this.equipmentList){
                this.finalEquipmentList.push(equipment);
             }

          	console.log("finalEquipmentList:: ", this.finalEquipmentList);

				resolve(true);
			}, error => {
				this.toastService.showToast("bottom", "Unable to fetch data.");
				//this.navCtrl.pop(AddEquipmentPage);
			});
		});
	}



//get WO details

	getWorkOrder(id: String): void {
		this.showLoading();
		this.workOrderService.getWorkOrderDetails(id).take(1).subscribe(wo => {
			 this.loading.dismiss();
			this.workOrder = wo;
			 for (let woItem of this.workOrder.workOrderItems) {
               if(woItem.itemType == 'EQUIPMENT'){
                 this.workOrderItems.push(woItem);
             }
         }
			this.loadEquipments();
		}, error => {
			 this.loading.dismiss();
			this.toastService.showToast("bottom", "NOT FOUND")
		});
	}


showLoading() {
    this.loading = this.loadingCtrl.create({
      content: 'Please wait...'
    });
    this.loading.present();
  }

	//called when scrolled
	doInfinite(infiniteScroll: any) {
		this.records += 20;
		this.page + 1;
		console.log('doInfinite, records is currently ' + this.records + ' and page at ' + this.page);

		this.loadEquipments().then(() => {
			infiniteScroll.complete();
		});
		

	}


 // called when quntity is added
	addEquipmentItem(item, i) {

		if (this.checked[i]) {
			item.itemQty = 0;
			var equipmentItem = this.getItem(this.workOrder, item);
			
			this.newWorkOrderItems[i] ={};
			this.newWorkOrderItems[i] = equipmentItem;
			this.priceCalculationOnItemChange(this.newWorkOrderItems[i]);
			}else{
		      	this.newWorkOrderItems[i]={};
		  	}
		}

 // called when item qty is added
addQtyToItem(item,i){
	if (this.checked[i]) {
			item.itemQty = +item.itemQty;
			var productItem = this.getItem(this.workOrder, item);
			
			this.newWorkOrderItems[i] ={};
			this.newWorkOrderItems[i] = productItem;
			this.priceCalculationOnItemChange(this.newWorkOrderItems[i]);
		}else{
		      	this.newWorkOrderItems[i]={};
		  }
}


//save equipment items
	saveEquipmentItems() {

	let isQtyGreaterThanZero:boolean = true;	
	console.log("this.newWorkOrderItems",this.newWorkOrderItems);

		let finalWoItems = [];

    this.newWorkOrderItems.forEach(item => {
			if(item.itemNumber){
				finalWoItems.push(item);
				}
    	});

	if(!(finalWoItems.length>0)){
      this.toastService.showToast("bottom","Please select Equipment!");
			return;
		}

		console.log("FINAL::::",finalWoItems);


		finalWoItems.forEach(item => {
			 if(isQtyGreaterThanZero){
				if(item.itemQty==0){
          		this.toastService.showToast("bottom","Enter quantity for item #"+item.itemNumber);
				  isQtyGreaterThanZero = false;
				}else{
					if(this.workOrder.workOrderItems.indexOf(item)<0){
						  this.workOrder.workOrderItems.push(item);
						  isQtyGreaterThanZero = true;
					}
				}
			 }
			});


		if (isQtyGreaterThanZero) {
			this.showLoading();
			this.workOrderService.updateWO(this.workOrder).subscribe(wo => {
				 this.loading.dismiss();
				this.toastService.showToast("bottom", "Equipment(s) added to the Work order!");
				this.navCtrl.push(AddWODetailsPage, {id: wo.id});
			}, error => {
				 this.loading.dismiss();
				this.toastService.showToast("bottom", "Error while adding Equipment to Work order!");
			});
		}
	}


//************** Save Equipment Item End********************//






  //************** Calculate Price **********************

	getItem(target,catItem){
		let item={
				itemType : catItem.itemType,
				itemNumber : catItem.vendorItemNumber,
				description : catItem.description,
				listPrice : catItem.listPrice,
				itemNotes : catItem.itemNotes,
				itemQty : catItem.itemQty,
				warehouses : [],
				qtyOnHands : [],
				costPrice: catItem.costPrice,
				billable:"Yes",
				siteAsset: target.machine,
				unitRate: catItem.unitRate,
				unitRateType: catItem.unitRateType,
        		contractName:target.contractName,
        		price:target.price,
        		contractPrice:target.contractPrice

		};


		if(target.contract && target.contract.type=="T & M support contract"){

			var smartCoractItemTemp=null;

		if(target.contract.smartContractItems){
        target.contract.smartContractItems.forEach(smartContractItem => {
          	if(smartContractItem.vendorItemNumber==catItem.vendorItemNumber){
						smartCoractItemTemp=smartContractItem;
						this.checkAndSetSmartItemContract(smartContractItem,item,target)
					}
        });
			}

			if(!smartCoractItemTemp){
				this.checkAndSetOtherContract(target,catItem,item)
			}
		}else if(target.contract && target.contract.type=="Fixed service contract"){
			item.contractName=target.contract.type;
			this.checkAndSetOtherContract(target,catItem,item)
		}

		if(!target.totalPrice){
			target.totalPrice=0;
		}

		if(!item.contractPrice && (item.itemType=="PEOPLE" || item.itemType=="SERVICE")){
			item.price=item.listPrice;
			target.totalPrice=target.totalPrice+Number(item.price);
		}

		return item;

	}


checkAndSetSmartItemContract(smartContractItem,item,target){
		if(smartContractItem.addOnCostPrice){
			item.addOnCostPrice=true;
			item.addOnCostPriceValue=smartContractItem.addOnCostPriceValue;
			item.billable="Yes";
			this.calculateAddOnCostPrice(item);
			item.contractName=target.contract.type;

		}else if( smartContractItem.discountOnListPrice){
			item.discountOnListPrice=true;
			item.discountOnListPriceValue=smartContractItem.discountOnListPriceValue;
			item.billable="Yes";
			this.calculateDiscountOnListPrice(item);
			item.contractName=target.contract.type;
		}
	}


calculateAddOnCostPrice(item){
		if(item.billable=="Yes" && item.costPrice){
			var price =item.costPrice*(Number(item.addOnCostPriceValue)/100)
			item.contractPrice=Number(item.listPrice)	+	price;
			if(item.itemType=="PEOPLE" || item.itemType=="SERVICE"){
				item.price=item.contractPrice;
			}
		}
	}

calculateDiscountOnListPrice(item){
		if(item.billable=="Yes" && item.listPrice){
			var price =item.listPrice*(Number(item.discountOnListPriceValue)/100)
			item.contractPrice=Number(item.listPrice)	-	price;
			if(item.itemType=="PEOPLE" || item.itemType=="SERVICE"){
				item.price=item.contractPrice;
			}
		}
	}


  checkAndSetOtherContract(target,catItem,item){
    target.contract.contractOtherDetails.forEach(otherContract => {

			let contractItemType=otherContract.name.toLowerCase();

			let catItemType=catItem.itemType.toLowerCase();

			let isManufactured="yes";
			if(catItem.manufactured){
				isManufactured=catItem.manufactured.toLowerCase();
			}


			if(contractItemType=="manufactured parts" && catItemType=="equipment" && isManufactured=="yes" && (otherContract.coveredInTM || otherContract.coveredInFP)){
				item.coveredUndercontact=true;
				item.billable="No";
				item.contractName=target.contract.type;

			}else if(contractItemType=="manufactured parts" && catItemType=="equipment" && isManufactured=="yes"  && otherContract.addOnCostPrice){
				item.addOnCostPrice=true;
				item.addOnCostPriceValue=otherContract.addOnCostPriceValue;
				this.calculateAddOnCostPrice(item);
				item.contractName=target.contract.type;

			}else if(contractItemType=="manufactured parts" && catItemType=="equipment" && isManufactured=="yes" && otherContract.discountOnListPrice){
				item.discountOnListPrice=true;
				item.discountOnListPriceValue=otherContract.discountOnListPriceValue;
				this.calculateDiscountOnListPrice(item);
				item.contractName=target.contract.type;

			}else if(contractItemType=="procured parts" && catItemType=="equipment" && isManufactured=="no"  && (otherContract.coveredInTM || otherContract.coveredInFP)){
				item.coveredUndercontact=true;
				item.billable="No";
				item.contractName=target.contract.type;

			}else if(contractItemType=="procured parts" && catItemType=="equipment" && isManufactured=="no" && otherContract.addOnCostPrice){
				item.addOnCostPrice=true;
				item.addOnCostPriceValue=otherContract.addOnCostPriceValue;
				this.calculateAddOnCostPrice(item);
				item.contractName=target.contract.type;

			}else if(contractItemType=="procured parts" && catItemType=="equipment" && isManufactured=="no" && otherContract.discountOnListPrice){
				item.discountOnListPrice=true;
				item.discountOnListPriceValue=otherContract.discountOnListPriceValue;
				this.calculateDiscountOnListPrice(item);
				item.contractName=target.contract.type;

			}else if(contractItemType==catItemType && (otherContract.coveredInTM || otherContract.coveredInFP)){
				item.coveredUndercontact=true;
				item.billable="No";
				item.contractName=target.contract.type;

			}else if(contractItemType==catItemType &&  otherContract.addOnCostPrice){
				item.addOnCostPrice=true;
				item.addOnCostPriceValue=otherContract.addOnCostPriceValue;
				this.calculateAddOnCostPrice(item);
				item.contractName=target.contract.type;

			}else if(contractItemType==catItemType &&  otherContract.discountOnListPrice){
				item.discountOnListPrice=true;
				item.discountOnListPriceValue=otherContract.discountOnListPriceValue;
				this.calculateDiscountOnListPrice(item);
				item.contractName=target.contract.type;
			}
		});
	}

priceCalculationOnItemChange(wOItem){
		console.log(wOItem);
		var itemQty=1;

		if(wOItem.itemType=='PRODUCT' || wOItem.itemType=='EQUIPMENT'){
			itemQty=wOItem.itemQty;
		}

		if(wOItem.billable==='No' || !itemQty || !wOItem.listPrice){
			wOItem.price=0;
			return;
		}

		var price=0;
		if(wOItem.contractPrice){
			price=wOItem.contractPrice;
		}else{
			price=wOItem.listPrice;
		}


		wOItem.price=Number(itemQty)*Number(price);


		if(wOItem.discount && Number(wOItem.discount)<=100){
			wOItem.price=wOItem.price-(wOItem.price*(Number(wOItem.discount)/100));
		}

	}

	calculateTotalPrice(finalEquipmentList){

		if (finalEquipmentList.length==0 || finalEquipmentList==null)
			return 0;

		  this.workOrder.totalPrice = 0;


      finalEquipmentList.forEach(woItem => {
      	  var price = woItem.price==null ? 0 : woItem.price;
			    this.workOrder.totalPrice = this.workOrder.totalPrice + Number(price);

    });
	}

	//******************************


  }
	