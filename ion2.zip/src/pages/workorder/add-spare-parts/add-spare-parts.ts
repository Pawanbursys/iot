import { Component } from '@angular/core';
import { NavController, NavParams, Platform, Loading, LoadingController } from 'ionic-angular';
import { AddWODetailsPage } from '../add-wo-details/add-wo-details';
import { BarcodeScanner } from 'ionic-native';

import {WorkOrder, AccountService, Account, ToastService, CatalogService, WorkOrderService, WorkOrderItem, CustomerVendorPartMap, Warehouse} from '../../../providers';


/*
  Generated class for the Add Spare Parts in WO.

  See http://ionicframework.com/docs/v2/components/#navigation for more info on
  Ionic pages and navigation.
*/
@Component({
  selector: 'add-spare-parts',
  templateUrl: 'add-spare-parts.html'
})

export class AddSparePartsPage {
    private account :Account;
    private workOrder:WorkOrder;
    private warehouse : Warehouse;
	private barcodeText:string;

    private workOrderItems:any[]=[];
    private productList : any[]=[];
    private finalProductList :any[]=[];
	private clonedProductList: any[] = [];
	private newWorkOrderItems = [];
	private checked: any[] = [];

    private page = 0;
	private records = 20;
	private itemNumber:string;
	loading: Loading;
	
  constructor(private accountService:AccountService,
      public navCtrl: NavController,
      public navParams: NavParams,
      private catalogService : CatalogService,
      private toastService:ToastService,
      private workOrderService: WorkOrderService,
	  private platform:Platform,
	  private loadingCtrl: LoadingController) {

     this.accountService.getAccount().subscribe(response => {
           this.account=response;
        },error => {
			this.toastService.showToast("bottom", "Not Found.");
		});

       let woId = navParams.get('id');
	  
       this.getWorkOrder(woId);
  }


//**************Scan Barcode****************//

 onScanServiceBtnClick(){

  console.log("inside method");

   this.platform.ready().then(() => {
     console.log("platform ready");
        BarcodeScanner.scan().then((result) => {
            console.log(result);
            if (!result.cancelled) {
                this.barcodeText = result.text;
				this.searchItem(result.text);
            }
            console.log("Barcode Format -> " + result.format);
        }, (error) => {
            console.log('error when scanning product barcode');
			this.toastService.showToast("bottom", "NOT FOUND.");
        });
    });
 }


	//*******Search Item Start***********//

	searchItem(itemNumber) {
		return new Promise(resolve => {
		if (itemNumber) {
			this.showLoading();
			this.catalogService.searchItemInCatalog(itemNumber, 'PRODUCT', this.account).subscribe(searchedItems => {
				 this.loading.dismiss();
				if (searchedItems) { 
				this.productList = searchedItems;
				
				this.clonedProductList = this.finalProductList.map(x => Object.assign({}, x));
				this.finalProductList = [];
			 	let productToDelete = [];

          for (let product of this.productList) {
                for(let woItem of this.workOrderItems){
                     	 if(woItem.itemNumber == product.vendorItemNumber){
						                 productToDelete.push(product);
		 			                }
                     			 }
                 		 	}


        if(productToDelete.length>0){
            for (let product of productToDelete){
                  var index = this.productList.indexOf(product);
			              	if(index>=0){
					                 this.productList.splice(index,1);
				                 }
                  		 	}
              			}

           for (let product of this.productList){
                	this.finalProductList.push(product);
             	}
        	  	console.log("finalProductList:: ", this.finalProductList);
			}else {
				this.toastService.showToast("bottom", "NO RESULT FOUND");
			}
		}, error => {
			 	this.loading.dismiss();
				this.toastService.showToast("bottom", "ERROR WHILE FEATCHING SEARCH LIST");
			});
		}
		//get items directly from cloned list(no need to request from server)
		else {
			if (this.clonedProductList) {
				this.finalProductList = this.clonedProductList.map(x => Object.assign({}, x));
			}
			//if cloned list is emplty
			else {
				this.loadSpareParts();
			}
		}
	});
	}



  showLoading() {
    this.loading = this.loadingCtrl.create({
      content: 'Please wait...'
    });
    this.loading.present();
  }

	//*******Load Product Items Start***********//

	loadSpareParts() {
		return new Promise(resolve => {
			this.showLoading();
			this.catalogService.getItemList(this.account, this.page, this.records, 'PRODUCT').subscribe(productsList => {
				this.loading.dismiss();
				this.finalProductList = [];
				this.productList = [];
				for (let parts of productsList) {
					this.productList.push(parts);
				}


		let productToDelete = [];

          for (let product of this.productList) {
                for(let woItem of this.workOrderItems){
                     	 if(woItem.itemNumber == product.vendorItemNumber){
						                 productToDelete.push(product);
		 			                }
                    		  }
                 		 }


        if(productToDelete.length>0){
            for (let product of productToDelete){
                  var index = this.productList.indexOf(product);
			              	if(index>=0){
					                 this.productList.splice(index,1);
				                 }
                  		 }
              		}

           for (let product of this.productList){
                this.finalProductList.push(product);
             }

         	 console.log("finalProductList:: ", this.finalProductList);

				resolve(true);
			}, error => {
				this.toastService.showToast("bottom", "Not Found.");
			});
		});
	}



//get WO details

	getWorkOrder(id: String): void {
		 this.showLoading()
		this.workOrderService.getWorkOrderDetails(id).take(1).subscribe(wo => {
			this.loading.dismiss();
			this.workOrder = wo;
			console.log(this.workOrder);

			 for (let woItem of this.workOrder.workOrderItems) {
               if(woItem.itemType == 'PRODUCT'){
                 this.workOrderItems.push(woItem);
             }
         }
			this.loadSpareParts();
		}, error => {
			this.loading.dismiss();
			this.toastService.showToast("bottom", "Unable to fetch data.")
		});
	}

	//called when scrolled
	doInfinite(infiniteScroll: any) {
		this.records += 20;
		this.page+1;
		console.log('doInfinite, records is currently ' + this.records + ' and page at ' + this.page);

		if(this.itemNumber){
			this.searchItem(this.itemNumber).then(() => {
			infiniteScroll.complete();
		});
		}else{
		this.loadSpareParts().then(() => {
			infiniteScroll.complete();
		});

		}

	}


 // called when check box is clicked
	addProductItem(item, i) {

		if (this.checked[i]) {
			item.itemQty = 0;
			var productItem = this.getItem(this.workOrder, item);
			
			this.newWorkOrderItems[i] ={};
			this.newWorkOrderItems[i] = productItem;
			this.priceCalculationOnItemChange(this.newWorkOrderItems[i]);
		}else{
		      	this.newWorkOrderItems[i]={};
		  }
	}

 // called when item qty is added
addQtyToItem(item,i){
	if (this.checked[i]) {
			item.itemQty = +item.itemQty;
			var productItem = this.getItem(this.workOrder, item);
			
			this.newWorkOrderItems[i] ={};
			this.newWorkOrderItems[i] = productItem;
			this.priceCalculationOnItemChange(this.newWorkOrderItems[i]);
		}else{
		      	this.newWorkOrderItems[i]={};
		  }
}

//save product items
	saveProductItems() {

	let isQtyGreaterThanZero:boolean = true;
	console.log("this.newWorkOrderItems",this.newWorkOrderItems);

		let finalWoItems = [];

    this.newWorkOrderItems.forEach(item => {
			if(item.itemNumber){
				finalWoItems.push(item);
				}
    	});

	if(!(finalWoItems.length>0)){
      this.toastService.showToast("bottom","Please select Product!");
			return;
		}

		console.log("FINAL::::",finalWoItems);


		finalWoItems.forEach(item => {
			if(isQtyGreaterThanZero){
				if(item.itemQty==0){
					this.toastService.showToast("bottom","Enter quantity for item #"+item.itemNumber);
					isQtyGreaterThanZero = false;
					
					}else{
						if(this.workOrder.workOrderItems.indexOf(item)<0){
							this.workOrder.workOrderItems.push(item);
							isQtyGreaterThanZero = true;
						}
					}
			}
			});

			

		if (isQtyGreaterThanZero) {
			this.showLoading();
			this.workOrderService.updateWO(this.workOrder).subscribe(wo => {
				this.loading.dismiss();
				this.toastService.showToast("bottom", "Product(s) added to the Work order!");
				this.navCtrl.push(AddWODetailsPage, {id: wo.id});
			}, error => {
				this.loading.dismiss();
				this.toastService.showToast("bottom", "Error while adding Product to Work order!");
			});
		}
	}


  //************** Calculate Price **********************

	getItem(target,catItem){
		let item={
				itemType : catItem.itemType,
				itemNumber : catItem.vendorItemNumber,
				description : catItem.description,
				listPrice : catItem.listPrice,
				itemNotes : catItem.itemNotes,
				itemQty : catItem.itemQty,
				warehouses : [],
				qtyOnHands : [],
				costPrice: catItem.costPrice,
				billable:"Yes",
				siteAsset: target.machine,
				unitRate: catItem.unitRate,
				unitRateType: catItem.unitRateType,
        contractName:target.contractName,
        price:target.price,
        contractPrice:target.contractPrice


		};


		if(target.contract && target.contract.type=="T & M support contract"){

			var smartCoractItemTemp=null;

			if(target.contract.smartContractItems){
        target.contract.smartContractItems.forEach(smartContractItem => {
          	if(smartContractItem.vendorItemNumber==catItem.vendorItemNumber){
						smartCoractItemTemp=smartContractItem;
						this.checkAndSetSmartItemContract(smartContractItem,item,target)
					}
        	});
			}

			if(!smartCoractItemTemp){
				this.checkAndSetOtherContract(target,catItem,item)
			}
		}else if(target.contract && target.contract.type=="Fixed service contract"){
			item.contractName=target.contract.type;
			this.checkAndSetOtherContract(target,catItem,item)
		}

		if(!target.totalPrice){
			target.totalPrice=0;
		}

		if(!item.contractPrice && (item.itemType=="PEOPLE" || item.itemType=="SERVICE")){
			item.price=item.listPrice;
			target.totalPrice=target.totalPrice+Number(item.price);
		}

		return item;

	}


checkAndSetSmartItemContract(smartContractItem,item,target){
		if(smartContractItem.addOnCostPrice){
			item.addOnCostPrice=true;
			item.addOnCostPriceValue=smartContractItem.addOnCostPriceValue;
			item.billable="Yes";
			this.calculateAddOnCostPrice(item);
			item.contractName=target.contract.type;

		}else if( smartContractItem.discountOnListPrice){
			item.discountOnListPrice=true;
			item.discountOnListPriceValue=smartContractItem.discountOnListPriceValue;
			item.billable="Yes";
			this.calculateDiscountOnListPrice(item);
			item.contractName=target.contract.type;
		}
	}


calculateAddOnCostPrice(item){
		if(item.billable=="Yes" && item.costPrice){
			var price =item.costPrice*(Number(item.addOnCostPriceValue)/100)
			item.contractPrice=Number(item.listPrice)	+	price;
			if(item.itemType=="PEOPLE" || item.itemType=="SERVICE"){
				item.price=item.contractPrice;
			}
		}
	}

calculateDiscountOnListPrice(item){
		if(item.billable=="Yes" && item.listPrice){
			var price =item.listPrice*(Number(item.discountOnListPriceValue)/100)
			item.contractPrice=Number(item.listPrice)	-	price;
			if(item.itemType=="PEOPLE" || item.itemType=="SERVICE"){
				item.price=item.contractPrice;
			}
		}
	}


  checkAndSetOtherContract(target,catItem,item){
    target.contract.contractOtherDetails.forEach(otherContract => {

			let contractItemType=otherContract.name.toLowerCase();

			let catItemType=catItem.itemType.toLowerCase();

			let isManufactured="yes";
			if(catItem.manufactured){
				isManufactured=catItem.manufactured.toLowerCase();
			}


			if(contractItemType=="manufactured parts" && catItemType=="product" && isManufactured=="yes" && (otherContract.coveredInTM || otherContract.coveredInFP)){
				item.coveredUndercontact=true;
				item.billable="No";
				item.contractName=target.contract.type;

			}else if(contractItemType=="manufactured parts" && catItemType=="product" && isManufactured=="yes"  && otherContract.addOnCostPrice){
				item.addOnCostPrice=true;
				item.addOnCostPriceValue=otherContract.addOnCostPriceValue;
				this.calculateAddOnCostPrice(item);
				item.contractName=target.contract.type;

			}else if(contractItemType=="manufactured parts" && catItemType=="product" && isManufactured=="yes" && otherContract.discountOnListPrice){
				item.discountOnListPrice=true;
				item.discountOnListPriceValue=otherContract.discountOnListPriceValue;
				this.calculateDiscountOnListPrice(item);
				item.contractName=target.contract.type;

			}else if(contractItemType=="procured parts" && catItemType=="product" && isManufactured=="no"  && (otherContract.coveredInTM || otherContract.coveredInFP)){
				item.coveredUndercontact=true;
				item.billable="No";
				item.contractName=target.contract.type;

			}else if(contractItemType=="procured parts" && catItemType=="product" && isManufactured=="no" && otherContract.addOnCostPrice){
				item.addOnCostPrice=true;
				item.addOnCostPriceValue=otherContract.addOnCostPriceValue;
				this.calculateAddOnCostPrice(item);
				item.contractName=target.contract.type;

			}else if(contractItemType=="procured parts" && catItemType=="product" && isManufactured=="no" && otherContract.discountOnListPrice){
				item.discountOnListPrice=true;
				item.discountOnListPriceValue=otherContract.discountOnListPriceValue;
				this.calculateDiscountOnListPrice(item);
				item.contractName=target.contract.type;

			}else if(contractItemType==catItemType && (otherContract.coveredInTM || otherContract.coveredInFP)){
				item.coveredUndercontact=true;
				item.billable="No";
				item.contractName=target.contract.type;

			}else if(contractItemType==catItemType &&  otherContract.addOnCostPrice){
				item.addOnCostPrice=true;
				item.addOnCostPriceValue=otherContract.addOnCostPriceValue;
				this.calculateAddOnCostPrice(item);
				item.contractName=target.contract.type;

			}else if(contractItemType==catItemType &&  otherContract.discountOnListPrice){
				item.discountOnListPrice=true;
				item.discountOnListPriceValue=otherContract.discountOnListPriceValue;
				this.calculateDiscountOnListPrice(item);
				item.contractName=target.contract.type;
			}
		});
	}

priceCalculationOnItemChange(wOItem){
		console.log(wOItem);
		var itemQty=1;

		if(wOItem.itemType=='PRODUCT' || wOItem.itemType=='EQUIPMENT'){
			itemQty=wOItem.itemQty;
		}

		if(wOItem.billable==='No' || !itemQty || !wOItem.listPrice){
			wOItem.price=0;
			return;
		}

		var price=0;
		if(wOItem.contractPrice){
			price=wOItem.contractPrice;
		}else{
			price=wOItem.listPrice;
		}


		wOItem.price=Number(itemQty)*Number(price);


		if(wOItem.discount && Number(wOItem.discount)<=100){
			wOItem.price=wOItem.price-(wOItem.price*(Number(wOItem.discount)/100));
		}

	}

	calculateTotalPrice(finalProductList){

		if (finalProductList.length==0 || finalProductList==null)
			return 0;

		  this.workOrder.totalPrice = 0;


      finalProductList.forEach(woItem => {
      	  var price = woItem.price==null ? 0 : woItem.price;
			    this.workOrder.totalPrice = this.workOrder.totalPrice + Number(price);

    });
	}

	//******************************


  }

