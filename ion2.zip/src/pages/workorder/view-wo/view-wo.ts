import { Component } from '@angular/core';
import { NavController, NavParams, Loading, LoadingController } from 'ionic-angular';
import { WorkOrder, Account, WorkOrderService, JobStatus, AccountService, ToastService, WorkOrderTransaction } from '../../../providers'
import { WODetailPage } from '../detail/wo-detail';
import { CreateWOPage } from '../createWO/createWO';
import { TranslateService } from 'ng2-translate';
import { AddWODetailsPage } from '../add-wo-details/add-wo-details';


/*
  Generated class for the viwe Work Order page.

  See http://ionicframework.com/docs/v2/components/#navigation for more info on
  Ionic pages and navigation.
*/
@Component({
	selector: 'view-wo-page',
	templateUrl: 'view-wo.html',
})
export class ViewWOPage {
	private account: Account;
	private siteName: string;
	private statusType: string;

	private eta: string;
	private reason: string;
	private showFullDescription: string;
	private isAreaManager: boolean;
	private isAdmin: boolean;
	private isCustomerAdmin: boolean;
	private isVendorTech: boolean;
	loading: Loading;



	constructor(public accountService: AccountService, public navCtrl: NavController,
		public navParams: NavParams, private workOrderService: WorkOrderService,
		private toastService: ToastService,
		private loadingCtrl: LoadingController) {

		this.statusType = navParams.get('statusType');
		this.siteName = navParams.get('siteName');

		this.loadCurrentWorkOrders();
		this.loadAccountDetails(accountService);
	}


	showLoading() {
		this.loading = this.loadingCtrl.create({
			content: 'Please wait...'
		});
		this.loading.present();
	}

	loadAccountDetails(accountService) {
		this.showLoading();

		accountService.getAccount().subscribe(response => {
			this.loading.dismiss();
			this.account = response;
		}, error => {
			this.toastService.showToast("bottom", "Not found.");
		});

		this.isAreaManager = this.account.authorities.indexOf('AREA_MANAGER') > -1;
		this.isAdmin = this.account.authorities.indexOf('VENDOR_SYSTEM_ADMIN') > -1;
		this.isCustomerAdmin = this.account.authorities.indexOf('CUSTOMER_ADMIN') > -1;
		this.isVendorTech = this.account.authorities.indexOf('VENDOR_TECHNICIAN') > -1;
	}

	private isExpanded = true;
	private reloadPage = 0;


	private limit = 10;
	private disableScroller = true;

	private workOrders: any[] = [];
	private workOrderData: any[] = [];



	//**********Load All Work Orders Start************************//

	private loadCurrentWorkOrders() {
		this.showLoading();
		this.workOrderService.getWorkOrders().take(1).subscribe(workOrders => {
			this.loading.dismiss();
			this.workOrders = workOrders;
			console.log(this.workOrders);
			if (this.siteName && this.statusType) {
				if (this.statusType == 'Started') {
					workOrders.forEach(workOrder => {
						if (workOrder.jobStatus.toUpperCase() === this.statusType.toUpperCase()) {
							if (workOrder.site.siteName.toUpperCase() === this.siteName.toUpperCase()) {
								this.workOrderData.push(workOrder);
							}
						}
					});

				} else if (this.statusType == 'Created') {
					workOrders.forEach(workOrder => {
						if (workOrder.jobStatus.toUpperCase() === this.statusType.toUpperCase()) {
							if (workOrder.site.siteName.toUpperCase() === this.siteName.toUpperCase()) {
								this.workOrderData.push(workOrder);
							}
						}
					});
					console.log(this.workOrderData);

				} else if (this.statusType == 'Completed') {
					workOrders.forEach(workOrder => {
						if (workOrder.jobStatus.toUpperCase() === this.statusType.toUpperCase()) {
							if (workOrder.site.siteName.toUpperCase() === this.siteName.toUpperCase()) {
								this.workOrderData.push(workOrder);
							}
						}
					});
				}
			}
			else if (this.statusType) {
				if (this.statusType == 'Started') {
					workOrders.forEach(workOrder => {
						if (workOrder.jobStatus.toUpperCase() === this.statusType.toUpperCase()) {
							this.workOrderData.push(workOrder);
						}
					});
				} else if (this.statusType == 'Created') {
					workOrders.forEach(workOrder => {
						if (workOrder.jobStatus.toUpperCase() === this.statusType.toUpperCase()) {
							this.workOrderData.push(workOrder);
						}
					});
				} else if (this.statusType == 'Suspended') {
					workOrders.forEach(workOrder => {
						if (workOrder.jobStatus.toUpperCase() === this.statusType.toUpperCase()) {
							this.workOrderData.push(workOrder);
						}
					});
				} else if (this.statusType == 'Completed') {
					workOrders.forEach(workOrder => {
						if (workOrder.jobStatus.toUpperCase() === this.statusType.toUpperCase()) {
							this.workOrderData.push(workOrder);
						}
					});
				} else if (this.statusType == 'Approved') {
					workOrders.forEach(workOrder => {
						if (workOrder.jobStatus.toUpperCase() === this.statusType.toUpperCase()) {
							this.workOrderData.push(workOrder);
						}
					});
				} else {
					workOrders.forEach(workOrder => {
						if (workOrder.machine) {
							if (workOrder.machine.id === this.statusType) {
								this.workOrderData.push(workOrder);
							}
						}
					});
				}
			}
			else {
				this.workOrderData = workOrders;
			}
		}, error => {
			this.toastService.showToast("bottom", "Not found.");
		});
	}

	//**********Load All Work Orders End*******************//




	//**********Proceed Work Order Start*******************//   
	private proceedWo(wo: any) {

		let isAreaManager = this.account.authorities.indexOf('AREA_MANAGER') > -1;
		let isAdmin = this.account.authorities.indexOf('VENDOR_SYSTEM_ADMIN') > -1;
		let isCustomerAdmin = this.account.authorities.indexOf('CUSTOMER_ADMIN') > -1;
		let isVendorTech = this.account.authorities.indexOf('VENDOR_TECHNICIAN') > -1;

		if (isAdmin || isCustomerAdmin || isAreaManager) {
			this.navCtrl.push(AddWODetailsPage, { id: wo.id });
			return 0;
		}

		if (!wo.eta) {
			this.toastService.showToast("bottom", "Please Enter ETA");
			return 0;
		}


		var alreadyAccepted = false;
		var keepGoing = true;

		wo.workOrderTransactions.forEach(obj => {
			if (keepGoing) {
				if (obj.transactionType == 'Accepted') {
					alreadyAccepted = true;
					keepGoing = false;
				}
			}
		});

		if (wo.jobStatus == 'Created' && !alreadyAccepted) {
			let workOrderTransaction = new WorkOrderTransaction();

			workOrderTransaction.transactionType = "Accepted";
			workOrderTransaction.workOrderId = wo.id;
			workOrderTransaction.newValue = wo.eta;

			this.showLoading();
			this.workOrderService.saveWorkOrderEvent(workOrderTransaction).take(1).subscribe(workOrder => {
				this.loading.dismiss();
				console.log("Wo ::", workOrder);
				this.navCtrl.push(AddWODetailsPage, { id: wo.id });
			});
		} else {
			this.loading.dismiss();
			this.navCtrl.push(AddWODetailsPage, { id: wo.id });
		}

	}

	//**********Decline Work Order Start*******************//   

	declineWo(wo) {
		if (!wo.reason) {
			this.toastService.showToast("bottom", "Please enter reason for decline");
			return 0;
		}

		if (wo.jobStatus == 'Created') {
			let workOrderTransaction = new WorkOrderTransaction();

			workOrderTransaction.transactionType = "Declined";
			workOrderTransaction.workOrderId = wo.id;
			workOrderTransaction.newValue = wo.reason;

			this.showLoading();
			this.workOrderService.saveWorkOrderEvent(workOrderTransaction).take(1).subscribe(workOrder => {
				this.loading.dismiss();
				console.log("declined success");
				//$state.reload();
			});

		}
	}



	clearEta(wo) {
		wo.eta = "";
	}

	loadMore() {
		if (this.limit < 100) {
			console.log("SCROLLLLLLLLLLLLLLLLLL")
			this.limit = this.limit + 10;
			// this.$broadcast('scroll.infiniteScrollComplete');
		} else {
			this.disableScroller = false;
		}
	}

	previewWO(woId) {
		this.navCtrl.push(AddWODetailsPage, { id: woId });
	}


}