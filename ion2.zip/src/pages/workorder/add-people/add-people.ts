import { Component } from '@angular/core';
import { NavController, NavParams, Loading, LoadingController  } from 'ionic-angular';
import { AddWODetailsPage } from '../add-wo-details/add-wo-details';


import {AccountService ,WorkOrderService, ToastService, CatalogService, WorkOrder, Account, WorkOrderItem} from '../../../providers';


/*
  Generated class for the Add People in WO.

  See http://ionicframework.com/docs/v2/components/#navigation for more info on
  Ionic pages and navigation.
*/
@Component({
  selector: 'add-people',
  templateUrl: 'add-people.html'
})

export class AddPeoplePage {

    public account : Account;
    private workOrder : WorkOrder;

	
	private peopleList = [];
	private finalPeopleList = [];
	private workOrderItems = [];
	private clonedPeopleList:any[]=[];

	private checked: any[] = [];
	private page = 0;
	private records = 20;
	private itemNumber :string;
	loading: Loading;

constructor(private accountService:AccountService,
      public navCtrl: NavController,
      public navParams: NavParams,
      private catalogService : CatalogService,
      private toastService:ToastService,
      private workOrderService: WorkOrderService,
	   private loadingCtrl: LoadingController) {

     this.accountService.getAccount().subscribe(response => {
           this.account=response;
        }, error => {
			this.toastService.showToast("bottom", "Data not found.");
		});

       let woId = navParams.get('id');


    this.workOrderService.getWorkOrderDetails(woId).take(1).subscribe(wo=> {
             this.workOrder = wo;
        for (let woItem of this.workOrder.workOrderItems) {
               if(woItem.itemType == 'PEOPLE'){
                 this.workOrderItems.push(woItem);
                 }
            }
			    this.loadPeople();
            }, error => {
				this.toastService.showToast("bottom", "Data not found.");
			})
      }


    //*********Get People list in page********//


 showLoading() {
    this.loading = this.loadingCtrl.create({
      content: 'Please wait...'
    });
    this.loading.present();
  }
	loadPeople() {
		return new Promise(resolve => {
			this.showLoading();
			this.catalogService.getItemList(this.account, this.page, this.records, 'PEOPLE').subscribe(peopleList => {
				 this.loading.dismiss();				
				 this.finalPeopleList = [];
				this.peopleList = [];
				for (let people of peopleList) {
					this.peopleList.push(people);
				}


		let peopleToDelete = [];

          for (let people of this.peopleList) {
                for(let woItem of this.workOrderItems){
                     	 if(woItem.itemNumber == people.vendorItemNumber){
						                peopleToDelete.push(people);
		 			                }
                            }
                     }


        if(peopleToDelete.length>0){
            for (let people of peopleToDelete){
                  var index = this.peopleList.indexOf(people);
			              	if(index>=0){
					                 this.peopleList.splice(index,1);
				                 }
                             }
                         }

           for (let people of this.peopleList){
                this.finalPeopleList.push(people);
             }

                console.log("finalPeopleList:: ", this.finalPeopleList);

				resolve(true);
			}, error => {
				this.toastService.showToast("bottom", "Unable to fetch data.");
				this.navCtrl.pop(AddPeoplePage);
			});
		});
	}


	//called when scrolled
	doInfinite(infiniteScroll: any) {
		this.records += 20;
		this.page + 1;
		console.log('doInfinite, records is currently ' + this.records + ' and page at ' + this.page);

		if(this.itemNumber){
			this.searchItem(this.itemNumber).then(() => {
			infiniteScroll.complete();
		});
		}else{
		this.loadPeople().then(() => {
			infiniteScroll.complete();
		});

		}

	}
        



    addPeopleItem(item,index){
		console.log('checked',this.checked);
		let people = this.finalPeopleList[index];

		let peopleItem = new WorkOrderItem();
			peopleItem.itemType = people.itemType;
			peopleItem.itemNumber = people.vendorItemNumber;
			peopleItem.description = people.description;
			peopleItem.listPrice = people.listPrice;
			peopleItem.itemNotes = people.itemNotes;
			peopleItem.itemQty = people.quantity;
			peopleItem.warehouses = people.warehouses;
			peopleItem.qtyOnHands = people.qtyOnHands;
			peopleItem.costPrice = people.costPrice;
			peopleItem.siteAsset = this.workOrder.machine;
			peopleItem.unitRate = people.unitRate;
			peopleItem.unitRateType = people.unitRateType;
		

	 if(this.checked[index] == true){
				this.workOrder.workOrderItems.push(peopleItem);
		} else{
			
			var delIndex = -1;
			
            this.workOrder.workOrderItems.forEach(item => {
				if(item.itemNumber == people.vendorItemNumber){
					delIndex = this.workOrder.workOrderItems.indexOf(item);
					console.log('delIndex',delIndex);
					if(delIndex>=0){
						this.workOrder.workOrderItems.splice(delIndex,1);
					}
				}
			
            });

			console.log(this.workOrder.workOrderItems);
		}
	}


    //************** Save People Item Start********************//

savePeopleItems():void{
		console.log(this.workOrder);
		this.showLoading();

    this.workOrderService.updateWO(this.workOrder).subscribe(wo => {
		 this.loading.dismiss();
        this.toastService.showToast("bottom","People(s) added to the Work order!");
        this.navCtrl.push(AddWODetailsPage, {id: wo.id});
     },error => {
		  this.loading.dismiss();
         this.toastService.showToast("bottom","Error while adding People to Work order!");
        });
	}




    //************** Save People Item End********************//


	//search items
	searchItem(itemNumber) {
		return new Promise(resolve => {
		if (itemNumber) {
			this.showLoading();
			this.catalogService.searchItemInCatalog(itemNumber, 'PEOPLE', this.account).subscribe(searchedItems => {
				 this.loading.dismiss();
				if (searchedItems) { 
				this.peopleList = searchedItems;
				
				this.clonedPeopleList = this.finalPeopleList.map(x => Object.assign({}, x));
				this.finalPeopleList = [];
			 	let peopleToDelete = [];

           for(let people of this.peopleList) {
                for(let item of this.workOrderItems){
                   if(item.itemNumber == people.vendorItemNumber){
						peopleToDelete.push(people);
					} 
                }
             }


			for(let people of peopleToDelete){
                var index = this.peopleList.indexOf(people);
                if(index>=0){
					this.peopleList.splice(index,1);
				}
            }

            for(let people of this.peopleList){
                this.finalPeopleList.push(people);
            }
			
			console.log("this.finalPeopleList",this.finalPeopleList);
			}else {
				this.toastService.showToast("bottom", "NO RESULT FOUND");
			}
		}, error => {
			 	this.loading.dismiss();
				this.toastService.showToast("bottom", "ERROR WHILE FEATCHING SEARCH LIST");
			});
		}
		else {
			if (this.clonedPeopleList) {
				this.finalPeopleList = this.clonedPeopleList.map(x => Object.assign({}, x));
			}
			//if cloned list is emplty
			else {
				this.loadPeople();
				}
			}
		});
	}

}
	