import { Component } from '@angular/core';
import { NavController, NavParams, AlertController, Loading, LoadingController, Platform } from 'ionic-angular';
import { WorkOrderService, WorkOrder, WorkOrderItem, AddPartsPriceCalculationService, ToastService, Account, AccountService, Document } from '../../../providers/index';
import { AddSparePartsPage } from '../add-spare-parts/add-spare-parts';
import { AddPeoplePage } from '../add-people/add-people';
import { AddEquipmentPage } from '../add-equipment/add-equipment';
import { AddServicePage } from '../add-service/add-service';
import { CommentWOPage } from '../comment/comment';
import { Observable } from 'rxjs/Observable';
import { ConfigService } from '../../../providers/config/config.service';
import { AuthHttp } from '../../../providers/index';
import { AddDocumentPage } from '../add-document/add-document';
import { WODashboardPage } from '../dashboard/wo-dashboard'

import { Transfer, TransferObject } from '@ionic-native/transfer';
import { File } from '@ionic-native/file';
import { FileOpener } from '@ionic-native/file-opener';


/*
  Generated class for the Detail page.

  See http://ionicframework.com/docs/v2/components/#navigation for more info on
  Ionic pages and navigation.
*/
declare var cordova: any;

@Component({
  selector: 'add-wo-details',
  templateUrl: 'add-wo-details.html',
  providers: [Transfer, TransferObject, FileOpener, File]
})

export class AddWODetailsPage {

  wo_height = 0
  spare_part_height = 0;
  labour_height = 0;
  equip_height = 0;
  doc_height = 0;
  service_height = 0;
  comment_height = 0;
  private workOrder: WorkOrder;
  private wharehouseDetails: any[] = [];

  private productItems: Array<WorkOrderItem> = []
  private equipmentItems: Array<WorkOrderItem> = [];
  private serviceItems: Array<WorkOrderItem> = [];
  private peopleItems: Array<WorkOrderItem> = [];
  private documents: any[] = [];
  private comments: any[] = [];

  private account: Account;
  private isAreaManager: boolean;
  private isAdmin: boolean;
  private isCustomerAdmin: boolean;
  private isVendorTech: boolean;
  loading: Loading;

  private seconds: number;
  private minutes: number;
  private hours: number;
  private timeDiff: number;

  private hoursDifference: number = 0;
  private minutesDifference: number = 0;
  private secondsDifference: number = 0;

  private logTimer: any;

  private woId: string;
  storageDirectory: string = '';

  constructor(public navCtrl: NavController,
    public navParams: NavParams,
    private workOrderService: WorkOrderService,
    private alertCtrl: AlertController,
    private partsPriceCalculationService: AddPartsPriceCalculationService,
    private toastService: ToastService,
    private configService: ConfigService,
    private authHttp: AuthHttp,
    public accountService: AccountService,
    private loadingCtrl: LoadingController,
    public platform: Platform,
    private transfer: Transfer,
    private file: File,
    private fileOpener: FileOpener) {

    this.woId = navParams.get('id');

    this.loadAccountDetails(accountService);

    this.workOrderService.getWorkOrderDetails(this.woId).take(1).subscribe(wo => {
      this.workOrder = wo;
      console.log(this.workOrder);

      this.workOrder.workOrderItems.forEach(woItem => {
        if (woItem.itemType == 'PRODUCT') {
          this.productItems.push(woItem);
        } else if (woItem.itemType == 'EQUIPMENT') {
          this.equipmentItems.push(woItem);
        } else if (woItem.itemType == 'PEOPLE') {
          this.peopleItems.push(woItem);
        } else if (woItem.itemType == 'SERVICE') {
          this.serviceItems.push(woItem);
        }

      });

      if (this.workOrder.workOrderItems && this.workOrder.workOrderItems.length > 0 && this.workOrder.isPeopleLineItemAdded) {
        this.workOrder.workOrderItems.forEach(woItem => {
          if (woItem.itemType === 'PEOPLE' && woItem.assignedPersonnel) {

            woItem.assignedPersonnel.forEach(element => {
              if (this.account.id === element.id) {
                console.log("WOITEMMMMM", woItem);
                this.setLogHours(woItem.workingHours);
              }
            });

          }
        });

      } else {
        this.setLogHours(this.workOrder.workingHours);
      }

      if (this.workOrder.documents) {
        this.documents = this.workOrder.documents;
      }

      if (this.workOrder.workOrderTransactions) {
        this.comments = this.workOrder.workOrderTransactions;
      }

      if (this.isAreaManager) {
        this.calculateWorkorderTime();
      }
    }, error => {
      console.log("Error ", error);
      this.toastService.showToast("bottom", "Unable to fetch data.");
      this.navCtrl.pop(AddWODetailsPage);
    });



  }

  loadAccountDetails(accountService) {
    accountService.getAccount().subscribe(response => {
      this.account = response;
    }, error => {
      console.log("Error ", error);
      this.toastService.showToast("bottom", "Unable to fetch data.");
      //this.navCtrl.pop(AddWODetailsPage);
    });

    this.isAreaManager = this.account.authorities.indexOf('AREA_MANAGER') > -1;
    this.isAdmin = this.account.authorities.indexOf('VENDOR_SYSTEM_ADMIN') > -1;
    this.isCustomerAdmin = this.account.authorities.indexOf('CUSTOMER_ADMIN') > -1;
    this.isVendorTech = this.account.authorities.indexOf('VENDOR_TECHNICIAN') > -1;
  }

  public addSpareParts(woId: string): void {
    this.navCtrl.push(AddSparePartsPage, { id: woId });
  }

  addPeople(woId: string): void {
    this.navCtrl.push(AddPeoplePage, { id: woId });
  }

  addEquipment(woId: string): void {
    this.navCtrl.push(AddEquipmentPage, { id: woId });
  }

  addService(woId: string): void {
    this.navCtrl.push(AddServicePage, { id: woId });
  }

  addDocument(woId: string): void {
    this.navCtrl.push(AddDocumentPage, { id: woId });
  }

  addComment(woId: string): void {
    this.navCtrl.push(CommentWOPage, { wo: this.workOrder });
  }


  ionViewDidLoad() {
    console.log('ionViewDidLoad WODetailPage');
  }
  onFabBtnClick(): void {
    this.navCtrl.popToRoot();
  }


  //******Edit Spare Part Start ********************//

  editAddedItem(woItem, i) {
    let prompt = this.alertCtrl.create({
      title: '#Item: ' + woItem.itemNumber,
      message: "Enter quntity",
      inputs: [
        {
          name: 'quntity',
          placeholder: 'Quantity',
          value: woItem.itemQty,
          type: 'number'
        },
      ],
      buttons: [
        {
          text: 'Cancel',
          handler: data => {
            console.log('Cancel clicked');
          }
        },
        {
          text: 'Save',
          handler: data => {
            if (+data.quntity > 0) {
              let item = {
                description: woItem.description,
                itemQty: +data.quntity,
                itemType: "PRODUCT",
                listPrice: woItem.listPrice,
                vendorItemNumber: woItem.itemNumber
              }
              woItem.itemQty = +data.quntity;
              var productItem = this.partsPriceCalculationService.getItem(this.workOrder, item);
              this.partsPriceCalculationService.priceCalculationOnItemChange(productItem);
              console.log(productItem);
              this.saveSparePartsList();
            }
            else {
              this.toastService.showToast("bottom", "please enter quntity greter then 0 for ITEM #" + woItem.itemNumber);
              this.editAddedItem(woItem, i);
            }
          }
        }
      ]
    });
    prompt.present();
  }


  deleteAddedItem(woItem, index) {

    let confirm = this.alertCtrl.create({
      title: '#Item: ' + woItem.itemNumber,
      message: 'Are you sure you wana delete this item?',
      buttons: [
        {
          text: 'Cancel',
          handler: () => {
            console.log('Disagree clicked');
          }
        },
        {
          text: 'Delete',
          handler: () => {
            let index = this.workOrder.workOrderItems.indexOf(woItem);
            if (index >= 0) {
              this.workOrder.workOrderItems.splice(index, 1);
              this.saveSparePartsList();
            }
          }
        }
      ]
    });
    confirm.present();
  }


  //save spare part list after deleting item(s)
  saveSparePartsList() {
    this.showLoading();
    this.workOrderService.updateWO(this.workOrder).subscribe(wo => {
      this.toastService.showToast("bottom", "Item(s) Updated Successfully!");
      this.loading.dismiss();
    }, error => {
      this.toastService.showToast("bottom", "Error while updating Item!");
      this.loading.dismiss();
    });
  }


  //get warehouse data
  getPartWarehouseList(woItem, index): Observable<Boolean> {
    this.showLoading();
    this.wharehouseDetails = [];
    return Observable.create(observer => {
      this.configService.getServiceUrl("WO_WAREHOUSE").take(1).subscribe(url => {
        this.authHttp.query(url + woItem.itemNumber + '/' + false)
          .map((response) => response.json())
          .subscribe(response => {
            this.wharehouseDetails = response;
            this.loading.dismiss();
            console.log(this.wharehouseDetails);
            if (this.wharehouseDetails.length === 0) {
              this.toastService.showToast("bottom", "No warehouse found");
              observer.next(false);
              observer.complete();
            }
            observer.next(true);
            observer.complete();
          }, error => {
            this.toastService.showToast("bottom", "Error while getting Warehouse list!");
            this.loading.dismiss();
            observer.next(false);
            observer.complete();
          });
      }, error => {
        this.toastService.showToast("bottom", "Not found.");
      });
    })
  }


  // called to save WO and Dispatch Quntity
  addWarehouse(woItem, index) {
    //get warehouses

    this.getPartWarehouseList(woItem, index).subscribe(response => {
      // popup to select warehouse
      if (response) {
        let alert = this.alertCtrl.create();
        alert.setTitle('Select Warehouse');

        this.wharehouseDetails.forEach(details => {
          alert.addInput({
            type: 'radio',
            label: details.whseName,
            value: details
          });
        });

        alert.addButton('Cancel');
        alert.addButton({
          text: 'OK',
          handler: data => {
            // popup to save dispatch quntity
            this.saveDispatchQuntity(woItem, data, index);
          }
        });
        alert.present();
      }
    }, error => {
      this.toastService.showToast("bottom", "ERROR!");
    });
  }

  // called to enter dipatch quntity and save WO
  saveDispatchQuntity(woItem, data, index) {

    let warehouseData = {
      copyDetails: data.copyDetails,
      id: data.id,
      qtyOnHandsValue: data.qtyOnHandsValue,
      showSiteAddress: data.showSiteAddress,
      whseName: data.whseName,
      qtyOnHands: data.qtyOnHands
    };

    let workOrderItems = {
      addOnCostPrice: woItem.addOnCostPrice,
      availableQtyInInventory: woItem.availableQtyInInventory,
      description: woItem.description,
      discountOnListPrice: woItem.discountOnListPrice,
      dispatchQuantity: null,
      itemNumber: woItem.itemNumber,
      itemQty: woItem.itemQty,
      itemType: woItem.itemType,
      listPrice: woItem.listPrice,
      warehouseData: warehouseData,
      price: woItem.price,
      billable: woItem.billable,
      contractPrice: woItem.contactPrice,
      itemNotes: woItem.itemNotes,
      costPrice: woItem.costPrice
    };

    let wo = {
      id: this.workOrder.id,
      workOrderId: this.workOrder.workOrderId,
      jobStatus: this.workOrder.jobStatus,
      workOrderItem: workOrderItems
    };

    let prompt = this.alertCtrl.create({
      title: '#Item: ' + woItem.itemNumber,
      message: "Enter Quntity",
      inputs: [
        {
          name: 'quntity',
          placeholder: 'Quntity',
          type: 'number'
        },
      ],
      buttons: [
        {
          text: 'Cancel',
          handler: data => {
            console.log('Cancel clicked');
          }
        },
        {
          text: 'Save',
          handler: data => {
            if (data.quntity > data.qtyOnHandsValue) {
              this.toastService.showToast("bottom", "WareHouse does not have this much quntity for item");
              this.saveDispatchQuntity(woItem, data, index);
            }
            else if (data.quntity > woItem.itemQty) {
              this.toastService.showToast("bottom", " Dispatch Quntity must be less then quntity required for item ");
              this.saveDispatchQuntity(woItem, data, index);
            } else {
              workOrderItems.dispatchQuantity = +data.quntity;
              console.log(workOrderItems.dispatchQuantity);
              this.saveItemInWo(wo, index);
            }
          }
        }
      ]
    });
    prompt.present();
  }

  // called to save Item in  WO
  saveItemInWo(wo, index) {
    this.showLoading();
    wo.isSparePartsOrder = false;
    this.configService.getServiceUrl("WO_ITEM").take(1).subscribe(url => {
      this.authHttp.put(url, wo)
        .subscribe(response => {
          console.log(response);
          // this.dispatchQuntity[index] = wo.workOrderItem.dispatchQuantity;
          this.navCtrl.push(AddWODetailsPage, { id: this.navParams.get('id') });
          this.toastService.showToast("bottom", "Item(s) added to the Work order!");
          this.loading.dismiss();
        }, error => {
          this.toastService.showToast("bottom", "Error while adding Item to Work order!");
          this.loading.dismiss();
        });
    });

  }



  deleteAddedDoc(doc, index) {

    let confirm = this.alertCtrl.create({
      title: 'Doc: ' + doc.description,
      message: 'Are you sure you wana delete this document?',
      buttons: [
        {
          text: 'Cancel',
          handler: () => {
            console.log('Disagree clicked');
          }
        },
        {
          text: 'Delete',
          handler: () => {
            let index = this.workOrder.documents.indexOf(doc);
            if (index >= 0) {
              this.workOrder.documents.splice(index, 1);
              this.saveSparePartsList();
            }
          }
        }
      ]
    });
    confirm.present();
  }


  showFinishPopup() {

    let finishPopup = this.alertCtrl.create({
      title: 'Finish WorkOrder',
      inputs: [
        {
          name: 'symptoms',
          placeholder: 'Symptoms',
          value: this.workOrder.symptoms,
          type: 'text'
        },
        {
          name: 'resolution',
          placeholder: 'Resolutions',
          value: this.workOrder.resolution
        }
      ],
      buttons: [
        {
          text: 'Cancel',
          handler: data => {
            console.log('Disagree clicked');
          }
        },
        {
          text: 'Finish',
          handler: data => {
            let document = new Document();
            document.id = this.workOrder.id;
            document.comments = data.resolution;
            document.description = data.symptoms;
            this.finishWorkOrder(document);

          }
        }
      ]
    });
    finishPopup.present();
  }


  finishWorkOrder(document) {
    this.showLoading();
    this.configService.getServiceUrl("WO").take(1).subscribe(url => {
      this.authHttp.post(url + "/" + "signature", document)
        .subscribe(response => {
          console.log(response);
          this.navCtrl.push(WODashboardPage);
          this.toastService.showToast("bottom", "WO: " + this.workOrder.workOrderId + " has been finished");
          this.loading.dismiss();
        }, error => {
          this.toastService.showToast("bottom", "Error while finishing Work order!");
          this.loading.dismiss();
        });
    });

  }


  showLoading() {
    this.loading = this.loadingCtrl.create({
      content: 'Please wait...'
    });
    this.loading.present();
  }


  // WO Timer 

  timerControl() {
    if (this.workOrder.jobStatus == 'Started') {
      this.pause();
    } else {
      this.start();
    }
    //	this.playPause = !this.playPause;
  }


  start() {
    this.logTimer = setInterval(() => {
      this.updateLogTime();
    }, 1000);


    this.workOrder.jobStatus = 'Started';
    this.saveWoEvent(this.workOrder.jobStatus);
    if (this.workOrder.jobStatus == 'Created') {
      // this.showLoading();
      this.navCtrl.push(this, { 'id': this.woId });
    }
  }

  pause() {

    clearInterval(this.logTimer);
    this.workOrder.jobStatus = 'Suspended';
    this.saveWoEvent(this.workOrder.jobStatus);
  }

  stop() {
    clearInterval(this.logTimer);
    this.workOrder.jobStatus = 'Completed';
    this.saveWoEvent(this.workOrder.jobStatus);
  }


  setLogHours(workingHours) {
    console.log("Working Hours", workingHours);
    if (workingHours) {
      var tokens = workingHours.split(':');
      this.hours = Number(tokens[0]);
      this.minutes = Number(tokens[1]);
      if (tokens.length > 2) {
        this.seconds = Number(tokens[2]);
      } else {
        this.seconds = 0;
      }
    } else {
      this.hours = 0;
      this.minutes = 0;
      this.seconds = 0;
    }
    console.log("workOrderStatus", this.workOrder.jobStatus);
    if (this.workOrder.jobStatus == 'Started') {
      this.logTimer = setInterval(() => {
        this.updateLogTime();
      }, 1000);
    }
  }

  updateLogTime() {

    if (!this.seconds) {
      this.seconds = 1;
    } else {
      this.seconds = this.seconds + 1
    }

    if (!this.minutes) {
      this.minutes = 0;
    }


    if (this.seconds > 59) {
      this.seconds = 0;
      this.minutes = this.minutes + 1
    }

    if (!this.hours) {
      this.hours = 0;
    }

    if (this.minutes > 59) {
      this.minutes = 0;
      this.hours = this.hours + 1
    }
  }




  calculateWorkorderTime() {
    let woStartTime: string;
    let woEndTime: string;


    var keepGoing = true;

    this.workOrder.workOrderTransactions.forEach(obj => {
      if (keepGoing) {
        if (obj.transactionType == 'Started') {
          woStartTime = obj.createdDate;
          keepGoing = false;
        }
      }
    });


    keepGoing = true;
    this.workOrder.workOrderTransactions.forEach(obj => {
      if (keepGoing) {
        if (obj.transactionType == 'Completed') {
          woEndTime = obj.createdDate;
          keepGoing = false;
        }
      }
    });


    if (woStartTime && woEndTime) {
      console.log("woStartTime", woStartTime);
      console.log("woEndTime  ", woEndTime);

      this.hoursDifference = 0;
      this.minutesDifference = 0;
      this.secondsDifference = 0;

      this.timeDiff = Math.abs(Date.parse(woStartTime) - Date.parse(woEndTime));
      this.hoursDifference = (this.timeDiff / (1000 * 3600));

      if (this.hoursDifference < 1) {
        this.hoursDifference = 0;
        this.minutesDifference = this.timeDiff / (1000 * 60);

        if (this.minutesDifference < 1) {
          this.minutesDifference = 0;
          this.secondsDifference = Math.ceil(this.timeDiff / 1000);

        } else {
          this.minutesDifference = Math.ceil(this.minutesDifference);
        }

      } else {
        this.hoursDifference = Math.ceil(this.hoursDifference);
      }
    }

  }



  saveWoEvent(jobStatus) {
    this.showLoading();
    this.configService.getServiceUrl("WO").take(1).subscribe(url => {
      this.authHttp.post(url + "/" + "event", { transactionType: jobStatus, workOrderId: this.workOrder.id })
        .subscribe(response => {
          console.log(response);
          this.toastService.showToast("bottom", "WO " + jobStatus);
          this.loading.dismiss();
        }, error => {
          this.toastService.showToast("bottom", "Error while saving Work order event!");
          this.loading.dismiss();
        });
    });

  }

  approveWorkOrder() {
    let approvalComments: string;

    let approvePopup = this.alertCtrl.create({
      title: 'Approve WorkOrder',
      message: "Are you sure you want to approve WO?",
      inputs: [
        {
          name: '',
          placeholder: 'Comments',
          value: approvalComments,
          type: 'text'
        }
      ],
      buttons: [
        {
          text: 'No',
          handler: data => {
            console.log('Disagree clicked');
          }
        },
        {
          text: 'Yes',
          handler: data => {

            this.approvalConfirmed(approvalComments);

          }
        }
      ]
    });
    approvePopup.present();

  }


  approvalConfirmed(approvalComments) {
    this.workOrder.jobStatus = 'Approved';

    this.showLoading();

    this.configService.getServiceUrl("WO").take(1).subscribe(url => {
      this.authHttp.post(url + "/" + "event", {
        transactionType: this.workOrder.jobStatus,
        workOrderId: this.workOrder.id, approvalComment: approvalComments
      })
        .subscribe(response => {
          console.log(response);
          this.navCtrl.push(WODashboardPage);
          this.toastService.showToast("bottom", "WO: " + this.workOrder.workOrderId + " has been Approved!");
          this.loading.dismiss();
        }, error => {
          this.toastService.showToast("bottom", "Error while Approving Work order!");
          this.loading.dismiss();
        });
    });
  }



  // Dowonloading of documents start 


  downloadDocument(doc) {
    console.log(doc);

    this.platform.ready().then(() => {
      console.log("platform ready");

      if (!this.platform.is('cordova')) {
        return false;
      }

      if (this.platform.is('ios')) {
        this.storageDirectory = cordova.file.documentsDirectory;
      }
      else if (this.platform.is('android')) {
        this.storageDirectory = cordova.file.dataDirectory;
      }
      else {
        return false;
      }

      const fileTransfer: TransferObject = this.transfer.create();

      const url = this.configService.getBaseUrl() + "api/tickets/document/" + doc.documentId;
      let filename = doc.description;
      let targetPath = this.storageDirectory + filename;

      fileTransfer.download(url, targetPath).then((entry) => {
        this.showLoading();

        var ext="application/";

				if(filename.indexOf('.pdf')>0){
					ext = ext+'pdf';
				} else if(filename.indexOf('.png')>0 || filename.indexOf('.jpg')>0 || filename.indexOf('.jpeg')>0 || filename.indexOf('.gif')>0){
					ext = "image/jpeg";
				} else{
					ext = "application/*";
				}

        this.loading.dismiss();
        this.fileOpener.open(entry.nativeURL, ext)
          .then(() => console.log('File is opened'))
          .catch(e => console.log('Error openening file', e));

      }, (error) => {

        this.loading.dismiss();
        const alertFailure = this.alertCtrl.create({
          title: `Download Failed!`,
          subTitle: `${filename} was not successfully downloaded. Error code: ${error.code}`,
          buttons: ['Ok']
        });

        alertFailure.present();

      });




    });
  }


}
