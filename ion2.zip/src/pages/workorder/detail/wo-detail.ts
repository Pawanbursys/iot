import { Component } from '@angular/core';
import { NavController, NavParams, Loading, LoadingController } from 'ionic-angular';
import { WorkOrderService, ToastService } from '../../../providers/index';

/*
  Generated class for the Detail page.

  See http://ionicframework.com/docs/v2/components/#navigation for more info on
  Ionic pages and navigation.
*/
@Component({
  selector: 'page-detail',
  templateUrl: 'wo-detail.html'
})
export class WODetailPage {

  private woDetailObject: any;
  private workOrderId: String;
  private jobStatus: String
  loading: Loading;

  constructor(public navCtrl: NavController, public navParams: NavParams, 
  private workOrderService: WorkOrderService, public toastService: ToastService,
  private loadingCtrl: LoadingController) {
     let id = navParams.get('id');
     this.getWorkOrderDetails(id);
  }

  private getWorkOrderDetails(id: String) {
    this.showLoading();
    this.workOrderService.getWorkOrderDetails(id).take(1).subscribe(workOrderdetails=> {
            this.loading.dismiss();
             this.woDetailObject = workOrderdetails;
             this.workOrderId = this.woDetailObject.workOrderId;
             this.jobStatus = this.woDetailObject.jobStatus;
            // console.log(this.woDetailObject.workOrderId);
    }, error => {
      this.toastService.showToast("bottom", "Not Found.");
    });
  }

  showLoading() {
    this.loading = this.loadingCtrl.create({
      content: 'Please wait...'
    });
    this.loading.present();
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad WODetailPage');
  }

}
