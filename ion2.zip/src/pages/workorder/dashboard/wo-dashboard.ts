import { Component } from '@angular/core';
import { NavController, NavParams, Loading, LoadingController  } from 'ionic-angular';
import { WorkOrder, WorkOrderService } from '../../../providers'
import { WODetailPage} from '../detail/wo-detail';
import { CreateWOPage} from '../createWO/createWO';
import { TranslateService} from 'ng2-translate';
import { ViewWOPage } from '../view-wo/view-wo';


/*
  Generated class for the WODashboard page.

  See http://ionicframework.com/docs/v2/components/#navigation for more info on
  Ionic pages and navigation.
*/
@Component({
  selector: 'page-wo-dashboard',
  templateUrl: 'wo-dashboard.html',
})
export class WODashboardPage {

  private currentWorkOrders : Array<WorkOrder>;
  private created : any;
  private completed : any;
  private started : any;
  private suspended : any;
  private approved : any;

  loading: Loading;

  constructor(public translate: TranslateService,public navCtrl: NavController, public navParams: NavParams, private workOrderService: WorkOrderService,
   private loadingCtrl: LoadingController) {
    this.loadCurrentWorkOrders();

    this.created = 0;
    this.completed = 0;
    this.started = 0;
    this.suspended = 0;
    this.approved = 0;

    // SET LANG (ON PAGE REFRESH)
    if(localStorage.getItem('LANG')){
      translate.use(localStorage.getItem('LANG'));
    }else{
      translate.setDefaultLang('en');
    }
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad WODashboardPage');
  }


 showLoading() {
    this.loading = this.loadingCtrl.create({
      content: 'Please wait...'
    });
    this.loading.present();
  }


  private loadCurrentWorkOrders(){
    this.showLoading();
    this.workOrderService.getWorkOrders().take(1).subscribe(workOrders=>{
      this.loading.dismiss();
      this.currentWorkOrders = workOrders;

      for (var i = 0; i < workOrders.length; i++) {
					if(workOrders[i].jobStatus === 'Created'){
						this.created = this.created+1;
					}else if(workOrders[i].jobStatus === 'Completed'){
            this.completed = this.completed+1;
					}else if(workOrders[i].jobStatus == 'Started'){
            this.started = this.started+1;
					}else if(workOrders[i].jobStatus === 'Suspended'){
            this.suspended = this.suspended+1;
					}else if(workOrders[i].jobStatus === 'Approved'){
            this.approved = this.approved+1;
					}
				};

    })
  }

  public showWorkOrderDetail(workOrder: WorkOrder):void {
    this.navCtrl.push(WODetailPage, {id: workOrder.id});
    // alert("Show work order detail - " + workOrder);
  }

   public createWO():void {
    this.navCtrl.push(CreateWOPage);
  }


  public openWorkOrderList(statusType:string):void{
    this.navCtrl.push(ViewWOPage,{"statusType":statusType});
	}



  //********************************** */

  eventSource;
    viewTitle;
    isToday: boolean;
    calendar = {
        mode: 'month',
        currentDate: new Date()
    }; // these are the variable used by the calendar.
    loadEvents() {
        this.eventSource = this.createRandomEvents();
    }
    onViewTitleChanged(title) {
        this.viewTitle = title;
    }
    onEventSelected(event) {
        console.log('Event selected:' + event.startTime + '-' + event.endTime + ',' + event.title);
    }
    changeMode(mode) {
        this.calendar.mode = mode;
    }
    today() {
        this.calendar.currentDate = new Date();
    }
    onTimeSelected(ev) {
        console.log('Selected time: ' + ev.selectedTime + ', hasEvents: ' +
            (ev.events !== undefined && ev.events.length !== 0) + ', disabled: ' + ev.disabled);
    }
    onCurrentDateChanged(event:Date) {
        var today = new Date();
        today.setHours(0, 0, 0, 0);
        event.setHours(0, 0, 0, 0);
        this.isToday = today.getTime() === event.getTime();
    }
    createRandomEvents() {
        var events = [];
        for (var i = 0; i < 50; i += 1) {
            var date = new Date();
            var eventType = Math.floor(Math.random() * 2);
            var startDay = Math.floor(Math.random() * 90) - 45;
            var endDay = Math.floor(Math.random() * 2) + startDay;
            var startTime;
            var endTime;
            if (eventType === 0) {
                startTime = new Date(Date.UTC(date.getUTCFullYear(), date.getUTCMonth(), date.getUTCDate() + startDay));
                if (endDay === startDay) {
                    endDay += 1;
                }
                endTime = new Date(Date.UTC(date.getUTCFullYear(), date.getUTCMonth(), date.getUTCDate() + endDay));
                events.push({
                    title: 'All Day - ' + i,
                    startTime: startTime,
                    endTime: endTime,
                    allDay: true
                });
            } else {
                var startMinute = Math.floor(Math.random() * 24 * 60);
                var endMinute = Math.floor(Math.random() * 180) + startMinute;
                startTime = new Date(date.getFullYear(), date.getMonth(), date.getDate() + startDay, 0, date.getMinutes() + startMinute);
                endTime = new Date(date.getFullYear(), date.getMonth(), date.getDate() + endDay, 0, date.getMinutes() + endMinute);
                events.push({
                    title: 'Event - ' + i,
                    startTime: startTime,
                    endTime: endTime,
                    allDay: false
                });
            }
        }
        return events;
    }
    onRangeChanged(ev) {
        console.log('range changed: startTime: ' + ev.startTime + ', endTime: ' + ev.endTime);
    }
    markDisabled = (date:Date) => {
        var current = new Date();
        current.setHours(0, 0, 0);
        return date < current;
    };


  //************************************** */

}
