import { Component } from '@angular/core';
import { NavController, NavParams, AlertController, Platform, LoadingController, Loading, ToastController } from 'ionic-angular';
import { AddWODetailsPage } from '../add-wo-details/add-wo-details';
import { AccountService, WorkOrderService, ToastService, WorkOrder, Account, WorkOrderItem, Warehouse, DataUtilsService, Document } from '../../../providers';
import { Camera} from '@ionic-native/camera';


/*
  Generated class for the Add Document in WO.

  See http://ionicframework.com/docs/v2/components/#navigation for more info on
  Ionic pages and navigation.
*/
@Component({
  selector: 'add-document',
  templateUrl: 'add-document.html',
   providers: [Camera]
})

export class AddDocumentPage {

  private account: Account;
  private workOrder: WorkOrder;
  private document: Document;
  private woDocuments: Array<Document> = [];
  private filesToUpload: any[] = [];
  loading: Loading;

  constructor(private accountService: AccountService,
    public navCtrl: NavController,
    public navParams: NavParams,
    private toastService: ToastService,
    private workOrderService: WorkOrderService,
    private alertCtrl: AlertController,
    private platform: Platform,
    private dataUtilsService: DataUtilsService,
    private loadingCtrl: LoadingController,
    private camera: Camera) {

    this.accountService.getAccount().subscribe(response => {
      this.account = response;
    }, error => {
      this.toastService.showToast("bottom", "Not Found.")
    });

    let woId = navParams.get('id');
    this.getWorkOrder(woId);
  }


  //*********Get WO********//

  getWorkOrder(id: String) {
    this.showLoading();
    this.workOrderService.getWorkOrderDetails(id).take(1).subscribe(wo => {
      this.loading.dismiss();
      this.workOrder = wo;
    }, error => {
      this.toastService.showToast("bottom", "Not found.");
    })
  }


  showLoading() {
    this.loading = this.loadingCtrl.create({
      content: 'Please wait...'
    });
    this.loading.present();
  }


  public onSelectFile(event) {
    console.log('onChange');
    var files = event.srcElement.files;

    for (let file of event.srcElement.files) {
      console.log(file);
      this.filesToUpload.push(file);
      let document = new Document();

      this.dataUtilsService.toBase64(file, function (base64Data, fileName, fileType) {
        document.fileName = fileName;
        document.fileData = base64Data;
        document.imageData = "data:image/jpeg;base64," + base64Data;
        document.documentType = fileType;
      });
      console.log(document)
      document.fileSize = this.dataUtilsService.byteSize(document.fileData);

      this.woDocuments.push(document);
      console.log(this.woDocuments);
    }
  }

  public removeFiles(index) {
    if (index >= 0) {
      this.woDocuments.splice(index, 1);
      this.filesToUpload.splice(index, 1);
    }
  }


  public takePicture() {

    console.log("inside take photo");

    this.platform.ready().then(() => {
      console.log("platform ready");

      let options = {
        destinationType: this.camera.DestinationType.DATA_URL,
        sourceType: this.camera.PictureSourceType.CAMERA,
        allowEdit: false,
        saveToPhotoAlbum: true
      };

      let document = new Document();
      let i:number=0;
      this.camera.getPicture(options).then(function (imageData) {
        document.fileName = 'Camera_' +i + '.png';
        document.fileData = imageData;
        document.fileSize = this.dataUtilsService.byteSize(document.fileData);
        document.imageData = "data:image/jpeg;base64," + imageData;
        this.woDocuments.push(document);
        i++;
      }, (error) => {
        console.log('error when taking picture'+error);
      });
    });
  }


  uploadMobileDocs() {

    console.log("saving WO documents");
    let doumentsToUpload = [];

    for (let file of this.woDocuments) {

      let document = new Document();

      document.id = this.workOrder.id;
      document.documentType = file.documentType;
      document.field = file.fileData;
      document.description = file.fileName;
      document.fileSize = this.dataUtilsService.byteSize(file.fileData);;

      doumentsToUpload.push(document);
    }

    console.log(doumentsToUpload);

    if (doumentsToUpload.length > 0) {
      this.showLoading();
      this.workOrderService.saveWorkOrderDocuments(doumentsToUpload).subscribe(wo => {
        this.loading.dismiss();
        console.log("Mobile documents saved!");
        this.toastService.showToast("bottom", "Document(s) added to the Work order!");
        this.navCtrl.push(AddWODetailsPage, { id: this.workOrder.id });
      }, error => {
        this.loading.dismiss();
        this.toastService.showToast("bottom", "Error while adding Document to Work order!");
      });
    } else {
      this.toastService.showToast("bottom", "No document available to save!");
    }

  }


}