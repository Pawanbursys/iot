import { Component } from '@angular/core';
import { NavController, NavParams, LoadingController, Loading } from 'ionic-angular';
import { InternalPartTransferService } from '../../../providers/internal-part-transfer/internal-part-transfer.service';
import {ToastService} from '../../../providers';
import { InternalPartTransferCreateDetailPage } from '../create/internal-part-transfer-detail-create';

@Component({
  selector: 'page-internal-part-transfer-search',
  templateUrl: 'internal-part-transfer-search.html'
})

export class InternalPartTransferSearchPage {
  loading: Loading;

  constructor(public navCtrl: NavController, public navParams: NavParams,
              private internalPartTransferService : InternalPartTransferService, 
              private toastService:ToastService, private loadingCtrl: LoadingController) {}

  searchedItems: any[];
  itemsAvailable: boolean = true;

  private getSearchDetails(searchValue: String) {
    console.log(searchValue);
    this.showLoading();
    this.internalPartTransferService.getSearchDetailsOfItems(searchValue).take(1).subscribe(item=> {
        this.searchedItems = item;
        if(this.searchedItems.length>0){
          this.loading.dismiss();
          this.itemsAvailable = true;
        }else{
          this.loading.dismiss();
          console.log("No data available.");
          this.itemsAvailable = false;
          this.toastService.showToast("bottom","SERVICE TAG NOT FOUND");
        }
        console.log(item);
    }, error => {
        this.loading.dismiss();
        this.toastService.showToast("bottom","SERVICE TAG NOT FOUND")
    });

  }

  openItemDetails(item){
    this.showLoading();
    this.navCtrl.push(InternalPartTransferCreateDetailPage, item);
    this.loading.dismiss();
  }


  ionViewDidLoad() {
    console.log('ionViewDidLoad InternalPartTransferPage');
  }

  showLoading() {
    this.loading = this.loadingCtrl.create({
      content: 'Please wait...'
    });
    this.loading.present();
  }
 
  showError(text) {
    setTimeout(() => {
      this.loading.dismiss();
    });
 
  }

}
