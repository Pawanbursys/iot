import { Component } from '@angular/core';
import { NavController, NavParams, LoadingController, Loading } from 'ionic-angular';
import { InternalPartTransferService } from '../../../providers/internal-part-transfer/internal-part-transfer.service';
import { ToastService } from '../../../providers';
import { WhsePickUpTicket, DateTime } from '../../../providers/internal-part-transfer/internal-part-transfer.modal'
import { InternalPartTransferLandingPage } from "../landing/internal-part-transfer-landing";
/*
  Generated class for the InternalPartTransfer page.

  See http://ionicframework.com/docs/v2/components/#navigation for more info on
  Ionic pages and navigation.
*/
@Component({
    selector: 'page-internal-part-transfer-create',
    templateUrl: 'internal-part-transfer-detail-create.html'
})
export class InternalPartTransferCreateDetailPage {
    loading: Loading;
    private internalPartTransfer: WhsePickUpTicket = new WhsePickUpTicket();

    constructor(public navCtrl: NavController, public navParams: NavParams,
        private internalPartTransferService: InternalPartTransferService,
        private toastService: ToastService, private loadingCtrl: LoadingController) { }

    dateTime = new DateTime();
    itemDetail: string = this.navParams.data;
    whseId: string = this.navParams.data.whseDTO.id;
    qtyOnHand: number[] = [];

    shipmentPriority: string[] = ["Low", "Medium", "High"];

    public event = {
        month: '1990-02-19',
        timeStarts: '07:43',
        timeEnds: '1990-02-20'
    }

    reqQty: number[];
    warehouses: string[];
    sites: any[];
    address: string;
    showAddress: boolean = false;
    private getWarehouse() {
        this.internalPartTransferService.getWarehouse(this.whseId).take(1).subscribe(item => {
            this.warehouses = item;
        }, error => {
            console.log(error);
        });
    }

    private getSites() {
        this.internalPartTransferService.getSites().take(1).subscribe(sites => {
            this.sites = sites.assignedSites;
        }, error => {
            console.log(error);
        });
    }

    showSiteAddress(siteInfo) {
        this.showAddress = true;
        this.sites.forEach(site => {
            if (site.id == siteInfo.id) {
                this.address = site.mailingAddress.street1 + ", " + site.mailingAddress.street2 + ", " + site.mailingAddress.city
                    + ", " + site.mailingAddress.state + ", " + site.mailingAddress.country + ", " + site.mailingAddress.postCode;
            }
        });
    }

    items: any = this.itemDetail;
    maxQuantity = this.items.quantityOnHand;

    validateQuantity() {
        if (this.internalPartTransfer.quantity > this.maxQuantity) {
            this.internalPartTransfer.quantity = this.maxQuantity;
        }
    }

    save(internalPartTransfer, dateTime) {

        //let partTransfer:any[] = internalPartTransfer;
        console.log(internalPartTransfer);

        if (internalPartTransfer.comment != null && internalPartTransfer.priority != null &&
            internalPartTransfer.quantity != null && internalPartTransfer.shippingSiteLocation != null &&
            internalPartTransfer.toWarehouse != null) {
            console.log("All fields are filled.");

            this.showLoading();
            this.internalPartTransferService.saveWhsePickUpTicket(internalPartTransfer, this.whseId, this.itemDetail).subscribe(prtTrnsfr => {
                this.toastService.showToast("bottom", "INTERNALPARTTRANSFER SUCCESSFULLY CREATED");
                this.navCtrl.setRoot(InternalPartTransferLandingPage);
                this.loading.dismiss();
            }, error => {
                this.loading.dismiss();
                this.toastService.showToast("bottom", "ERROR WHILE CREATING INTERNALPARTTRANSFER")
            });
        }else{
            this.loading.dismiss();
            this.toastService.showToast("bottom","All fields are complusory.");
        }

        this.loading.dismiss();

    }

    ionViewDidLoad() {
        this.getWarehouse();
        this.getSites();
    }

    showLoading() {
        this.loading = this.loadingCtrl.create({
            content: 'Please wait...'
        });
        this.loading.present();
    }

    showError(text) {
        setTimeout(() => {
            this.loading.dismiss();
        });

    }

}