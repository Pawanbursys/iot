import { Component } from '@angular/core';
import { NavController, NavParams, LoadingController, Loading } from 'ionic-angular';
import { InternalPartTransferService } from '../../../providers/internal-part-transfer/internal-part-transfer.service'
import { InternalPartTransferEditDetailPage } from "../edit/internal-part-transfer-detail-edit";
import { InternalPartTransferSearchPage } from "../search/internal-part-transfer-search";
import { ToastService } from "../../../providers/index";

@Component({
  selector: 'page-internal-part-transfer-landing',
  templateUrl: 'internal-part-transfer-landing.html'
})

export class InternalPartTransferLandingPage {
  loading: Loading;

  constructor(public navCtrl: NavController, public navParams: NavParams,
  public internalPartTransferService: InternalPartTransferService, 
  private loadingCtrl: LoadingController, private toastService: ToastService) {}

  pickUpTickets: any[];
  isPickUpTicketsAvailable: boolean = true;

  private getPickUpTickets(){
    this.showLoading();
    this.internalPartTransferService.getPickUpTickets().take(1).subscribe(pickUpTickets => {
        console.log(pickUpTickets.length);
        this.loading.dismiss();
        this.pickUpTickets = pickUpTickets;

        if(pickUpTickets.length == 0){
          this.isPickUpTicketsAvailable = false;
        }else{
          this.isPickUpTicketsAvailable = true;
        }

    }, error=>{
        console.log("Error ", error);
        this.isPickUpTicketsAvailable = false;
        this.toastService.showToast("bottom", "Unable to fetch data.");
    });
  }

  openPartTransferDetails(pickUpTicket){
      console.log(pickUpTicket);
       this.showLoading();
       this.navCtrl.push(InternalPartTransferEditDetailPage,  pickUpTicket);
       this.loading.dismiss();
  }

  createWhsePickupTicket(){
    this.navCtrl.push(InternalPartTransferSearchPage);
  }


  ionViewDidLoad() {
      this.getPickUpTickets();  
  }

  showLoading() {
        this.loading = this.loadingCtrl.create({
            content: 'Please wait...'
        });
        this.loading.present();
    }

    showError(text) {
        setTimeout(() => {
            this.loading.dismiss();
        });

    }

}
