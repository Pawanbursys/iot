import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';
import { InternalPartTransferService } from '../../../providers/internal-part-transfer/internal-part-transfer.service';
import { ToastService } from '../../../providers';
import { WhsePickUpTicket, DateTime } from '../../../providers/internal-part-transfer/internal-part-transfer.modal'
import { InternalPartTransferLandingPage } from "../landing/internal-part-transfer-landing";
/*
  Generated class for the InternalPartTransfer page.

  See http://ionicframework.com/docs/v2/components/#navigation for more info on
  Ionic pages and navigation.
*/
@Component({
    selector: 'page-internal-part-transfer-detail',
    templateUrl: 'internal-part-transfer-detail-edit.html'
})
export class InternalPartTransferEditDetailPage {
    private internalPartTransfer: WhsePickUpTicket = new WhsePickUpTicket();

    constructor(public navCtrl: NavController, public navParams: NavParams,
        private internalPartTransferService: InternalPartTransferService,
        private toastService: ToastService, private dateTime: DateTime) { }

    itemDetail: any = this.navParams.data;
    whseId: string = this.navParams.data.fromWarehouseId;
    qtyOnHand: number[] = [];
    searchedItems: any;
    selectedItem: any;
    availQty: any;
    mgr: string;
    shipmentPriority: string[] = ["Low", "Medium", "High"];

    public event = {
        month: '1990-02-19',
        timeStarts: '07:43',
        timeEnds: '1990-02-20'
    }

    getPartTransferDetails() {
        this.internalPartTransfer.comment = this.itemDetail.comment;
        this.internalPartTransfer.priority = this.itemDetail.priority;
        this.internalPartTransfer.quantity = this.itemDetail.quantity;
        this.internalPartTransfer.shippingSiteLocation = this.itemDetail.shippingSiteLocation;
        this.internalPartTransfer.expectedReceivingDate = this.itemDetail.expectedReceivingDate;
    }

    getSearchDetails(itemNo) {
        this.internalPartTransferService.getSearchDetailsOfItems(itemNo).take(1).subscribe(item => {
            if (item.length > 0) {
                item.forEach(response => {
                    if (response.whseDTO.id == this.itemDetail.fromWarehouseId) {
                        this.selectedItem = response;
                        this.availQty = response.quantityOnHand;
                        this.mgr = response.whseDTO.whseContact.firstName + " " + response.whseDTO.whseContact.lastName;
                    }
                })
            }
        }, error => {
            this.toastService.showToast("bottom", "SERVICE TAG NOT FOUND")
        });
    }

    reqQty: number[];
    warehouses: string[];
    sites: any[];
    address: string;
    showAddress: boolean = false;

    private getWarehouse() {
         
        this.internalPartTransferService.getWarehouse(this.whseId).take(1).subscribe(item => {
            console.log("getWarehouse ", item);
            this.warehouses = item;
            item.forEach(result => {
                if (result.id == this.itemDetail.toWarehouseId) {
                    this.internalPartTransfer.toWarehouse = result;
                }
            });
        }, error => {
            console.log(error);
            this.toastService.showToast("bottom", "Unable to fetch data.");
            this.navCtrl.pop(InternalPartTransferEditDetailPage);
        });
    }

    private getSites() {
        this.internalPartTransferService.getSites().take(1).subscribe(sites => {
            this.sites = sites.assignedSites;
            sites.assignedSites.forEach(site => {
                if (site.siteName == this.internalPartTransfer.shippingSiteLocation) {
                    this.internalPartTransfer.shippingSiteLocation = site;
                    this.address = this.internalPartTransfer.shippingSiteLocation.mailingAddress.street1 + ", " + this.internalPartTransfer.shippingSiteLocation.mailingAddress.street2 + ", " + this.internalPartTransfer.shippingSiteLocation.mailingAddress.city
                        + ", " + this.internalPartTransfer.shippingSiteLocation.mailingAddress.state + ", " + this.internalPartTransfer.shippingSiteLocation.mailingAddress.country + ", " + this.internalPartTransfer.shippingSiteLocation.mailingAddress.postCode;
                }
            });
        }, error => {
            console.log(error);
            this.toastService.showToast("bottom", "Unable to fetch data.");
            this.navCtrl.pop(InternalPartTransferEditDetailPage);
        });
    }

    showSiteAddress(siteInfo) {
        this.sites.forEach(site => {
            if (site.id == siteInfo.id) {
                this.address = site.mailingAddress.street1 + ", " + site.mailingAddress.street2 + ", " + site.mailingAddress.city
                    + ", " + site.mailingAddress.state + ", " + site.mailingAddress.country + ", " + site.mailingAddress.postCode;
            }
        });
    }

    validateQuantity() {
        var maxQuantity = this.selectedItem.quantityOnHand;
        if (this.internalPartTransfer.quantity > maxQuantity) {
            this.internalPartTransfer.quantity = maxQuantity;
        }
    }

    update(internalPartTransfer, dateTime) {
        this.internalPartTransferService.updateWhsePickUpTicket(internalPartTransfer, dateTime, this.whseId, this.itemDetail).subscribe(prtTrnsfr => {
            this.toastService.showToast("bottom", "INTERNALPARTTRANSFER SUCCESSFULLY UPDATED");
            this.navCtrl.setRoot(InternalPartTransferLandingPage);
        }, error => {
            this.toastService.showToast("bottom", "ERROR WHILE CREATING INTERNALPARTTRANSFER")
        });
    }

    ionViewDidLoad() {
        this.getSearchDetails(this.navParams.data.itemNo);
        this.getPartTransferDetails();
        this.getWarehouse();
        this.getSites();
    }

}