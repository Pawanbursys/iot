import { HomePage } from './../../home/home';
import { Component } from '@angular/core';
import { NavController, NavParams, LoadingController, Loading } from 'ionic-angular';
import { Account, AccountService, AuthSessionService, ToastService } from '../../../providers';
import { TranslateService } from 'ng2-translate';
import {ConfigService } from '../../../providers';

/*
  Generated class for the Account page.

  See http://ionicframework.com/docs/v2/components/#navigation for more info on
  Ionic pages and navigation.
*/
@Component({
  selector: 'page-account',
  templateUrl: 'account.html'
})
export class AccountPage {
  private accountDetails: any;
  profilePic: any;
  loading: Loading;

  constructor(private toastService: ToastService,
    private authSessionService: AuthSessionService,
    public navCtrl: NavController,
    private accountService: AccountService,
    public navParams: NavParams,
    private loadingCtrl: LoadingController,
    private translate: TranslateService,
    private configService:ConfigService) {

    this.accountService.getAccount().subscribe(response => {
      this.accountDetails = response;
    });

    // SET LANG (ON PAGE REFRESH)
    if (localStorage.getItem('LANG')) {
      translate.use(localStorage.getItem('LANG'));
    } else {
      translate.setDefaultLang('en');
    }
    this.checkProfilePic();

  }

  public logout() {

    this.showLoading();
    this.authSessionService.logout().subscribe(response => {
      if (response) {
        window.location.reload(true);
      } else {
        this.loading.dismiss();
        this.toastService.showToast("bottom", "ERROR")
      };
    });

  }

  showLoading() {
    this.loading = this.loadingCtrl.create({
      content: 'Please wait...'
    });
    this.loading.present();
  }

  checkProfilePic(): any {
    if (this.accountDetails.profilePicId != null || this.accountDetails.profilePicId != undefined) {
      this.profilePic = this.configService.getBaseUrl() + "api/vendor/imageType/" + this.accountDetails.profilePicId;
    } else if (this.accountDetails.profilePicId == null || this.accountDetails.profilePicId == undefined) {
      this.profilePic = "./assets/img/noImageIcon.jpg";
    }
  }
}
