import { Component } from '@angular/core';
import { NavController, AlertController, LoadingController, Loading,Platform } from 'ionic-angular';
import { AuthSessionService , Credentials , PushNotificationService,AccountService,ConfigService} from '../../../providers';
import { HomePage } from '../../home/home';
import { TranslateService} from 'ng2-translate';
 import { InAppBrowser,InAppBrowserOptions } from 'ionic-native';

@Component({
  selector: 'page-login',
  templateUrl: 'login.html'
})
export class LoginPage {
  loading: Loading;
  credentials: Credentials;
  selectedLang: any;
 
  constructor(private configService:ConfigService,private platform:Platform,public translate: TranslateService,private accountService:AccountService,private nav: NavController,private pushNotification:PushNotificationService, private authSessionService: AuthSessionService, private alertCtrl:AlertController, private loadingCtrl: LoadingController) {
    if(localStorage.getItem('LANG')){
      this.selectedLang = localStorage.getItem('LANG');
      this.translate.use(localStorage.getItem('LANG'));
    }else{
      this.selectedLang = 'en';
      localStorage.setItem('LANG',this.selectedLang);
      translate.setDefaultLang(this.selectedLang);
    }
    
    this.credentials = {
      email : "",
      password : "",
      rememberMe: true
    };
  }
 
 
  public login() {
    this.showLoading()
    // this.showError(this.registerCredentials.email);
    this.authSessionService.login(this.credentials).subscribe(allowed => {
      if (allowed) {       
         this.accountService.getAccount().subscribe(response => {
            this.loading.dismiss();
            this.nav.setRoot(HomePage).catch(()=> this.showError("Can't navigate to home page"));
            this.pushNotification.callSetupPushNotification();
        }, error => {
            this.loading.dismiss();
            this.showError("Access Denied");
        });
       
       
      } else {
        this.showError("Access Denied");
      }
    },error => {
      this.showError(error);
    })
  }

  public setSelectedLang(lang){
    localStorage.setItem('LANG',lang);
    this.translate.use(localStorage.getItem('LANG'));
  }
 
  showLoading() {
    this.loading = this.loadingCtrl.create({
      content: 'Please wait...'
    });
    this.loading.present();
  }
 
  showError(text) {
    setTimeout(() => {
      this.loading.dismiss();
    });
 
    let alert = this.alertCtrl.create({
      title: 'Fail',
      subTitle: text,
      buttons: ['OK']
    });
    alert.present(prompt);
  }

  openGoogleOAuthUrl() {
    this.platform.ready().then(() => {    
        this.callOauthInAppBrowser("api/google/oauth");
      });
  }  

  openOffice365OAuthUrl() {
    this.platform.ready().then(() => {   
        this.callOauthInAppBrowser("api/azur/ad");
      });
  }


  callOauthInAppBrowser(url:string){

      let options:InAppBrowserOptions = {clearcache: 'yes',toolbar: 'yes'};
        
        let browser = new InAppBrowser(this.configService.getBaseUrl()+url,'_blank',options);
        browser.on("loadstart").subscribe(data=>{          
          var u = document.createElement("a");
          u.href = data.url;
          try{            
            if(u.pathname === "/"){
              browser.close();
              window.location.reload(true);
            }
          }catch(e){console.log("Error::"+e);}
        });

  }

}