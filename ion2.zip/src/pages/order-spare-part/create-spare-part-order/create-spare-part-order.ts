import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';
import { OrderSparePartDetailsPage } from '../order-spare-part-details/order-spare-part-details';

import { WorkOrderService, ToastService,
  WorkOrder, AccountService, SiteEquipment, Account, SmartContract , Principal} from '../../../providers/index';

@Component({
  selector: 'page-create-spare-part-order',
  templateUrl: 'create-spare-part-order.html'
})
export class CreateSparePartOrderPage {

  private siteEquipment : SiteEquipment;
  private account :Account;
  private smartContract : SmartContract;
  private isSparePartsOrder : boolean;
  private serviceTag : any;

  constructor(private accountService:AccountService,
      public navCtrl: NavController,
      public navParams: NavParams,
      private workOrderService : WorkOrderService,
      private toastService:ToastService,
      private principal:Principal) {

      this.accountService.getAccount().subscribe(response => {
            this.account=response;
            //console.log(this.account.authorities.indexOf('VENDOR_SYSTEM_ADMIN'));
         });  
        
  }


   private getServiceTagDetails(serviceTag: String) {
   
    this.workOrderService.getServiceTagDetail(serviceTag).take(1).subscribe(siteAsset=> {

        this.siteEquipment = siteAsset;
        this.serviceTag = serviceTag;
        this.siteEquipment.serviceTag = this.serviceTag;
        this.getMachineSmartContract(this.siteEquipment.id)
    }, error => {
        this.toastService.showToast("bottom","SERVICE TAG NOT FOUND")
    });

  }

  private getMachineSmartContract(machineId: String) {

    this.workOrderService.getMachineSmartContract(machineId).take(1).subscribe(smartContract=> {
          this.smartContract = smartContract;
    }, error => {
        this.toastService.showToast("bottom","NO CONTRACT FOUND")
    });
  }

   private createWO(siteEquipment) {
     console.log(siteEquipment);
    this.isSparePartsOrder = true;
    this.workOrderService.saveWO(siteEquipment,this.account,this.smartContract,this.isSparePartsOrder).subscribe(wo => {
      this.navCtrl.push(OrderSparePartDetailsPage, {id: wo.id});
      this.toastService.showToast("bottom","WO SUCCESSFULLY CREATED")
    },error => {
      this.toastService.showToast("bottom","ERROR WHILE CREATING WO")
    });
    
  }

}
