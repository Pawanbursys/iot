import { Component } from '@angular/core';
import { NavController, NavParams ,Loading , LoadingController } from 'ionic-angular';
import { OrderSparePartService, ToastService } from '../../../providers/index';
import { CreateSparePartOrderPage } from '../create-spare-part-order/create-spare-part-order'
import { OrderSparePartDetailsPage } from '../order-spare-part-details/order-spare-part-details';

@Component({
  selector: 'page-order-spare-part-list',
  templateUrl: 'order-spare-part-list.html'
})
export class OrderSparePartListPage {
  private sparePartOrders:any;
  loading: Loading;
  
  constructor(public navCtrl: NavController,
              public navParams: NavParams,
              private loadingCtrl:LoadingController,
              private orderSparePartService: OrderSparePartService,
              private toastService:ToastService) {
  
  this.showLoading();
  this.getOrderSparePartsList();
}

  private getOrderSparePartsList():void { 

    this.orderSparePartService.getListOfSpareParts().subscribe(workOrderdetails=> {
          
          this.sparePartOrders = workOrderdetails;
          this.loading.dismiss();
    },error => {
      this.showError("ERROR WHILE CREATING WO");
      this.toastService.showToast("bottom", "Not Found.");
    });
  }

  private createSparePartOrder():void {

       this.navCtrl.push(CreateSparePartOrderPage).catch(() => {
          this.showError("ERROR");
        });
  }

  private getPartDetails(orders):void{
   this.navCtrl.push(OrderSparePartDetailsPage, {id: orders.id});
  }

  showLoading():void {
        this.loading = this.loadingCtrl.create({
            content: 'Please wait...'
        });
        this.loading.present();
    }
 
  showError(text):void {
        setTimeout(() => {
            this.loading.dismiss();
        });
        this.toastService.showToast("bottom",text);
    }

}