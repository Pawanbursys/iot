import { Component } from '@angular/core';

import { NavController, NavParams, AlertController } from 'ionic-angular';
import {
	OrderSparePartService, ToastService, WorkOrder, AccountService,
	 Account, WorkOrderService, CatalogService, ConfigService, 
	AddPartsPriceCalculationService
} from '../../../providers/index';

import { OrderSparePartDetailsPage } from '../order-spare-part-details/order-spare-part-details';
import { BarcodeScanner } from 'ionic-native';

@Component({
	selector: 'page-add-spare-part-list',
	templateUrl: 'add-spare-part-list.html'
})
export class AddSparePartListPage {
	private barcodeText: string;
	private account: Account;
	private workOrder: WorkOrder;
	public page = 0;
	public records = 20;
	private productList: any[] = [];
	private clonedProductList: any[] = [];
	private finalProductList: any[] = [];
	private checked: any[] = [];
	private enableClearItem: boolean = false;
	private enableInfiniteScroll: boolean = true;
	private ifPartAreadyAdded: boolean = false;
	private itemNumber: string;
	private itemWithNullQuntity: boolean = false;
	private clonedWorkOrderItems: any[] = [];


	constructor(public navCtrl: NavController,
		public navParams: NavParams,
		private accountService: AccountService,
		private workOrderService: WorkOrderService,
		private orderSparePartService: OrderSparePartService,
		private toastService: ToastService,
		private catalogService: CatalogService,
		private alertController: AlertController,
		private configService: ConfigService,		
		private partsPriceCalculationService: AddPartsPriceCalculationService) {
		this.accountService.getAccount().subscribe(response => {
			this.account = response;
		}, error => {
			this.toastService.showToast("bottom", "Not Found.");
		});
		let woId = navParams.get('id');
		this.getWorkOrder(woId);
	}



	//barcode scan
	onScanServiceBtnClick() {
		BarcodeScanner.scan().then((result) => {
			console.log(result);
			if (!result.cancelled) {
				console.log(result.text);
				this.barcodeText = result.text;
				this.searchItem(result.text);
			}
			console.log("Barcode Format -> " + result.format);
		}, (error) => {
			console.log('error when scanning product barcode');
			this.toastService.showToast("bottom", "NOT FOUND.");
		});
	}

	//search items
	searchItem(itemNumber) {
		if (itemNumber) {
			console.log(itemNumber);

			this.catalogService.searchItemInCatalog(itemNumber, 'PRODUCT', this.account).subscribe(searchedItems => {
				console.log(searchedItems);
				if (searchedItems.length > 0) {
					this.clonedProductList = this.productList.map(x => Object.assign({}, x));
					this.productList = [];
					searchedItems.forEach(searchedItem => {

						this.workOrder.workOrderItems.forEach(items => {
							if (items.itemNumber === searchedItem.vendorItemNumber) {
								console.log("1");
								//when there is only one item in search list and already added to list(show toaster)
								if (searchedItems.length === 1) {
									this.toastService.showToast("bottom", "Already added to spare part list");
								}
								this.ifPartAreadyAdded = true;
							}
						});
						console.log(this.ifPartAreadyAdded);
						if (!this.ifPartAreadyAdded) {
							console.log("2");
							this.productList.push(searchedItem);
							this.ifPartAreadyAdded = false;
						} else if (searchedItems.length === 1) {
							this.searchItem('');
						} else {
							this.ifPartAreadyAdded = false;
						}
					});
					this.enableInfiniteScroll = false;
					this.enableClearItem = true;
				} else {
					this.toastService.showToast("bottom", "NO RESULT FOUND");
					this.enableClearItem = true;
				}
			}, error => {
				this.toastService.showToast("bottom", "ERROR WHILE FEATCHING SEARCH LIST");
			});
		}
		//get items directly from cloned list(no need to request from server)
		else {
			if (this.clonedProductList) {
				this.productList = this.clonedProductList.map(x => Object.assign({}, x));
			}
			//if cloned list is emplty
			else {
				this.loadSpareParts();
			}
			this.itemNumber = "";
			this.enableClearItem = false;
			this.enableInfiniteScroll = true;
		}
	}


	//get WO details
	getWorkOrder(id: String): void {
		this.workOrderService.getWorkOrderDetails(id).take(1).subscribe(wo => {
			this.workOrder = wo;
			this.loadSpareParts();
		}, error => {
			this.toastService.showToast("bottom", "ERROR")
		});
	}

	//called when scrolled
	doInfinite(infiniteScroll: any) {
		console.log('doInfinite, records is currently ' + this.records + ' and page at ' + this.page);
		// this.records = this.records + 20;
		this.page = this.page + 1;

		this.loadSpareParts().then(() => {
			infiniteScroll.complete();
		});

	}

	//load spare parts list
	loadSpareParts() {
		return new Promise(resolve => {
			this.catalogService.getItemList(this.account, this.page, this.records, 'PRODUCT').subscribe(productsList => {
				console.log("lenth is:::", productsList.length);

				if (productsList.length === 0) {
					this.enableInfiniteScroll = false;
				}

				for (let parts of productsList) {
					if (!this.checkProductFromWO(parts)) {
						this.productList.push(parts);
					}
				}
				resolve(true);
			}, error => {
				this.toastService.showToast("bottom", "NOT FOUND.");
			});
			console.log(this.productList);
		});
	}

	// called when quntity is added
	addProductItem(item, i) {

		if (this.checked[i]) {
			item.itemQty = +item.itemQty;
			this.deleteFromFinalList(item, i);
			var productItem = this.partsPriceCalculationService.getItem(this.workOrder, item);
			this.partsPriceCalculationService.priceCalculationOnItemChange(productItem);
			this.finalProductList.push(productItem);
		}
		else {
			this.deleteFromFinalList(item, i);
		}
		console.log(this.finalProductList);
	}

	//oncheckbox hit
	deleteFromFinalList(item, i) {
		this.finalProductList.forEach(product => {
			if (product.itemNumber === item.vendorItemNumber) {
				this.finalProductList.splice(this.finalProductList.indexOf(product), 1);
			}
		});
	}


	//to check parts that are already attached in WO
	checkProductFromWO(product): boolean {
		for (let woItems of this.workOrder.workOrderItems) {
			if (woItems.itemNumber === product.vendorItemNumber) {
				return true;
			}
		}
		return false;
	}

	//save spare part list
	addSpareParts() {
		console.log("this.finalProductList", this.finalProductList);
		this.clonedWorkOrderItems = [];
		this.itemWithNullQuntity = false;
		this.clonedWorkOrderItems = this.workOrder.workOrderItems.map(x => Object.assign({}, x));
		for (let i = 0; i < this.finalProductList.length; i++) {
			if (this.finalProductList[i].itemQty === 0) {
				this.toastService.showToast("bottom", "please enter quntity for ITEM #" + this.finalProductList[i].itemNumber);
				this.workOrder.workOrderItems = this.clonedWorkOrderItems.map(x => Object.assign({}, x));
				this.itemWithNullQuntity = true;
				break;
			} else {
				this.workOrder.workOrderItems.push(this.finalProductList[i]);
			}
		}

		if (this.workOrder && this.workOrder.workOrderItems && !this.itemWithNullQuntity) {
			this.workOrderService.updateWO(this.workOrder).subscribe(wo => {
				this.toastService.showToast("bottom", "Product(s) added to the Work order!");
				this.navCtrl.push(OrderSparePartDetailsPage, { id: wo.id });
			}, error => {
				this.itemWithNullQuntity = false;
				this.toastService.showToast("bottom", "Error while adding Product to Work order!");
			});

		}
	}
}