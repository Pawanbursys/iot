import { Component } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { NavController, NavParams, AlertController, Loading, LoadingController } from 'ionic-angular';
import { OrderSparePartService, WorkOrderService, ToastService, WorkOrder, AddPartsPriceCalculationService,
         Principal } from '../../../providers/index';
import { AuthHttp } from '../../../providers/index';
import { ConfigService } from '../../../providers/config/config.service'
import { AddSparePartListPage } from './../add-spare-part-list/add-spare-part-list'

@Component({
  selector: 'page-order-spare-part-details',
  templateUrl: 'order-spare-part-details.html'
})
export class OrderSparePartDetailsPage {
  loading: Loading;
  woDetailObject: WorkOrder;
  dispatchQuntity: any = [];
  wo_detail_height = 0;
  spare_parts_height = 0;
  wharehouseDetails: any[] = [];
  auths:Array<string>;
  hasWarehouseSelectAuth:boolean = false;


  constructor(public navCtrl: NavController,
    public navParams: NavParams,
    private orderSparePartService: OrderSparePartService,
    private toastService: ToastService,
    private workOrderService: WorkOrderService,
    private alertCtrl: AlertController,
    private partsPriceCalculationService: AddPartsPriceCalculationService,
    private configService: ConfigService,
    private loadingCtrl: LoadingController,
    private authHttp: AuthHttp,
    private principal:Principal) {


    let id = navParams.get('id');
    this.showLoading();
    this.getSparePartDetails(id);
    this.auths = ['VENDOR_SYSTEM_ADMIN','AREA_MANAGER','DISTRICT_MANAGER','VENDOR_TECH_SUPERVISOR','VENDOR_ENGINEER'];

    this.hasWarehouseSelectAuth = this.principal.hasAnyAuthority(this.auths);
  }


  private getSparePartDetails(id: String) {
    this.workOrderService.getWorkOrderDetails(id).take(1).subscribe(workOrderdetails => {
      this.woDetailObject = workOrderdetails;
      console.log(this.woDetailObject);
      this.loading.dismiss();
    }, error => {
      this.showError("ERROR WHILE getting Spare Parts Details");
      this.toastService.showToast("bottom", "Not Found.");
    })
  }

  private addSpareParts(): void {
    this.navCtrl.push(AddSparePartListPage, { id: this.woDetailObject.id });
  }

  public editSparePart(woItem, i) :void{
    let prompt = this.alertCtrl.create({
      title: '#Item: ' + woItem.itemNumber,
      message: "Enter quntity",
      inputs: [
        {
          name: 'quntity',
          placeholder: 'Quntity',
          value: woItem.itemQty,
          type: 'number'
        },
      ],
      buttons: [
        {
          text: 'Cancel',
          handler: data => {
            console.log('Cancel clicked');
          }
        },
        {
          text: 'Save',
          handler: data => {
            if (+data.quntity > 0) {
              let item = {
                description: woItem.description,
                itemQty: +data.quntity,
                itemType: "PRODUCT",
                listPrice: woItem.listPrice,
                vendorItemNumber: woItem.itemNumber
              }
              woItem.itemQty = +data.quntity;
              var productItem = this.partsPriceCalculationService.getItem(this.woDetailObject, item);
              this.partsPriceCalculationService.priceCalculationOnItemChange(productItem);
              console.log(productItem);
              this.saveSparePartsList();
            }
            else {
              this.toastService.showToast("bottom", "please enter quntity greter then 0 for ITEM #" + woItem.itemNumber);
              this.editSparePart(woItem, i);
            }
          }
        }
      ]
    });
    prompt.present();
  }


  public deleteSparePart(woItem, index):void {

    let confirm = this.alertCtrl.create({
      title: '#Item: ' + woItem.itemNumber,
      message: 'Are you sure you wana delete this item?',
      buttons: [
        {
          text: 'Cancel',
          handler: () => {
            console.log('Disagree clicked');
          }
        },
        {
          text: 'Delete',
          handler: () => {
            this.woDetailObject.workOrderItems.splice(index, 1);
            this.saveSparePartsList();
          }
        }
      ]
    });
    confirm.present();
  }



  //save spare part list
  public saveSparePartsList() :void{
    this.showLoading();
    this.workOrderService.updateWO(this.woDetailObject).subscribe(wo => {
      this.loading.dismiss();
      this.toastService.showToast("bottom", "Product(s) Updated Successfully!");
    }, error => {
      this.showError("Error while updating Spare part!");

    });
  }


  //get warehouse data
  public getPartWarehouseList(woItem, index): Observable<Boolean> {

    this.wharehouseDetails = [];
    return Observable.create(observer => {
      this.configService.getServiceUrl("WO_WAREHOUSE").take(1).subscribe(url => {
        this.authHttp.query(url + woItem.itemNumber + '/' + true)
          .map((response) => response.json())
          .subscribe(response => {
            this.wharehouseDetails = response;
            if (this.wharehouseDetails.length === 0) {
              this.toastService.showToast("bottom", "No warehouse found");
              observer.next(false);
              observer.complete();
            }
            observer.next(true);
            observer.complete();
          }, error => {
            this.toastService.showToast("bottom", "Error while getting Warehouse list!");
            observer.next(false);
            observer.complete();
          });
      }, error => {
        this.toastService.showToast("bottom", "Not Found.");
      });
    })
  }

  // called to save WO and Dispatch Quntity
  public editPartDetails(woItem, index) :void{
    //get warehouses

    this.getPartWarehouseList(woItem, index).subscribe(response => {
      // popup to select warehouse
      if (response) {
        let alert = this.alertCtrl.create();
        alert.setTitle('Select Warehouse');

        this.wharehouseDetails.forEach(details => {
          alert.addInput({
            type: 'radio',
            label: details.whseName,
            value: details
          });
        });

        alert.addButton('Cancel');
        alert.addButton({
          text: 'OK',
          handler: data => {
            // popup to save dispatch quntity
            this.saveDispatchQuntity(woItem, data, index);
          }
        });
        alert.present();
      }
    }, error => {
      this.toastService.showToast("bottom", "Not Found.");
    });
  }

  // called to enter dipatch quntity and save WO
  public saveDispatchQuntity(woItem, data, index) {

    let warehouseData = {
      copyDetails: data.copyDetails,
      id: data.id,
      qtyOnHandsValue: data.qtyOnHandsValue,
      showSiteAddress: data.showSiteAddress,
      whseName: data.whseName,
      qtyOnHands: data.qtyOnHands
    };

    let workOrderItems = {
      addOnCostPrice: woItem.addOnCostPrice,
      availableQtyInInventory: woItem.availableQtyInInventory,
      description: woItem.description,
      discountOnListPrice: woItem.discountOnListPrice,
      dispatchQuantity: null,
      itemNumber: woItem.itemNumber,
      itemQty: woItem.itemQty,
      itemType: woItem.itemType,
      listPrice: woItem.listPrice,
      warehouseData: warehouseData,
      price: woItem.price,
      billable: woItem.billable,
      contractPrice: woItem.contactPrice,
      itemNotes: woItem.itemNotes,
      costPrice: woItem.costPrice
    };

    let wo = {
      id: this.woDetailObject.id,
      workOrderId: this.woDetailObject.workOrderId,
      jobStatus: this.woDetailObject.jobStatus,
      workOrderItem: workOrderItems,
      isSparePartsOrder: true
    };

    let prompt = this.alertCtrl.create({
      title: '#Item: ' + woItem.itemNumber,
      message: "Enter Dispatch quntity",
      inputs: [
        {
          name: 'quntity',
          placeholder: 'Quntity',
          type: 'number'
        },
      ],
      buttons: [
        {
          text: 'Cancel',
          handler: data => {
            console.log('Cancel clicked');
          }
        },
        {
          text: 'Save',
          handler: data => {
            if (data.quntity > data.qtyOnHandsValue) {
              this.toastService.showToast("bottom", "WareHouse does not have this much quntity for item");
              this.saveDispatchQuntity(woItem, data, index);
            }
            else if (data.quntity > woItem.itemQty) {
              this.toastService.showToast("bottom", " Dispatch Quntity must be less then quntity required for item ");
              this.saveDispatchQuntity(woItem, data, index);
            } else {
              workOrderItems.dispatchQuantity = +data.quntity;
              console.log(workOrderItems.dispatchQuantity);
              this.saveSparePartOrder(wo, index);
            }
          }
        }
      ]
    });
    prompt.present();
  }

  // called to save WO (Spare part order)
  public saveSparePartOrder(wo, index) :void{
    this.showLoading();
    this.configService.getServiceUrl("WO_ITEM").take(1).subscribe(url => {
      this.authHttp.put(url, wo)
        .subscribe(response => {
          console.log(response);
          this.dispatchQuntity[index] = wo.workOrderItem.dispatchQuantity;
          this.loading.dismiss();
          this.navCtrl.push(OrderSparePartDetailsPage, { id: this.navParams.get('id') });
          this.toastService.showToast("bottom", "Order saved successfully!");
        }, error => {
          this.showError("Error while placing Order!")
        });
    });

  }

  public onFinishWo(): void {
    this.navCtrl.pop();
  }

  public showLoading(): void {
    this.loading = this.loadingCtrl.create({
      content: 'Please wait...'
    });
    this.loading.present();
  }

  public showError(text): void {
    setTimeout(() => {
      this.loading.dismiss();
    });
    this.toastService.showToast("bottom", text);
  }

}